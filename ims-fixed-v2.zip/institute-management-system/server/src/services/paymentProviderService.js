// Configurable online payment provider abstraction (#10, #11). Which
// provider is active is controlled entirely by the PAYMENT_PROVIDER env
// var — never hardcode credentials or pick a provider in code. Defaults
// to 'manual' (the existing, fully-functional cash/bank-transfer flow in
// feeController.js), so online payments are opt-in.
//
// To enable Stripe: set PAYMENT_PROVIDER=stripe, STRIPE_SECRET_KEY, and
// STRIPE_WEBHOOK_SECRET in the environment, and `npm install stripe` in
// server/ (not pre-installed, to avoid forcing the dependency on schools
// that don't use it).

const PROVIDER = process.env.PAYMENT_PROVIDER || 'manual';

// Creates a hosted checkout session for a fee invoice and returns the URL
// to redirect the payer to. Returns null for 'manual' — the frontend
// should fall back to the existing in-person payment recording flow.
async function createCheckoutSession({ fee, student, successUrl, cancelUrl }) {
  if (PROVIDER === 'manual') return null;

  if (PROVIDER === 'stripe') {
    let stripeLib;
    try {
      stripeLib = require('stripe');
    } catch (err) {
      throw new Error('PAYMENT_PROVIDER=stripe but the "stripe" package is not installed. Run `npm install stripe` in server/.');
    }
    if (!process.env.STRIPE_SECRET_KEY) {
      throw new Error('STRIPE_SECRET_KEY is not configured.');
    }
    const stripe = stripeLib(process.env.STRIPE_SECRET_KEY);

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: (process.env.PAYMENT_CURRENCY || 'usd').toLowerCase(),
            product_data: { name: fee.title },
            unit_amount: Math.round((fee.amount - fee.discount - fee.amountPaid) * 100),
          },
          quantity: 1,
        },
      ],
      metadata: { feeId: String(fee._id), studentId: String(student._id) },
      success_url: successUrl,
      cancel_url: cancelUrl,
    });

    return session.url;
  }

  throw new Error(`Unknown PAYMENT_PROVIDER "${PROVIDER}".`);
}

// Verifies and parses a provider webhook payload, returning a normalized
// { feeId, amount, transactionId } on a successful payment event, or null
// for events that don't represent a completed payment.
async function parseWebhookEvent(req) {
  if (PROVIDER !== 'stripe') return null;

  let stripeLib;
  try {
    stripeLib = require('stripe');
  } catch (err) {
    return null;
  }
  const stripe = stripeLib(process.env.STRIPE_SECRET_KEY);

  const event = stripe.webhooks.constructEvent(
    req.body,
    req.headers['stripe-signature'],
    process.env.STRIPE_WEBHOOK_SECRET
  );

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    return {
      feeId: session.metadata.feeId,
      amount: session.amount_total / 100,
      transactionId: session.payment_intent,
    };
  }
  return null;
}

function getActiveProvider() {
  return PROVIDER;
}

module.exports = { createCheckoutSession, parseWebhookEvent, getActiveProvider };
