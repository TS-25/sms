const PDFDocument = require('pdfkit');

// Shared palette matching the app's "Ledger & Brass" design system, so
// generated documents feel consistent with the on-screen UI.
const INK = '#1A1F16';
const INK_SOFT = '#454C3E';
const INK_MUTED = '#6B7263';
const BRASS = '#C99529';
const BRASS_DARK = '#846017';
const CREAM = '#F7F5EF';
const LINE = '#E4E6E0';

// Draws a thin decorative double-rule border with brass corner accents —
// reused by the report card and certificate to give them a "premium"
// document feel without needing any external image assets.
function drawOrnamentalBorder(doc, margin = 20) {
  const { width, height } = doc.page;
  doc.save();
  doc.lineWidth(1.5).strokeColor(BRASS).rect(margin, margin, width - margin * 2, height - margin * 2).stroke();
  doc.lineWidth(0.5).strokeColor(LINE).rect(margin + 6, margin + 6, width - (margin + 6) * 2, height - (margin + 6) * 2).stroke();

  const corners = [
    [margin, margin],
    [width - margin, margin],
    [margin, height - margin],
    [width - margin, height - margin],
  ];
  corners.forEach(([x, y]) => {
    doc.circle(x, y, 3).fill(BRASS);
  });
  doc.restore();
}

// Streams a print-friendly fee receipt PDF directly to the HTTP response.
function generateFeeReceiptPDF(res, { school, student, fee, payment }) {
  const doc = new PDFDocument({ margin: 50, size: 'A4' });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader(
    'Content-Disposition',
    `attachment; filename=receipt-${payment.receiptNumber}.pdf`
  );
  doc.pipe(res);

  doc.fontSize(18).fillColor(INK).text(school?.schoolName || 'School', { align: 'center' });
  if (school?.address) doc.fontSize(10).fillColor(INK_MUTED).text(school.address, { align: 'center' });
  doc.moveDown();
  doc.fontSize(14).fillColor(INK).text('Fee Payment Receipt', { align: 'center', underline: true });
  doc.moveDown(1.5);

  doc.fontSize(11).fillColor(INK);
  doc.text(`Receipt No: ${payment.receiptNumber}`);
  doc.text(`Date: ${new Date(payment.paidAt).toLocaleDateString()}`);
  doc.moveDown();
  doc.text(`Student Name: ${student.fullName}`);
  doc.text(`Admission No: ${student.admissionNumber}`);
  doc.text(`Class/Section: ${student.class?.name || ''} / ${student.section?.name || ''}`);
  doc.moveDown();
  doc.text(`Fee Title: ${fee.title}`);
  doc.text(`Category: ${fee.category}`);
  doc.text(`Total Amount: ${school?.currency || ''} ${fee.amount}`);
  doc.text(`Discount: ${school?.currency || ''} ${fee.discount}`);
  doc.text(`Amount Paid (this receipt): ${school?.currency || ''} ${payment.amount}`);
  doc.text(`Payment Method: ${payment.method}`);
  doc.moveDown(2);
  doc.text('_____________________', { align: 'right' });
  doc.text('Authorized Signature', { align: 'right' });

  doc.end();
}

// Streams a premium-styled report card PDF, including a breakdown table,
// a summary panel, and the school's current grading scale as a legend so
// parents/students can see exactly how the grade was derived.
function generateReportCardPDF(res, { school, student, exam, result, gradingScale = [] }) {
  const doc = new PDFDocument({ margin: 40, size: 'A4' });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader(
    'Content-Disposition',
    `attachment; filename=report-card-${student.admissionNumber}.pdf`
  );
  doc.pipe(res);

  drawOrnamentalBorder(doc);

  doc.fontSize(20).fillColor(INK).text(school?.schoolName || 'School', 40, 40, { align: 'center' });
  if (school?.address) doc.fontSize(9).fillColor(INK_MUTED).text(school.address, { align: 'center' });
  doc.moveDown(0.3);
  doc.fontSize(8).fillColor(BRASS_DARK).text('ACADEMIC REPORT CARD', { align: 'center', characterSpacing: 2 });

  doc.moveDown(0.8);
  doc.moveTo(60, doc.y).lineTo(doc.page.width - 60, doc.y).lineWidth(0.75).strokeColor(BRASS).stroke();
  doc.moveDown(1);

  const infoTop = doc.y;
  doc.fontSize(10).fillColor(INK_SOFT);
  const col1 = 60;
  const col2 = doc.page.width / 2 + 10;
  doc.text(`Student Name:`, col1, infoTop, { continued: true }).fillColor(INK).text(` ${student.fullName}`);
  doc.fillColor(INK_SOFT).text(`Admission No:`, col1, infoTop + 16, { continued: true }).fillColor(INK).text(` ${student.admissionNumber}`);
  doc.fillColor(INK_SOFT).text(`Class / Section:`, col1, infoTop + 32, { continued: true }).fillColor(INK).text(` ${student.class?.name || ''} / ${student.section?.name || ''}`);

  doc.fillColor(INK_SOFT).text(`Exam:`, col2, infoTop, { continued: true }).fillColor(INK).text(` ${exam.name}`);
  doc.fillColor(INK_SOFT).text(`Roll No:`, col2, infoTop + 16, { continued: true }).fillColor(INK).text(` ${student.rollNumber || '—'}`);
  doc.fillColor(INK_SOFT).text(`Date:`, col2, infoTop + 32, { continued: true }).fillColor(INK).text(` ${new Date().toLocaleDateString()}`);

  doc.y = infoTop + 56;
  doc.moveDown(0.5);

  const tableX = 60;
  const tableWidth = doc.page.width - 120;
  const col = { subject: tableX, full: tableX + 220, obtained: tableX + 320, pct: tableX + 400 };

  let y = doc.y;
  doc.rect(tableX, y, tableWidth, 22).fill(INK);
  doc.fillColor(CREAM).fontSize(9);
  doc.text('SUBJECT', col.subject + 8, y + 6);
  doc.text('FULL MARKS', col.full, y + 6);
  doc.text('OBTAINED', col.obtained, y + 6);
  doc.text('%', col.pct, y + 6);
  y += 22;

  doc.font('Helvetica').fontSize(10);
  result.marks.forEach((m, idx) => {
    const rowHeight = 22;
    if (idx % 2 === 1) {
      doc.rect(tableX, y, tableWidth, rowHeight).fill('#F3F4F1');
    }
    const subjPct = m.fullMarks > 0 ? Math.round((m.marksObtained / m.fullMarks) * 1000) / 10 : 0;
    doc.fillColor(INK);
    doc.text(m.subject?.name || String(m.subject), col.subject + 8, y + 6);
    doc.text(String(m.fullMarks), col.full, y + 6);
    doc.text(String(m.marksObtained), col.obtained, y + 6);
    doc.text(`${subjPct}%`, col.pct, y + 6);
    y += rowHeight;
  });
  doc.moveTo(tableX, y).lineTo(tableX + tableWidth, y).lineWidth(0.5).strokeColor(LINE).stroke();
  doc.y = y + 16;

  const summaryTop = doc.y;
  const summaryHeight = 70;
  doc.roundedRect(tableX, summaryTop, tableWidth, summaryHeight, 4).fill('#FBF3E3');
  doc.fillColor(INK).fontSize(11);
  const sCol1 = tableX + 20;
  const sCol2 = tableX + tableWidth / 2 + 10;
  doc.text(`Total: ${result.totalObtained} / ${result.totalFullMarks}`, sCol1, summaryTop + 14);
  doc.text(`Percentage: ${result.percentage}%`, sCol1, summaryTop + 34);
  doc.fontSize(14).fillColor(BRASS_DARK).text(`Grade: ${result.grade}`, sCol2, summaryTop + 12);
  doc.fontSize(11).fillColor(INK).text(`GPA: ${result.gpa}`, sCol2, summaryTop + 34);
  doc
    .fontSize(12)
    .fillColor(result.isPass ? '#2F6B3A' : '#B3261E')
    .text(result.isPass ? 'RESULT: PASS' : 'RESULT: FAIL', sCol1, summaryTop + 50, { characterSpacing: 1 });

  doc.y = summaryTop + summaryHeight + 20;

  if (gradingScale.length) {
    doc.fontSize(9).fillColor(INK_MUTED).text('GRADING SCALE', tableX, doc.y, { characterSpacing: 1 });
    doc.moveDown(0.3);
    const sorted = [...gradingScale].sort((a, b) => b.minPercentage - a.minPercentage);
    const legendText = sorted
      .map((t) => `${t.grade} (${t.minPercentage}%+, GPA ${t.gpa})`)
      .join('   ·   ');
    doc.fontSize(8).fillColor(INK_SOFT).text(legendText, tableX, doc.y, { width: tableWidth });
    doc.moveDown(1);
  }

  const sigY = Math.max(doc.y + 30, doc.page.height - 110);
  doc.fontSize(10).fillColor(INK);
  doc.moveTo(tableX, sigY).lineTo(tableX + 150, sigY).strokeColor(INK_MUTED).stroke();
  doc.text('Class Teacher', tableX, sigY + 6);
  doc.moveTo(tableX + tableWidth - 150, sigY).lineTo(tableX + tableWidth, sigY).strokeColor(INK_MUTED).stroke();
  doc.text('Principal', tableX + tableWidth - 150, sigY + 6);

  doc.end();
}

// Streams a wallet-sized student/staff ID card PDF (front side only —
// simple, print-friendly, one card per page for now).
function generateIdCardPDF(res, { school, person, role, idLabel, classSection }) {
  const doc = new PDFDocument({ size: [242, 153], margin: 10 });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename=id-card-${idLabel}.pdf`);
  doc.pipe(res);

  doc.rect(0, 0, 242, 153).fill(INK);
  doc.fillColor(CREAM).fontSize(10).text(school?.schoolName || 'School', 10, 10, { width: 222 });
  doc.fontSize(7).fillColor(BRASS).text(role.toUpperCase(), 10, 24);

  doc.fillColor(CREAM).fontSize(11).text(person.fullName || person.name, 10, 45, { width: 150 });
  doc.fontSize(8).fillColor('#C4C8BE');
  doc.text(`ID: ${idLabel}`, 10, 62);
  if (classSection) doc.text(`Class: ${classSection}`, 10, 76);
  if (person.phone) doc.text(`Phone: ${person.phone}`, 10, 90);

  doc.fontSize(6).fillColor('#9DA394').text(school?.address || '', 10, 130, { width: 222 });

  doc.end();
}

// Streams a premium, ornamental certificate PDF (character, transfer,
// participation, etc). The body text and title come directly from the
// Certificate document, so the same layout works for any certificate type
// and stays editable — see certificateController.js's update endpoint.
function generateCertificatePDF(res, { school, student, certificate }) {
  const doc = new PDFDocument({ margin: 0, size: 'A4', layout: 'landscape' });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader(
    'Content-Disposition',
    `attachment; filename=certificate-${certificate.certificateNumber}.pdf`
  );
  doc.pipe(res);

  const { width, height } = doc.page;

  doc.rect(0, 0, width, height).fill(CREAM);
  drawOrnamentalBorder(doc, 24);
  doc.lineWidth(0.75).strokeColor(BRASS).rect(34, 34, width - 68, height - 68).stroke();

  const crestCx = width / 2;
  const crestCy = 78;
  doc.save();
  doc.circle(crestCx, crestCy, 26).lineWidth(2).strokeColor(BRASS).stroke();
  doc.circle(crestCx, crestCy, 20).lineWidth(0.75).strokeColor(BRASS).stroke();
  doc.fontSize(16).fillColor(BRASS_DARK).text('*', crestCx - 4, crestCy - 8);
  doc.restore();

  doc.fontSize(22).fillColor(INK).text(school?.schoolName || 'School', 0, 118, { align: 'center' });
  if (school?.address) doc.fontSize(9).fillColor(INK_MUTED).text(school.address, { align: 'center' });

  doc.moveDown(0.6);
  doc.fontSize(30).fillColor(BRASS_DARK).text(certificate.title, { align: 'center' });

  doc.moveDown(0.3);
  const dividerY = doc.y + 6;
  doc.moveTo(width / 2 - 90, dividerY).lineTo(width / 2 + 90, dividerY).lineWidth(1).strokeColor(BRASS).stroke();
  doc.circle(width / 2, dividerY, 2.5).fill(BRASS);

  doc.moveDown(2);
  doc
    .fontSize(14)
    .fillColor(INK_SOFT)
    .text(certificate.body.replace(/\{\{\s*studentName\s*\}\}/gi, student.fullName), {
      align: 'center',
      width: width - 220,
      lineGap: 8,
    });

  const footerY = height - 110;
  doc.fontSize(9).fillColor(INK_MUTED);
  doc.text(`Certificate No: ${certificate.certificateNumber}`, 80, footerY);
  doc.text(`Date: ${new Date(certificate.issueDate).toLocaleDateString()}`, 80, footerY + 14);

  doc.moveTo(width - 260, footerY + 24).lineTo(width - 80, footerY + 24).strokeColor(INK_MUTED).stroke();
  doc.fontSize(9).fillColor(INK).text('Principal Signature', width - 260, footerY + 30, { width: 180, align: 'center' });

  doc.end();
}

module.exports = {
  generateFeeReceiptPDF,
  generateReportCardPDF,
  generateIdCardPDF,
  generateCertificatePDF,
};
