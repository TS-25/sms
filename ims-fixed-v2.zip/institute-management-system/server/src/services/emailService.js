const nodemailer = require('nodemailer');

// Per-school transporters are cached so we don't rebuild a nodemailer
// transport on every single email — invalidated whenever settings are
// saved (see settingsController.js's updateSettings calling
// clearTransporterCache).
const transporterCache = new Map();

// Falls back to a single server-wide transporter built from env vars —
// keeps existing single-institute deployments working with zero config,
// and is also the fallback for any institute that hasn't set up its own
// provider yet.
let envTransporter;
let envTransporterAttempted = false;

function getEnvTransporter() {
  if (envTransporterAttempted) return envTransporter;
  envTransporterAttempted = true;
  if (!process.env.EMAIL_HOST) return null;

  envTransporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: Number(process.env.EMAIL_PORT) || 587,
    secure: Number(process.env.EMAIL_PORT) === 465,
    auth: process.env.EMAIL_USER
      ? { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASSWORD }
      : undefined,
  });
  return envTransporter;
}

// Fetches (and caches) a transporter built from a specific school's
// admin-configured email settings (Settings → Email Provider in the UI).
async function getTransporterForSchool(schoolId) {
  if (!schoolId) return null;
  if (transporterCache.has(String(schoolId))) return transporterCache.get(String(schoolId));

  const SchoolSettings = require('../models/SchoolSettings');
  const settings = await SchoolSettings.findOne({ school: schoolId }).select('+emailConfig.password');
  const config = settings?.emailConfig;

  if (!config || config.provider !== 'smtp' || !config.host) {
    transporterCache.set(String(schoolId), null);
    return null;
  }

  const transporter = nodemailer.createTransport({
    host: config.host,
    port: config.port || 587,
    secure: !!config.secure,
    auth: config.user ? { user: config.user, pass: config.password } : undefined,
  });

  transporterCache.set(String(schoolId), { transporter, fromAddress: config.fromAddress, fromName: config.fromName });
  return transporterCache.get(String(schoolId));
}

// Call this after saving email settings so the next send picks up the new
// configuration instead of a stale cached transporter.
function clearTransporterCache(schoolId) {
  transporterCache.delete(String(schoolId));
}

// Core send function. Tries the school's own configured provider first,
// then falls back to the server-wide env-based transporter, then finally
// to a console log — so email-dependent flows (password reset, etc.)
// never hard-fail just because no provider has been configured yet.
const sendEmail = async ({ schoolId, to, subject, html, text }) => {
  const schoolTransporter = await getTransporterForSchool(schoolId);
  if (schoolTransporter?.transporter) {
    return schoolTransporter.transporter.sendMail({
      from: schoolTransporter.fromName
        ? `"${schoolTransporter.fromName}" <${schoolTransporter.fromAddress || schoolTransporter.transporter.options.auth?.user}>`
        : schoolTransporter.fromAddress || schoolTransporter.transporter.options.auth?.user,
      to,
      subject,
      html,
      text,
    });
  }

  const fallback = getEnvTransporter();
  if (!fallback) {
    console.log(`[email:mock] To: ${to} | Subject: ${subject}\n${text || html}`);
    return { mocked: true };
  }
  return fallback.sendMail({
    from: process.env.EMAIL_FROM || 'no-reply@institute.com',
    to,
    subject,
    html,
    text,
  });
};

// Built-in fallback templates, used when an institute hasn't customized
// one via the EmailTemplate model. {{variable}} placeholders are
// substituted the same way for both built-in and custom templates.
const DEFAULT_TEMPLATES = {
  welcome: {
    subject: 'Welcome to {{institutionName}}',
    body: 'Hi {{recipientName}}, your account at {{institutionName}} has been created. You can now log in with the credentials provided by your institute.',
  },
  password_reset: {
    subject: 'Reset your password',
    body: 'Reset your password using this link (valid 30 minutes): {{resetUrl}}',
  },
  fee_reminder: {
    subject: 'Fee payment reminder — {{institutionName}}',
    body: 'This is a reminder that a payment of {{amount}} is due on {{dueDate}} for {{studentName}}.',
  },
  payment_confirmation: {
    subject: 'Payment received — {{institutionName}}',
    body: 'We have received your payment of {{amount}}. Receipt number: {{receiptNumber}}.',
  },
  result_published: {
    subject: 'Results published — {{institutionName}}',
    body: 'Results for {{examName}} have been published for {{studentName}}. Log in to view the full report card.',
  },
  notice_published: {
    subject: 'New notice — {{institutionName}}',
    body: 'A new notice has been published: {{noticeTitle}}.',
  },
};

function fillTemplate(str, vars) {
  return str.replace(/\{\{\s*(\w+)\s*\}\}/g, (_, key) => (vars[key] !== undefined ? vars[key] : ''));
}

// Sends an email using the institute's custom template if one exists for
// `type`, otherwise falls back to the built-in default.
const sendTemplatedEmail = async ({ schoolId, type, to, variables = {} }) => {
  const EmailTemplate = require('../models/EmailTemplate');
  let template = schoolId ? await EmailTemplate.findOne({ school: schoolId, type }) : null;
  if (!template) template = DEFAULT_TEMPLATES[type];
  if (!template) throw new Error(`No email template found for type "${type}" and no default exists.`);

  const subject = fillTemplate(template.subject, variables);
  const body = fillTemplate(template.body, variables);
  return sendEmail({ schoolId, to, subject, html: `<p>${body}</p>`, text: body });
};

// Sends a real test message through whatever provider is currently
// configured (school-specific or the env fallback), so an admin can
// verify their SMTP settings actually work before relying on them.
const sendTestEmail = async ({ schoolId, to }) => {
  return sendEmail({
    schoolId,
    to,
    subject: 'Test email from your Institute Management System',
    html: '<p>If you received this, your email provider is configured correctly.</p>',
    text: 'If you received this, your email provider is configured correctly.',
  });
};

module.exports = { sendEmail, sendTemplatedEmail, sendTestEmail, clearTransporterCache, DEFAULT_TEMPLATES };
