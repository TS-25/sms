// Real backup/restore via `mongodump`/`mongorestore` CLI tools, shelled
// out through Node's child_process (#34). These ship with the MongoDB
// Database Tools package — NOT bundled with this app, so document that
// the deployment environment needs them installed (the official `mongo`
// Docker image includes them; a bare Node host may need a separate
// install). Never exposes backups publicly — downloads require
// SUPER_ADMIN auth (see backupRoutes.js).
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');
const util = require('util');

const execAsync = util.promisify(exec);
const BACKUP_DIR = path.join(__dirname, '..', '..', 'backups');

if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

async function runBackup() {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const outDir = path.join(BACKUP_DIR, `backup-${timestamp}`);
  const uri = process.env.MONGODB_URI;

  await execAsync(`mongodump --uri="${uri}" --out="${outDir}"`);

  // Package into a single archive for easier download/storage.
  const archivePath = `${outDir}.archive`;
  await execAsync(`mongodump --uri="${uri}" --archive="${archivePath}" --gzip`);

  // Clean up the loose directory dump now that the archive exists.
  fs.rmSync(outDir, { recursive: true, force: true });

  const stats = fs.statSync(archivePath);
  return { filePath: archivePath, fileSizeBytes: stats.size };
}

function listBackupFiles() {
  if (!fs.existsSync(BACKUP_DIR)) return [];
  return fs.readdirSync(BACKUP_DIR).filter((f) => f.endsWith('.archive'));
}

module.exports = { runBackup, listBackupFiles, BACKUP_DIR };
