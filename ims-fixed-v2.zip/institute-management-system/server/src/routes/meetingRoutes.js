const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ADMIN_LIKE, ROLES } = require('../config/roles');
const ctrl = require('../controllers/meetingController');

const router = express.Router();

router.use(protect, requireSchool);

router.get('/', ctrl.getSlots);
router.post('/', authorize(ROLES.TEACHER, ...ADMIN_LIKE), ctrl.createSlot);
router.post('/:id/book', authorize(ROLES.PARENT, ROLES.STUDENT), ctrl.bookSlot);
router.patch('/:id/cancel', ctrl.cancelSlot);
router.delete('/:id', authorize(ROLES.TEACHER, ...ADMIN_LIKE), ctrl.deleteSlot);

module.exports = router;
