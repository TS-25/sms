const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { FINANCE_ROLES } = require('../config/roles');
const ctrl = require('../controllers/payrollController');

const router = express.Router();

router.use(protect, requireSchool, authorize(...FINANCE_ROLES));

router.get('/structures', ctrl.getStructures);
router.post('/structures', ctrl.upsertStructure);
router.post('/generate', ctrl.generatePayroll);
router.get('/payslips', ctrl.getPayslips);
router.patch('/payslips/:id/pay', ctrl.markPaid);

module.exports = router;
