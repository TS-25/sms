const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ROLES } = require('../config/roles');
const ctrl = require('../controllers/securityController');

const router = express.Router();

router.use(protect, requireSchool, authorize(ROLES.ADMIN));

router.get('/dashboard', ctrl.getSecurityDashboard);

module.exports = router;
