const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ADMIN_LIKE } = require('../config/roles');
const ctrl = require('../controllers/hostelController');

const router = express.Router();

router.use(protect, requireSchool);

router.get('/', ctrl.getHostels);
router.post('/', authorize(...ADMIN_LIKE), ctrl.createHostel);
router.put('/:id', authorize(...ADMIN_LIKE), ctrl.updateHostel);
router.delete('/:id', authorize(...ADMIN_LIKE), ctrl.deleteHostel);

router.post('/:id/rooms', authorize(...ADMIN_LIKE), ctrl.addRoom);
router.patch('/:id/rooms/:roomId/beds/:bedId/allocate', authorize(...ADMIN_LIKE), ctrl.allocateBed);
router.patch('/:id/rooms/:roomId/beds/:bedId/checkout', authorize(...ADMIN_LIKE), ctrl.checkoutBed);

module.exports = router;
