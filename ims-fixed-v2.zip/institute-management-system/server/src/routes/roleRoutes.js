const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ROLES } = require('../config/roles');
const ctrl = require('../controllers/roleController');

const router = express.Router();

router.use(protect, requireSchool, authorize(ROLES.ADMIN));

router.get('/permissions', ctrl.getPermissionCatalog);
router.get('/', ctrl.getRoles);
router.post('/', ctrl.createRole);
router.put('/:id', ctrl.updateRole);
router.delete('/:id', ctrl.deleteRole);

module.exports = router;
