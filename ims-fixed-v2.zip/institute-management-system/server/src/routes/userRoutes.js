const express = require('express');
const { body } = require('express-validator');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const validate = require('../middleware/validate');
const { ROLES } = require('../config/roles');
const ctrl = require('../controllers/userController');

const router = express.Router();

router.use(protect, requireSchool, authorize(ROLES.ADMIN));

router.get('/', ctrl.getUsers);
router.post(
  '/',
  [
    body('name').notEmpty(),
    body('email').isEmail(),
    body('password').isLength({ min: 6 }),
    body('role').isIn(Object.values(ROLES)),
  ],
  validate,
  ctrl.createUser
);
router.put('/:id', ctrl.updateUser);
router.delete('/:id', ctrl.deleteUser);

module.exports = router;
