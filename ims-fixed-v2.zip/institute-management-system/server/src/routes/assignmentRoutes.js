const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ADMIN_LIKE, ROLES } = require('../config/roles');
const ctrl = require('../controllers/assignmentController');

const router = express.Router();

router.use(protect, requireSchool);

router.get('/', ctrl.getAssignments);
router.post('/', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.createAssignment);
router.put('/:id', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.updateAssignment);
router.delete('/:id', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.deleteAssignment);
router.post('/:id/submit', authorize(ROLES.STUDENT, ...ADMIN_LIKE), ctrl.submitAssignment);

module.exports = router;
