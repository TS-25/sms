const express = require('express');
const { protect } = require('../middleware/auth');
const ctrl = require('../controllers/sessionController');

const router = express.Router();

router.use(protect);

router.get('/', ctrl.getMySessions);
router.delete('/:id', ctrl.revokeSession);
router.delete('/', ctrl.revokeAllOtherSessions);

module.exports = router;
