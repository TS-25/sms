const express = require('express');
const { body } = require('express-validator');
const { protect, authorize } = require('../middleware/auth');
const validate = require('../middleware/validate');
const { ROLES } = require('../config/roles');
const ctrl = require('../controllers/platformController');
const backupCtrl = require('../controllers/backupController');

const router = express.Router();

// Platform routes are SUPER_ADMIN only, and deliberately do NOT use
// requireSchool — these endpoints operate across tenants by design.
router.use(protect, authorize(ROLES.SUPER_ADMIN));

router.get('/stats', ctrl.getPlatformStats);

router.get('/schools', ctrl.getSchools);
router.get('/schools/:id', ctrl.getSchool);
router.post(
  '/schools',
  [
    body('name').notEmpty(),
    body('slug').notEmpty().matches(/^[a-z0-9-]+$/).withMessage('Slug must be lowercase letters, numbers, and hyphens only.'),
    body('adminName').notEmpty(),
    body('adminEmail').isEmail(),
    body('adminPassword').isLength({ min: 6 }),
  ],
  validate,
  ctrl.createSchool
);
router.put('/schools/:id', ctrl.updateSchool);
router.patch('/schools/:id/status', ctrl.setSchoolStatus);
router.patch('/schools/:id/modules', ctrl.updateSchoolModules);

router.post('/backups', backupCtrl.triggerBackup);
router.get('/backups', backupCtrl.getBackups);
router.get('/backups/:id/download', backupCtrl.downloadBackup);

module.exports = router;
