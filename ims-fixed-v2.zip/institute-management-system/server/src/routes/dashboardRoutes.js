const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ADMIN_LIKE, ROLES } = require('../config/roles');
const ctrl = require('../controllers/dashboardController');

const router = express.Router();

router.use(protect, requireSchool);

router.get('/admin', authorize(...ADMIN_LIKE, ROLES.ACCOUNTANT), ctrl.getAdminStats);
router.get('/teacher', authorize(ROLES.TEACHER), ctrl.getTeacherStats);
router.get('/student', authorize(ROLES.STUDENT, ROLES.PARENT), ctrl.getStudentStats);

module.exports = router;
