const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ADMIN_LIKE, ROLES } = require('../config/roles');
const ctrl = require('../controllers/libraryController');

const router = express.Router();
const LIBRARY_STAFF = [...ADMIN_LIKE, ROLES.LIBRARIAN];

router.use(protect, requireSchool);

router.get('/books', ctrl.getBooks);
router.post('/books', authorize(...LIBRARY_STAFF), ctrl.createBook);
router.put('/books/:id', authorize(...LIBRARY_STAFF), ctrl.updateBook);
router.delete('/books/:id', authorize(...LIBRARY_STAFF), ctrl.deleteBook);

router.post('/issue', authorize(...LIBRARY_STAFF), ctrl.issueBook);
router.patch('/return/:transactionId', authorize(...LIBRARY_STAFF), ctrl.returnBook);
router.get('/transactions', authorize(...LIBRARY_STAFF, ROLES.STUDENT, ROLES.TEACHER), ctrl.getTransactions);

module.exports = router;
