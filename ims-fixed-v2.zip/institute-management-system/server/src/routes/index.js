const express = require('express');

const router = express.Router();

router.use('/auth', require('./authRoutes'));
router.use('/platform', require('./platformRoutes'));
router.use('/users', require('./userRoutes'));
router.use('/roles', require('./roleRoutes'));
router.use('/promotions', require('./promotionRoutes'));
router.use('/alumni', require('./alumniRoutes'));
router.use('/sessions', require('./sessionRoutes'));
router.use('/security', require('./securityRoutes'));
router.use('/payroll', require('./payrollRoutes'));
router.use('/email-templates', require('./emailTemplateRoutes'));
router.use('/cms', require('./cmsRoutes'));
router.use('/gallery', require('./galleryRoutes'));
router.use('/clubs', require('./clubRoutes'));
router.use('/sports', require('./sportsRoutes'));
router.use('/student-records', require('./studentRecordsRoutes'));
router.use('/meetings', require('./meetingRoutes'));
router.use('/public', require('./publicRoutes'));
router.use('/students', require('./studentRoutes'));
router.use('/teachers', require('./teacherRoutes'));
router.use('/academics', require('./academicRoutes'));
router.use('/attendance', require('./attendanceRoutes'));
router.use('/exams', require('./examRoutes'));
router.use('/', require('./feeRoutes')); // exposes /fees and /payments
router.use('/expenses', require('./expenseRoutes'));
router.use('/notices', require('./noticeRoutes'));
router.use('/notifications', require('./notificationRoutes'));
router.use('/assignments', require('./assignmentRoutes'));
router.use('/dashboard', require('./dashboardRoutes'));
router.use('/settings', require('./settingsRoutes'));
router.use('/audit-logs', require('./auditLogRoutes'));
router.use('/uploads', require('./uploadRoutes'));
router.use('/timetables', require('./timetableRoutes'));
router.use('/library', require('./libraryRoutes'));
router.use('/transport', require('./transportRoutes'));
router.use('/hostels', require('./hostelRoutes'));
router.use('/staff', require('./staffRoutes'));
router.use('/leaves', require('./leaveRoutes'));
router.use('/events', require('./eventRoutes'));
router.use('/documents', require('./documentRoutes'));
router.use('/id-cards', require('./idCardRoutes'));
router.use('/certificates', require('./certificateRoutes'));

router.get('/health', (req, res) => res.json({ success: true, message: 'API is healthy.' }));

module.exports = router;
