const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ADMIN_LIKE, ROLES } = require('../config/roles');
const ctrl = require('../controllers/clubController');

const router = express.Router();

router.use(protect, requireSchool);

router.get('/', ctrl.getClubs);
router.post('/', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.createClub);
router.put('/:id', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.updateClub);
router.delete('/:id', authorize(...ADMIN_LIKE), ctrl.deleteClub);
router.post('/:id/activities', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.addActivity);

module.exports = router;
