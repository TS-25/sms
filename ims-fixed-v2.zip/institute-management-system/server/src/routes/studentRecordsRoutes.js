const express = require('express');
const { protect, authorize, requireSchool, authorizeOrPermission } = require('../middleware/auth');
const { ADMIN_LIKE, ROLES } = require('../config/roles');
const ctrl = require('../controllers/studentRecordsController');

const router = express.Router();

router.use(protect, requireSchool);

// Achievements & merit — visible more broadly, editable by admin-like/teacher
router.get('/achievements', ctrl.getAchievements);
router.post('/achievements', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.createAchievement);
router.delete('/achievements/:id', authorize(...ADMIN_LIKE), ctrl.deleteAchievement);

router.get('/merit', ctrl.getMeritPoints);
router.get('/merit/leaderboard', ctrl.getMeritLeaderboard);
router.post('/merit', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.giveMeritPoint);

// Discipline — sensitive; admin-like roles, or anyone explicitly granted
// the discipline.view/manage permission via a custom Role (Phase 2).
router.get('/discipline', authorizeOrPermission(ADMIN_LIKE, 'discipline.view'), ctrl.getDisciplineIncidents);
router.post('/discipline', authorizeOrPermission(ADMIN_LIKE, 'discipline.manage'), ctrl.createDisciplineIncident);

// Health records — same pattern, gated by health.view/manage.
router.get('/health/:studentId', authorizeOrPermission(ADMIN_LIKE, 'health.view'), ctrl.getHealthRecord);
router.put('/health/:studentId', authorizeOrPermission(ADMIN_LIKE, 'health.manage'), ctrl.upsertHealthRecord);

module.exports = router;
