const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ADMIN_LIKE, ROLES } = require('../config/roles');
const ctrl = require('../controllers/sportsController');

const router = express.Router();

router.use(protect, requireSchool);

router.get('/', ctrl.getTeams);
router.post('/', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.createTeam);
router.put('/:id', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.updateTeam);
router.delete('/:id', authorize(...ADMIN_LIKE), ctrl.deleteTeam);
router.post('/:id/matches', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.addMatch);

module.exports = router;
