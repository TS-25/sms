const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ADMIN_LIKE } = require('../config/roles');
const ctrl = require('../controllers/cmsController');

const router = express.Router();

router.use(protect, requireSchool, authorize(...ADMIN_LIKE));

router.get('/pages', ctrl.getPages);
router.post('/pages', ctrl.createPage);
router.put('/pages/:id', ctrl.updatePage);
router.delete('/pages/:id', ctrl.deletePage);

module.exports = router;
