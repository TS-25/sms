const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ADMIN_LIKE } = require('../config/roles');
const ctrl = require('../controllers/idCardController');

const router = express.Router();

router.use(protect, requireSchool, authorize(...ADMIN_LIKE));

router.get('/student/:studentId', ctrl.studentIdCard);
router.get('/teacher/:teacherId', ctrl.teacherIdCard);

module.exports = router;
