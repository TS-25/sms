const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ROLES } = require('../config/roles');
const ctrl = require('../controllers/emailTemplateController');

const router = express.Router();

router.use(protect, requireSchool, authorize(ROLES.ADMIN));

router.get('/', ctrl.getTemplates);
router.put('/:type', ctrl.upsertTemplate);
router.delete('/:type', ctrl.resetTemplate);
router.post('/send-test', ctrl.sendTest);

module.exports = router;
