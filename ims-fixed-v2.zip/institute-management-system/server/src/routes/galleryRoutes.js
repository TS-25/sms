const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ADMIN_LIKE } = require('../config/roles');
const ctrl = require('../controllers/galleryController');

const router = express.Router();

router.use(protect, requireSchool, authorize(...ADMIN_LIKE));

router.get('/', ctrl.getAlbums);
router.post('/', ctrl.createAlbum);
router.put('/:id', ctrl.updateAlbum);
router.delete('/:id', ctrl.deleteAlbum);
router.post('/:id/images', ctrl.addImage);
router.delete('/:id/images/:imageId', ctrl.removeImage);

module.exports = router;
