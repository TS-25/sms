const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ADMIN_LIKE } = require('../config/roles');
const ctrl = require('../controllers/transportController');

const router = express.Router();

router.use(protect, requireSchool);

router.get('/vehicles', ctrl.getVehicles);
router.post('/vehicles', authorize(...ADMIN_LIKE), ctrl.createVehicle);
router.put('/vehicles/:id', authorize(...ADMIN_LIKE), ctrl.updateVehicle);
router.delete('/vehicles/:id', authorize(...ADMIN_LIKE), ctrl.deleteVehicle);

router.get('/routes', ctrl.getRoutes);
router.post('/routes', authorize(...ADMIN_LIKE), ctrl.createRoute);
router.put('/routes/:id', authorize(...ADMIN_LIKE), ctrl.updateRoute);
router.delete('/routes/:id', authorize(...ADMIN_LIKE), ctrl.deleteRoute);

router.get('/assignments', authorize(...ADMIN_LIKE), ctrl.getAssignments);
router.post('/assign', authorize(...ADMIN_LIKE), ctrl.assignStudent);
router.delete('/assignments/:id', authorize(...ADMIN_LIKE), ctrl.removeAssignment);

module.exports = router;
