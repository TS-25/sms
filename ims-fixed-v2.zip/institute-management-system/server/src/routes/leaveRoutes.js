const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ADMIN_LIKE } = require('../config/roles');
const ctrl = require('../controllers/leaveController');

const router = express.Router();

router.use(protect, requireSchool);

router.get('/', ctrl.getLeaves);
router.post('/', ctrl.applyLeave);
router.patch('/:id/review', authorize(...ADMIN_LIKE), ctrl.reviewLeave);
router.delete('/:id', ctrl.deleteLeave);

module.exports = router;
