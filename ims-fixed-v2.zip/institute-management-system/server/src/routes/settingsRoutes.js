const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ROLES } = require('../config/roles');
const ctrl = require('../controllers/settingsController');

const router = express.Router();

// Public branding info (school name/logo) for the login screen — must be
// registered before the protect() middleware below.
router.get('/public', ctrl.getPublicSettings);

router.use(protect, requireSchool);

router.get('/', ctrl.getSettings);
router.put('/', authorize(ROLES.ADMIN), ctrl.updateSettings);

module.exports = router;
