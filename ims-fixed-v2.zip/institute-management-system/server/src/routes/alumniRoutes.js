const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ADMIN_LIKE } = require('../config/roles');
const ctrl = require('../controllers/alumniController');

const router = express.Router();

router.use(protect, requireSchool, authorize(...ADMIN_LIKE));

router.get('/', ctrl.getAlumni);
router.get('/stats', ctrl.getAlumniStats);
router.put('/:id', ctrl.updateAlumni);

module.exports = router;
