const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ROLES } = require('../config/roles');
const ctrl = require('../controllers/auditLogController');

const router = express.Router();

router.use(protect, requireSchool, authorize(ROLES.ADMIN));

router.get('/', ctrl.getAuditLogs);

module.exports = router;
