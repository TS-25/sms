const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ADMIN_LIKE, ROLES } = require('../config/roles');
const ctrl = require('../controllers/noticeController');

const router = express.Router();

router.use(protect, requireSchool);

router.get('/', ctrl.getNotices);
router.post('/', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.createNotice);
router.put('/:id', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.updateNotice);
router.delete('/:id', authorize(...ADMIN_LIKE), ctrl.deleteNotice);

module.exports = router;
