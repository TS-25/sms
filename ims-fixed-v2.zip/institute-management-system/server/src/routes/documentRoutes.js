const express = require('express');
const { protect, requireSchool } = require('../middleware/auth');
const upload = require('../middleware/upload');
const ctrl = require('../controllers/documentController');

const router = express.Router();

router.use(protect, requireSchool);

router.get('/', ctrl.getDocuments);
router.post('/', upload.single('file'), ctrl.uploadDocument);
router.delete('/:id', ctrl.deleteDocument);

module.exports = router;
