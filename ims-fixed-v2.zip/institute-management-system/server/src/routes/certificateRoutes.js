const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ADMIN_LIKE, ROLES } = require('../config/roles');
const ctrl = require('../controllers/certificateController');

const router = express.Router();

router.use(protect, requireSchool);

router.get('/', authorize(...ADMIN_LIKE, ROLES.STUDENT, ROLES.PARENT), ctrl.getCertificates);
router.post('/', authorize(...ADMIN_LIKE), ctrl.createCertificate);
router.put('/:id', authorize(...ADMIN_LIKE), ctrl.updateCertificate);
router.delete('/:id', authorize(...ADMIN_LIKE), ctrl.deleteCertificate);
router.get('/:id/pdf', authorize(...ADMIN_LIKE, ROLES.STUDENT, ROLES.PARENT), ctrl.downloadCertificate);

module.exports = router;
