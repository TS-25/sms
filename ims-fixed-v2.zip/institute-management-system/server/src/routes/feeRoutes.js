const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { FINANCE_ROLES, ROLES } = require('../config/roles');
const ctrl = require('../controllers/feeController');

const router = express.Router();

router.use(protect, requireSchool);

router.get('/fees', authorize(...FINANCE_ROLES, ROLES.STUDENT, ROLES.PARENT), ctrl.getFees);
router.post('/fees', authorize(...FINANCE_ROLES), ctrl.createFee);
router.put('/fees/:id', authorize(...FINANCE_ROLES), ctrl.updateFee);
router.delete('/fees/:id', authorize(...FINANCE_ROLES), ctrl.deleteFee);

router.get('/payments', authorize(...FINANCE_ROLES, ROLES.STUDENT, ROLES.PARENT), ctrl.getPayments);
router.post('/payments', authorize(...FINANCE_ROLES), ctrl.recordPayment);
router.get('/payments/:id/receipt', authorize(...FINANCE_ROLES, ROLES.STUDENT, ROLES.PARENT), ctrl.downloadReceipt);
router.post('/fees/:id/pay-online', authorize(...FINANCE_ROLES, ROLES.STUDENT, ROLES.PARENT), ctrl.initiateOnlinePayment);
router.post('/fees/:id/remind', authorize(...FINANCE_ROLES), ctrl.sendFeeReminder);

module.exports = router;
