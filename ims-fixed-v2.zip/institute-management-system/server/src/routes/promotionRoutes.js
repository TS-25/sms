const express = require('express');
const { protect, authorize, requireSchool } = require('../middleware/auth');
const { ADMIN_LIKE } = require('../config/roles');
const ctrl = require('../controllers/promotionController');

const router = express.Router();

router.use(protect, requireSchool, authorize(...ADMIN_LIKE));

router.post('/promote', ctrl.promoteStudents);
router.post('/repeat', ctrl.repeatStudents);
router.post('/transfer/:studentId', ctrl.transferStudent);
router.post('/graduate', ctrl.graduateStudents);
router.get('/history/:studentId', ctrl.getStudentHistory);

module.exports = router;
