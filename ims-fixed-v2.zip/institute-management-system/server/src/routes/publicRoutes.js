const express = require('express');
const cmsCtrl = require('../controllers/cmsController');
const galleryCtrl = require('../controllers/galleryController');
const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const School = require('../models/School');
const Notice = require('../models/Notice');
const Event = require('../models/Event');
const SchoolSettings = require('../models/SchoolSettings');

const router = express.Router();

// GET /api/public/institutes/:slug — basic identity for a public site (#42)
router.get('/institutes/:slug', asyncHandler(async (req, res) => {
  const school = await School.findOne({ slug: req.params.slug, isActive: true });
  if (!school) throw new ApiError(404, 'Institute not found.');
  const settings = await SchoolSettings.findOne({ school: school._id }).select('schoolName logoUrl address phone email website');
  res.json({ success: true, data: settings || { schoolName: school.name } });
}));

// GET /api/public/institutes/:slug/notices — published, non-expired only
router.get('/institutes/:slug/notices', asyncHandler(async (req, res) => {
  const school = await School.findOne({ slug: req.params.slug, isActive: true });
  if (!school) throw new ApiError(404, 'Institute not found.');
  const now = new Date();
  const notices = await Notice.find({
    school: school._id,
    targetAudience: 'everyone',
    publishDate: { $lte: now },
    $or: [{ expiryDate: null }, { expiryDate: { $gte: now } }, { expiryDate: { $exists: false } }],
  }).sort({ publishDate: -1 }).limit(20);
  res.json({ success: true, data: notices });
}));

// GET /api/public/institutes/:slug/events
router.get('/institutes/:slug/events', asyncHandler(async (req, res) => {
  const school = await School.findOne({ slug: req.params.slug, isActive: true });
  if (!school) throw new ApiError(404, 'Institute not found.');
  const events = await Event.find({ school: school._id, startDate: { $gte: new Date() } }).sort({ startDate: 1 }).limit(20);
  res.json({ success: true, data: events });
}));

router.get('/institutes/:slug/pages/:pageSlug', cmsCtrl.getPublicPage);
router.get('/institutes/:slug/gallery', galleryCtrl.getPublicGallery);

module.exports = router;
