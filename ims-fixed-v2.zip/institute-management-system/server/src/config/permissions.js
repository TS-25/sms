// Static catalog of fine-grained permission strings the app understands.
// This is additive to the fixed ROLES system (config/roles.js), not a
// replacement — it lets a school grant specific capabilities to staff-type
// accounts (e.g. a receptionist who should also see fee status) without
// inventing a whole new fixed role for every combination.
//
// `admin` always has every permission implicitly (see utils/permissions.js)
// and never needs a custom role. Everyone else only gets a permission if
// it's on their assigned custom Role document.
const PERMISSION_CATALOG = [
  { group: 'Students', permissions: ['students.view', 'students.create', 'students.edit', 'students.delete'] },
  { group: 'Teachers', permissions: ['teachers.view', 'teachers.create', 'teachers.edit', 'teachers.delete'] },
  { group: 'Fees', permissions: ['fees.view', 'fees.create', 'fees.collect'] },
  { group: 'Attendance', permissions: ['attendance.view', 'attendance.manage'] },
  { group: 'Results', permissions: ['results.view', 'results.manage', 'results.publish'] },
  { group: 'Library', permissions: ['library.view', 'library.manage'] },
  { group: 'Transport', permissions: ['transport.view', 'transport.manage'] },
  { group: 'Hostel', permissions: ['hostel.view', 'hostel.manage'] },
  { group: 'Reports', permissions: ['reports.export'] },
  { group: 'Notices', permissions: ['notices.create'] },
  { group: 'Health Records', permissions: ['health.view', 'health.manage'] },
  { group: 'Discipline', permissions: ['discipline.view', 'discipline.manage'] },
];

const ALL_PERMISSIONS = PERMISSION_CATALOG.flatMap((g) => g.permissions);

module.exports = { PERMISSION_CATALOG, ALL_PERMISSIONS };
