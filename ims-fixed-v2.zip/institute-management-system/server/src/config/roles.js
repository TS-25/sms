// Central role definitions used across the app (auth, seed data, middleware).
// Extend this list to add new roles (e.g. librarian, receptionist) — the RBAC
// middleware and User model are driven entirely by this list, so no other
// code needs to change to introduce a new role name.
//
// Multi-tenancy note: SUPER_ADMIN is a PLATFORM-level role (manages schools
// themselves — see platformController.js) and has no `school` on their User
// document. Every other role belongs to exactly one school and is scoped to
// it everywhere. ADMIN is the highest authority *within* a single school.

const ROLES = Object.freeze({
  SUPER_ADMIN: 'super_admin',
  ADMIN: 'admin',
  PRINCIPAL: 'principal',
  TEACHER: 'teacher',
  STUDENT: 'student',
  PARENT: 'parent',
  ACCOUNTANT: 'accountant',
  LIBRARIAN: 'librarian',
  RECEPTIONIST: 'receptionist',
  STAFF: 'staff',
});

const ALL_ROLES = Object.values(ROLES);

// Roles allowed to manage core academic/administrative data within a school.
// Deliberately excludes SUPER_ADMIN, which operates at the platform level
// and is not scoped to any single school's data.
const ADMIN_LIKE = [ROLES.ADMIN, ROLES.PRINCIPAL];

// Roles allowed to manage finances.
const FINANCE_ROLES = [ROLES.ADMIN, ROLES.ACCOUNTANT];

module.exports = { ROLES, ALL_ROLES, ADMIN_LIKE, FINANCE_ROLES };
