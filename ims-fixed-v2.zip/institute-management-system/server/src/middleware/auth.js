const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { verifyAccessToken } = require('../utils/tokens');
const { userHasPermission } = require('../utils/permissions');
const User = require('../models/User');
const School = require('../models/School');

// Verifies the JWT access token from the Authorization header and attaches
// the authenticated user to req.user, plus req.schoolId/req.school for
// tenant scoping and feature-flag checks.
const protect = asyncHandler(async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    throw new ApiError(401, 'Not authenticated. No token provided.');
  }

  const token = authHeader.split(' ')[1];
  let decoded;
  try {
    decoded = verifyAccessToken(token);
  } catch (err) {
    throw new ApiError(401, 'Invalid or expired token.');
  }

  const user = await User.findById(decoded.id);
  if (!user) throw new ApiError(401, 'User belonging to this token no longer exists.');
  if (!user.isActive) throw new ApiError(403, 'This account has been deactivated.');

  req.user = user;
  // Every tenant-scoped controller should filter by this, e.g.
  // Student.find({ school: req.schoolId, ...otherFilters }). It's null for
  // SUPER_ADMIN, who operates at the platform level across all schools —
  // see requireSchool() below and platformController.js.
  req.schoolId = user.school || null;

  if (req.schoolId) {
    req.school = await School.findById(req.schoolId);
    if (!req.school || !req.school.isActive) {
      throw new ApiError(403, "This school's account is not active. Contact the platform administrator.");
    }
  }

  next();
});

// Guards routes that operate on a single school's data (i.e. almost
// everything except the platform/:schools endpoints). SUPER_ADMIN has no
// school of their own, so without this check their requests would silently
// filter to `school: null` and either see nothing or, worse, match
// documents that were incorrectly saved without a school — this turns
// that into a clear 403 instead.
const requireSchool = (req, res, next) => {
  if (!req.schoolId) {
    throw new ApiError(
      403,
      'This action requires a school context. Platform-level accounts should use the /platform endpoints instead.'
    );
  }
  next();
};

// Enforces a feature flag server-side (#81, #83) — hiding a disabled
// module from the sidebar isn't enough on its own, since someone could
// still call the API directly. Usage: requireModule('library').
const requireModule = (moduleName) => (req, res, next) => {
  if (req.school && req.school.enabledModules?.[moduleName] === false) {
    throw new ApiError(403, `The "${moduleName}" module is disabled for this school.`);
  }
  next();
};

// Grants access if EITHER the user's fixed role is in `roles` OR they hold
// the given fine-grained permission via a custom Role (see
// config/permissions.js). Lets a school extend, say, a receptionist with
// `fees.view` without inventing a whole new fixed role.
const authorizeOrPermission = (roles, permission) => asyncHandler(async (req, res, next) => {
  if (roles.includes(req.user.role)) return next();
  if (await userHasPermission(req.user, permission)) return next();
  throw new ApiError(403, 'You do not have permission to perform this action.');
});

// Restricts a route to a specific set of roles.
// Usage: authorize('admin', 'super_admin')
const authorize = (...allowedRoles) => (req, res, next) => {
  if (!req.user) throw new ApiError(401, 'Not authenticated.');
  if (!allowedRoles.includes(req.user.role)) {
    throw new ApiError(403, 'You do not have permission to perform this action.');
  }
  next();
};

module.exports = { protect, authorize, requireSchool, requireModule, authorizeOrPermission };
