const crypto = require('crypto');
const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const User = require('../models/User');
const LoginAttempt = require('../models/LoginAttempt');
const Session = require('../models/Session');
const {
  generateAccessToken,
  generateRefreshToken,
  verifyRefreshToken,
} = require('../utils/tokens');
const { sendTemplatedEmail } = require('../services/emailService');
const { generateSecret, generateTOTP, verifyTOTP, generateRecoveryCodes, getSetupUri } = require('../utils/totp');
const { parseUserAgent } = require('../utils/parseUserAgent');
const logAction = require('../utils/logAction');

const recordAttempt = (data) => LoginAttempt.create(data).catch((err) => console.error('LoginAttempt log failure:', err.message));

// The refresh-token cookie's secure/sameSite attributes must match how the
// request actually arrived, not just NODE_ENV. If NODE_ENV=production but
// the app is served over plain HTTP (e.g. local Docker on localhost), a
// hardcoded `secure: true` + `sameSite: 'none'` cookie is silently dropped
// by the browser — login appears to work, then every refresh/reload logs
// the user back out. req.secure is accurate here because app.js sets
// `app.set('trust proxy', 1)`, so this works correctly both for plain HTTP
// (local/Docker) and for real HTTPS deployments behind a reverse proxy.
const getCookieOptions = (req) => ({
  httpOnly: true,
  secure: req.secure,
  sameSite: req.secure ? 'none' : 'lax',
  maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
});

// POST /api/auth/login
// Note: email is globally unique across the whole platform (not scoped per
// school) specifically so this lookup is unambiguous — login has no
// separate "which school" step. The tradeoff: the same person can't hold
// two accounts with the same email at two different schools. A future
// subdomain-per-school routing scheme could relax this if needed.
const login = asyncHandler(async (req, res) => {
  const { email, password, totpCode } = req.body;
  const ip = req.ip;
  const userAgent = req.headers['user-agent'];

  const user = await User.findOne({ email: email.toLowerCase() }).select('+password +twoFactorSecret +twoFactorRecoveryCodes');
  if (!user) {
    await recordAttempt({ email, success: false, reason: 'no_such_user', ip, userAgent });
    throw new ApiError(401, 'Invalid email or password.');
  }
  if (!user.isActive) {
    await recordAttempt({ school: user.school, email, success: false, reason: 'account_deactivated', ip, userAgent });
    throw new ApiError(403, 'This account has been deactivated.');
  }

  const isMatch = await user.comparePassword(password);
  if (!isMatch) {
    await recordAttempt({ school: user.school, email, success: false, reason: 'wrong_password', ip, userAgent });
    throw new ApiError(401, 'Invalid email or password.');
  }

  if (user.twoFactorEnabled) {
    if (!totpCode) {
      // Not a failure exactly — the client should now prompt for the code
      // and resubmit. Distinguishing this from a hard failure lets the
      // frontend show "Enter your 2FA code" instead of "wrong password".
      return res.status(200).json({ success: true, data: { twoFactorRequired: true } });
    }
    const isValidCode = verifyTOTP(user.twoFactorSecret, totpCode) || user.twoFactorRecoveryCodes.includes(totpCode);
    if (!isValidCode) {
      await recordAttempt({ school: user.school, email, success: false, reason: 'bad_2fa_code', ip, userAgent });
      throw new ApiError(401, 'Invalid two-factor authentication code.');
    }
    if (user.twoFactorRecoveryCodes.includes(totpCode)) {
      // Recovery codes are single-use.
      user.twoFactorRecoveryCodes = user.twoFactorRecoveryCodes.filter((c) => c !== totpCode);
    }
  }

  user.lastLoginAt = new Date();
  await user.save();

  const accessToken = generateAccessToken(user);
  const { token: refreshToken, jti } = generateRefreshToken(user);

  const { browser, device } = parseUserAgent(userAgent);
  await Session.create({
    school: user.school,
    user: user._id,
    tokenId: jti,
    device,
    browser,
    ip,
  });

  res.cookie('refreshToken', refreshToken, getCookieOptions(req));
  await recordAttempt({ school: user.school, email, success: true, ip, userAgent });
  await logAction({ user, action: 'login', entity: 'User', entityId: user._id, req });

  res.json({
    success: true,
    data: { user: user.toSafeObject(), accessToken },
  });
});

// POST /api/auth/refresh
const refresh = asyncHandler(async (req, res) => {
  const token = req.cookies?.refreshToken || req.body?.refreshToken;
  if (!token) throw new ApiError(401, 'No refresh token provided.');

  let decoded;
  try {
    decoded = verifyRefreshToken(token);
  } catch (err) {
    throw new ApiError(401, 'Invalid or expired refresh token.');
  }

  const user = await User.findById(decoded.id);
  if (!user || !user.isActive) throw new ApiError(401, 'User not found or deactivated.');

  // Honor session revocation (#87) — if this specific session was revoked
  // (e.g. via "log out of other devices"), the refresh token itself is
  // still cryptographically valid until it expires, so we must check the
  // Session record too, not just the JWT signature.
  if (decoded.jti) {
    const session = await Session.findOne({ tokenId: decoded.jti });
    if (!session || session.revoked) {
      throw new ApiError(401, 'This session has been revoked. Please log in again.');
    }
    session.lastActiveAt = new Date();
    await session.save();
  }

  const accessToken = generateAccessToken(user);
  res.json({ success: true, data: { accessToken } });
});

// POST /api/auth/logout
const logout = asyncHandler(async (req, res) => {
  const token = req.cookies?.refreshToken;
  if (token) {
    try {
      const decoded = verifyRefreshToken(token);
      if (decoded.jti) await Session.findOneAndUpdate({ tokenId: decoded.jti }, { revoked: true });
    } catch {
      // Token already invalid/expired — nothing to revoke.
    }
  }
  res.clearCookie('refreshToken', getCookieOptions(req));
  res.json({ success: true, message: 'Logged out successfully.' });
});

// GET /api/auth/me
const getMe = asyncHandler(async (req, res) => {
  res.json({ success: true, data: { user: req.user.toSafeObject() } });
});

// POST /api/auth/change-password
const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const user = await User.findById(req.user._id).select('+password');
  const isMatch = await user.comparePassword(currentPassword);
  if (!isMatch) throw new ApiError(400, 'Current password is incorrect.');

  user.password = newPassword;
  await user.save();
  res.json({ success: true, message: 'Password changed successfully.' });
});

// POST /api/auth/forgot-password
const forgotPassword = asyncHandler(async (req, res) => {
  const { email } = req.body;
  const user = await User.findOne({ email: email.toLowerCase() });

  // Always respond the same way to avoid leaking which emails are registered.
  const genericResponse = {
    success: true,
    message: 'If an account with that email exists, a reset link has been sent.',
  };
  if (!user) return res.json(genericResponse);

  const resetToken = crypto.randomBytes(32).toString('hex');
  user.resetPasswordToken = crypto.createHash('sha256').update(resetToken).digest('hex');
  user.resetPasswordExpires = Date.now() + 30 * 60 * 1000; // 30 minutes
  await user.save();

  const resetUrl = `${process.env.CLIENT_URL}/reset-password/${resetToken}`;
  await sendTemplatedEmail({
    schoolId: user.school,
    type: 'password_reset',
    to: user.email,
    variables: { resetUrl },
  });

  res.json(genericResponse);
});

// POST /api/auth/reset-password/:token
const resetPassword = asyncHandler(async (req, res) => {
  const hashedToken = crypto.createHash('sha256').update(req.params.token).digest('hex');
  const user = await User.findOne({
    resetPasswordToken: hashedToken,
    resetPasswordExpires: { $gt: Date.now() },
  }).select('+resetPasswordToken +resetPasswordExpires');

  if (!user) throw new ApiError(400, 'Invalid or expired reset token.');

  user.password = req.body.password;
  user.resetPasswordToken = undefined;
  user.resetPasswordExpires = undefined;
  await user.save();

  res.json({ success: true, message: 'Password has been reset. You can now log in.' });
});

// POST /api/auth/2fa/setup — generates a new secret + QR setup URI. Not
// yet enabled until confirmed via /2fa/verify (below), so a user can't
// accidentally lock themselves out by generating a secret they never
// actually saved into their authenticator app.
const setup2FA = asyncHandler(async (req, res) => {
  const secret = generateSecret();
  const user = await User.findById(req.user._id);
  user.twoFactorSecret = secret; // not enabled yet — see verify2FA
  await user.save();

  const setupUri = getSetupUri({ secret, accountName: user.email, issuer: 'Institute Management System' });
  res.json({ success: true, data: { secret, setupUri } });
});

// POST /api/auth/2fa/verify  body: { totpCode }
// Confirms the user actually has the secret in their authenticator app
// before flipping twoFactorEnabled on, and issues one-time recovery codes.
const verify2FA = asyncHandler(async (req, res) => {
  const { totpCode } = req.body;
  const user = await User.findById(req.user._id).select('+twoFactorSecret');
  if (!user.twoFactorSecret) throw new ApiError(400, 'Call /2fa/setup first.');

  if (!verifyTOTP(user.twoFactorSecret, totpCode)) {
    throw new ApiError(400, 'Invalid code. Check your authenticator app and try again.');
  }

  const recoveryCodes = generateRecoveryCodes();
  user.twoFactorEnabled = true;
  user.twoFactorRecoveryCodes = recoveryCodes;
  await user.save();

  await logAction({ user, action: 'enabled_2fa', entity: 'User', entityId: user._id, req });
  res.json({ success: true, data: { recoveryCodes } });
});

// POST /api/auth/2fa/disable  body: { password }
const disable2FA = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).select('+password');
  const isMatch = await user.comparePassword(req.body.password);
  if (!isMatch) throw new ApiError(400, 'Incorrect password.');

  user.twoFactorEnabled = false;
  user.twoFactorSecret = undefined;
  user.twoFactorRecoveryCodes = [];
  await user.save();

  await logAction({ user, action: 'disabled_2fa', entity: 'User', entityId: user._id, req });
  res.json({ success: true, message: 'Two-factor authentication disabled.' });
});

module.exports = {
  login,
  refresh,
  logout,
  getMe,
  changePassword,
  forgotPassword,
  resetPassword,
  setup2FA,
  verify2FA,
  disable2FA,
};
