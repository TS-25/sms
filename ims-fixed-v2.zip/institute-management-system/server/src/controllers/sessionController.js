const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Session = require('../models/Session');
const { verifyRefreshToken } = require('../utils/tokens');

// GET /api/sessions — the current user's own active sessions/devices (#87)
const getMySessions = asyncHandler(async (req, res) => {
  const sessions = await Session.find({ user: req.user._id, revoked: false }).sort({ lastActiveAt: -1 });

  // Mark which one is the session making this very request, so the UI can
  // label it "This device" and skip offering to revoke it accidentally.
  let currentTokenId = null;
  const cookieToken = req.cookies?.refreshToken;
  if (cookieToken) {
    try {
      currentTokenId = verifyRefreshToken(cookieToken).jti;
    } catch {
      // Expired/invalid — just won't be flagged as current, harmless.
    }
  }

  res.json({
    success: true,
    data: sessions.map((s) => ({ ...s.toObject(), isCurrent: s.tokenId === currentTokenId })),
  });
});

// DELETE /api/sessions/:id — revoke one specific session
const revokeSession = asyncHandler(async (req, res) => {
  const session = await Session.findOneAndUpdate(
    { _id: req.params.id, user: req.user._id },
    { revoked: true },
    { new: true }
  );
  if (!session) throw new ApiError(404, 'Session not found.');
  res.json({ success: true, message: 'Session revoked.' });
});

// DELETE /api/sessions — "log out of all other devices". Reads the current
// session from the request's own refresh-token cookie server-side (never
// trusts the client to say which session is "current").
const revokeAllOtherSessions = asyncHandler(async (req, res) => {
  let currentTokenId = null;
  const cookieToken = req.cookies?.refreshToken;
  if (cookieToken) {
    try {
      currentTokenId = verifyRefreshToken(cookieToken).jti;
    } catch {
      // Expired/invalid — proceed revoking everything, nothing to protect.
    }
  }

  await Session.updateMany(
    { user: req.user._id, revoked: false, tokenId: { $ne: currentTokenId } },
    { revoked: true }
  );
  res.json({ success: true, message: 'All other sessions have been logged out.' });
});

module.exports = { getMySessions, revokeSession, revokeAllOtherSessions };
