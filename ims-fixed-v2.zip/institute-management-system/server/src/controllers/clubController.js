const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Club = require('../models/Club');

const getClubs = asyncHandler(async (req, res) => {
  const clubs = await Club.find({ school: req.schoolId }).populate('teacher', 'firstName lastName').populate('members', 'firstName lastName admissionNumber');
  res.json({ success: true, data: clubs });
});

const createClub = asyncHandler(async (req, res) => {
  const club = await Club.create({ ...req.body, school: req.schoolId });
  res.status(201).json({ success: true, data: club });
});

const updateClub = asyncHandler(async (req, res) => {
  const club = await Club.findOneAndUpdate({ _id: req.params.id, school: req.schoolId }, req.body, { new: true, runValidators: true });
  if (!club) throw new ApiError(404, 'Club not found.');
  res.json({ success: true, data: club });
});

const deleteClub = asyncHandler(async (req, res) => {
  const club = await Club.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!club) throw new ApiError(404, 'Club not found.');
  res.json({ success: true, message: 'Club deleted.' });
});

const addActivity = asyncHandler(async (req, res) => {
  const club = await Club.findOne({ _id: req.params.id, school: req.schoolId });
  if (!club) throw new ApiError(404, 'Club not found.');
  club.activities.push(req.body);
  await club.save();
  res.status(201).json({ success: true, data: club });
});

module.exports = { getClubs, createClub, updateClub, deleteClub, addActivity };
