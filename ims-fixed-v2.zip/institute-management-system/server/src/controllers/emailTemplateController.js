const asyncHandler = require('../utils/asyncHandler');
const EmailTemplate = require('../models/EmailTemplate');
const { DEFAULT_TEMPLATES, sendTestEmail } = require('../services/emailService');

// GET /api/email-templates — all known types, using the institute's
// customized version where one exists, and the built-in default otherwise
// (so the UI always has something sensible to show/edit).
const getTemplates = asyncHandler(async (req, res) => {
  const custom = await EmailTemplate.find({ school: req.schoolId });
  const customByType = Object.fromEntries(custom.map((t) => [t.type, t]));

  const merged = Object.entries(DEFAULT_TEMPLATES).map(([type, def]) => ({
    type,
    subject: customByType[type]?.subject || def.subject,
    body: customByType[type]?.body || def.body,
    isCustomized: !!customByType[type],
  }));

  res.json({ success: true, data: merged });
});

// PUT /api/email-templates/:type  body: { subject, body }
const upsertTemplate = asyncHandler(async (req, res) => {
  const { subject, body } = req.body;
  const template = await EmailTemplate.findOneAndUpdate(
    { school: req.schoolId, type: req.params.type },
    { subject, body },
    { new: true, upsert: true, runValidators: true }
  );
  res.json({ success: true, data: template });
});

// DELETE /api/email-templates/:type — revert to the built-in default
const resetTemplate = asyncHandler(async (req, res) => {
  await EmailTemplate.findOneAndDelete({ school: req.schoolId, type: req.params.type });
  res.json({ success: true, message: 'Reverted to default template.' });
});

// POST /api/email-templates/send-test  body: { to }
const sendTest = asyncHandler(async (req, res) => {
  await sendTestEmail({ schoolId: req.schoolId, to: req.body.to || req.user.email });
  res.json({ success: true, message: `Test email sent to ${req.body.to || req.user.email}.` });
});

module.exports = { getTemplates, upsertTemplate, resetTemplate, sendTest };
