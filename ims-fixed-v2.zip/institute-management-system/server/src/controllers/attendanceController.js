const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Attendance = require('../models/Attendance');
const { toCsv } = require('../services/csvService');

// POST /api/attendance/mark  — bulk mark attendance for a class/section/date
const markAttendance = asyncHandler(async (req, res) => {
  const { class: classId, section, date, records } = req.body;
  if (!Array.isArray(records) || records.length === 0) {
    throw new ApiError(400, 'records array is required.');
  }

  const day = new Date(date);
  const ops = records.map((r) => ({
    updateOne: {
      filter: { student: r.student, date: day, school: req.schoolId },
      update: {
        $set: {
          school: req.schoolId,
          student: r.student,
          class: classId,
          section,
          date: day,
          status: r.status,
          remarks: r.remarks,
          markedBy: req.user._id,
        },
      },
      upsert: true,
    },
  }));

  await Attendance.bulkWrite(ops);
  res.json({ success: true, message: `Attendance marked for ${records.length} student(s).` });
});

// GET /api/attendance?class=&section=&date=
const getAttendanceByDate = asyncHandler(async (req, res) => {
  const { class: classId, section, date } = req.query;
  if (!classId || !section || !date) throw new ApiError(400, 'class, section and date are required.');

  const day = new Date(date);
  const attendance = await Attendance.find({ class: classId, section, date: day, school: req.schoolId }).populate(
    'student',
    'firstName lastName admissionNumber rollNumber'
  );
  res.json({ success: true, data: attendance });
});

// GET /api/attendance/student/:studentId?from=&to=
const getStudentAttendance = asyncHandler(async (req, res) => {
  const { from, to } = req.query;
  const filter = { student: req.params.studentId, school: req.schoolId };
  if (from || to) {
    filter.date = {};
    if (from) filter.date.$gte = new Date(from);
    if (to) filter.date.$lte = new Date(to);
  }

  const records = await Attendance.find(filter).sort({ date: -1 });
  const total = records.length;
  const present = records.filter((r) => r.status === 'present').length;
  const percentage = total > 0 ? Math.round((present / total) * 10000) / 100 : 0;

  res.json({ success: true, data: { records, summary: { total, present, percentage } } });
});

// GET /api/attendance/export/csv?class=&section=&date=
const exportAttendanceCsv = asyncHandler(async (req, res) => {
  const { class: classId, section, date } = req.query;
  const filter = { school: req.schoolId };
  if (classId) filter.class = classId;
  if (section) filter.section = section;
  if (date) filter.date = new Date(date);

  const records = await Attendance.find(filter)
    .populate('student', 'firstName lastName admissionNumber')
    .lean();

  const rows = records.map((r) => ({
    date: new Date(r.date).toISOString().slice(0, 10),
    admissionNumber: r.student?.admissionNumber,
    name: `${r.student?.firstName || ''} ${r.student?.lastName || ''}`.trim(),
    status: r.status,
  }));

  const csv = toCsv(rows, ['date', 'admissionNumber', 'name', 'status']);
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename=attendance.csv');
  res.send(csv);
});

module.exports = { markAttendance, getAttendanceByDate, getStudentAttendance, exportAttendanceCsv };
