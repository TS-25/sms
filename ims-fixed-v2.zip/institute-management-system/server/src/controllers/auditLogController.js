const asyncHandler = require('../utils/asyncHandler');
const AuditLog = require('../models/AuditLog');

// GET /api/audit-logs?entity=&user=&page=&limit=
const getAuditLogs = asyncHandler(async (req, res) => {
  const { entity, user, page = 1, limit = 50 } = req.query;
  const filter = { school: req.schoolId };
  if (entity) filter.entity = entity;
  if (user) filter.user = user;

  const skip = (Number(page) - 1) * Number(limit);
  const [logs, total] = await Promise.all([
    AuditLog.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    AuditLog.countDocuments(filter),
  ]);

  res.json({ success: true, data: logs, pagination: { total, page: Number(page), limit: Number(limit) } });
});

module.exports = { getAuditLogs };
