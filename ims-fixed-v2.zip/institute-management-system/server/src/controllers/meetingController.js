const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const MeetingSlot = require('../models/MeetingSlot');

// GET /api/meetings?teacher=&status=
const getSlots = asyncHandler(async (req, res) => {
  const { teacher, status } = req.query;
  const filter = { school: req.schoolId };
  if (teacher) filter.teacher = teacher;
  if (status) filter.status = status;
  const slots = await MeetingSlot.find(filter)
    .populate('teacher', 'firstName lastName')
    .populate('bookedBy', 'name')
    .populate('student', 'firstName lastName')
    .sort({ startTime: 1 });
  res.json({ success: true, data: slots });
});

// POST /api/meetings  body: { teacher, startTime, endTime } — teacher opens a slot
const createSlot = asyncHandler(async (req, res) => {
  const slot = await MeetingSlot.create({ ...req.body, school: req.schoolId });
  res.status(201).json({ success: true, data: slot });
});

// POST /api/meetings/:id/book  body: { student, notes } — parent books it
const bookSlot = asyncHandler(async (req, res) => {
  const slot = await MeetingSlot.findOne({ _id: req.params.id, school: req.schoolId });
  if (!slot) throw new ApiError(404, 'Meeting slot not found.');
  if (slot.isBooked) throw new ApiError(400, 'This slot has already been booked.');

  slot.isBooked = true;
  slot.status = 'booked';
  slot.bookedBy = req.user._id;
  slot.student = req.body.student;
  slot.notes = req.body.notes;
  await slot.save();

  res.json({ success: true, data: slot });
});

// PATCH /api/meetings/:id/cancel
const cancelSlot = asyncHandler(async (req, res) => {
  const slot = await MeetingSlot.findOneAndUpdate(
    { _id: req.params.id, school: req.schoolId },
    { isBooked: false, status: 'cancelled', bookedBy: null, student: null },
    { new: true }
  );
  if (!slot) throw new ApiError(404, 'Meeting slot not found.');
  res.json({ success: true, data: slot });
});

const deleteSlot = asyncHandler(async (req, res) => {
  const slot = await MeetingSlot.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!slot) throw new ApiError(404, 'Meeting slot not found.');
  res.json({ success: true, message: 'Slot deleted.' });
});

module.exports = { getSlots, createSlot, bookSlot, cancelSlot, deleteSlot };
