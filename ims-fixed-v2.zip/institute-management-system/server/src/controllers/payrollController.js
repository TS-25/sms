const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const SalaryStructure = require('../models/SalaryStructure');
const Payslip = require('../models/Payslip');

// GET /api/payroll/structures
const getStructures = asyncHandler(async (req, res) => {
  const structures = await SalaryStructure.find({ school: req.schoolId });
  res.json({ success: true, data: structures });
});

// POST /api/payroll/structures  body: { employee, employeeModel, basicSalary, allowances, deductions }
const upsertStructure = asyncHandler(async (req, res) => {
  const { employee, employeeModel, basicSalary, allowances, deductions } = req.body;
  const structure = await SalaryStructure.findOneAndUpdate(
    { employee, school: req.schoolId },
    { employeeModel, basicSalary, allowances, deductions, school: req.schoolId },
    { new: true, upsert: true, runValidators: true }
  );
  res.json({ success: true, data: structure });
});

// POST /api/payroll/generate  body: { month, year }
// Generates a payslip for every employee with a salary structure, for the
// given month — skips anyone who already has one for that month/year.
const generatePayroll = asyncHandler(async (req, res) => {
  const { month, year } = req.body;
  if (!month || !year) throw new ApiError(400, 'month and year are required.');

  const structures = await SalaryStructure.find({ school: req.schoolId });
  const results = { created: 0, skipped: 0 };

  for (const s of structures) {
    const existing = await Payslip.findOne({ employee: s.employee, month, year, school: req.schoolId });
    if (existing) {
      results.skipped += 1;
      continue;
    }
    const netPay = s.basicSalary + s.allowances - s.deductions;
    await Payslip.create({
      school: req.schoolId,
      employee: s.employee,
      employeeModel: s.employeeModel,
      month,
      year,
      basicSalary: s.basicSalary,
      allowances: s.allowances,
      deductions: s.deductions,
      netPay,
    });
    results.created += 1;
  }

  res.json({ success: true, data: results });
});

// GET /api/payroll/payslips?month=&year=&employee=
const getPayslips = asyncHandler(async (req, res) => {
  const { month, year, employee } = req.query;
  const filter = { school: req.schoolId };
  if (month) filter.month = Number(month);
  if (year) filter.year = Number(year);
  if (employee) filter.employee = employee;

  const payslips = await Payslip.find(filter).sort({ year: -1, month: -1 });
  res.json({ success: true, data: payslips });
});

// PATCH /api/payroll/payslips/:id/pay
const markPaid = asyncHandler(async (req, res) => {
  const payslip = await Payslip.findOneAndUpdate(
    { _id: req.params.id, school: req.schoolId },
    { status: 'paid', paidAt: new Date() },
    { new: true }
  );
  if (!payslip) throw new ApiError(404, 'Payslip not found.');
  res.json({ success: true, data: payslip });
});

module.exports = { getStructures, upsertStructure, generatePayroll, getPayslips, markPaid };
