const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Expense = require('../models/Expense');

const getExpenses = asyncHandler(async (req, res) => {
  const { category, from, to, page = 1, limit = 20 } = req.query;
  const filter = { school: req.schoolId };
  if (category) filter.category = category;
  if (from || to) {
    filter.date = {};
    if (from) filter.date.$gte = new Date(from);
    if (to) filter.date.$lte = new Date(to);
  }

  const skip = (Number(page) - 1) * Number(limit);
  const [expenses, total] = await Promise.all([
    Expense.find(filter).sort({ date: -1 }).skip(skip).limit(Number(limit)),
    Expense.countDocuments(filter),
  ]);

  res.json({ success: true, data: expenses, pagination: { total, page: Number(page), limit: Number(limit) } });
});

const createExpense = asyncHandler(async (req, res) => {
  const expense = await Expense.create({ ...req.body, school: req.schoolId, recordedBy: req.user._id });
  res.status(201).json({ success: true, data: expense });
});

const updateExpense = asyncHandler(async (req, res) => {
  const expense = await Expense.findOneAndUpdate({ _id: req.params.id, school: req.schoolId }, req.body, { new: true, runValidators: true });
  if (!expense) throw new ApiError(404, 'Expense not found.');
  res.json({ success: true, data: expense });
});

const deleteExpense = asyncHandler(async (req, res) => {
  const expense = await Expense.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!expense) throw new ApiError(404, 'Expense not found.');
  res.json({ success: true, message: 'Expense deleted.' });
});

module.exports = { getExpenses, createExpense, updateExpense, deleteExpense };
