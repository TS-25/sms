const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Leave = require('../models/Leave');

const getLeaves = asyncHandler(async (req, res) => {
  const { applicant, status, page = 1, limit = 20 } = req.query;
  const filter = { school: req.schoolId };
  if (applicant) filter.applicant = applicant;
  if (status) filter.status = status;

  const skip = (Number(page) - 1) * Number(limit);
  const [leaves, total] = await Promise.all([
    Leave.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Leave.countDocuments(filter),
  ]);

  res.json({ success: true, data: leaves, pagination: { total, page: Number(page), limit: Number(limit) } });
});

const applyLeave = asyncHandler(async (req, res) => {
  const leave = await Leave.create({ ...req.body, school: req.schoolId });
  res.status(201).json({ success: true, data: leave });
});

const reviewLeave = asyncHandler(async (req, res) => {
  const { status, reviewNote } = req.body;
  if (!['approved', 'rejected'].includes(status)) throw new ApiError(400, 'status must be approved or rejected.');

  const leave = await Leave.findOneAndUpdate(
    { _id: req.params.id, school: req.schoolId },
    { status, reviewNote, reviewedBy: req.user._id },
    { new: true }
  );
  if (!leave) throw new ApiError(404, 'Leave request not found.');
  res.json({ success: true, data: leave });
});

const deleteLeave = asyncHandler(async (req, res) => {
  const leave = await Leave.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!leave) throw new ApiError(404, 'Leave request not found.');
  res.json({ success: true, message: 'Leave request deleted.' });
});

module.exports = { getLeaves, applyLeave, reviewLeave, deleteLeave };
