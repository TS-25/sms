const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Student = require('../models/Student');
const Teacher = require('../models/Teacher');
const SchoolSettings = require('../models/SchoolSettings');
const { generateIdCardPDF } = require('../services/pdfService');

const studentIdCard = asyncHandler(async (req, res) => {
  const student = await Student.findOne({ _id: req.params.studentId, school: req.schoolId }).populate('class section');
  if (!student) throw new ApiError(404, 'Student not found.');
  const school = await SchoolSettings.findOne({ school: req.schoolId });

  generateIdCardPDF(res, {
    school,
    person: { fullName: student.fullName, phone: student.phone },
    role: 'Student',
    idLabel: student.admissionNumber,
    classSection: `${student.class?.name || ''} / ${student.section?.name || ''}`,
  });
});

const teacherIdCard = asyncHandler(async (req, res) => {
  const teacher = await Teacher.findOne({ _id: req.params.teacherId, school: req.schoolId });
  if (!teacher) throw new ApiError(404, 'Teacher not found.');
  const school = await SchoolSettings.findOne({ school: req.schoolId });

  generateIdCardPDF(res, {
    school,
    person: { fullName: teacher.fullName, phone: teacher.phone },
    role: teacher.designation || 'Teacher',
    idLabel: teacher.employeeId,
  });
});

module.exports = { studentIdCard, teacherIdCard };
