// Groups several smaller student-record features together (achievements,
// merit points, discipline, health) since each is a small CRUD around a
// single student — keeping them in one file avoids a proliferation of
// near-identical tiny controller files.
const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Achievement = require('../models/Achievement');
const MeritPoint = require('../models/MeritPoint');
const DisciplineIncident = require('../models/DisciplineIncident');
const HealthRecord = require('../models/HealthRecord');

// ---------- Achievements (#49, #50) ----------
const getAchievements = asyncHandler(async (req, res) => {
  const filter = { school: req.schoolId };
  if (req.query.student) filter.student = req.query.student;
  const achievements = await Achievement.find(filter).populate('student', 'firstName lastName admissionNumber').sort({ date: -1 });
  res.json({ success: true, data: achievements });
});

const createAchievement = asyncHandler(async (req, res) => {
  const achievement = await Achievement.create({ ...req.body, school: req.schoolId, recordedBy: req.user._id });
  res.status(201).json({ success: true, data: achievement });
});

const deleteAchievement = asyncHandler(async (req, res) => {
  const achievement = await Achievement.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!achievement) throw new ApiError(404, 'Achievement not found.');
  res.json({ success: true, message: 'Achievement deleted.' });
});

// ---------- Merit Points (#49) ----------
const getMeritPoints = asyncHandler(async (req, res) => {
  const filter = { school: req.schoolId };
  if (req.query.student) filter.student = req.query.student;
  const points = await MeritPoint.find(filter).populate('student', 'firstName lastName admissionNumber').sort({ createdAt: -1 });
  res.json({ success: true, data: points });
});

const giveMeritPoint = asyncHandler(async (req, res) => {
  const point = await MeritPoint.create({ ...req.body, school: req.schoolId, givenBy: req.user._id });
  res.status(201).json({ success: true, data: point });
});

// GET /api/student-records/merit/leaderboard — top students by total points
const getMeritLeaderboard = asyncHandler(async (req, res) => {
  const leaderboard = await MeritPoint.aggregate([
    { $match: { school: req.schoolId } },
    { $group: { _id: '$student', totalPoints: { $sum: '$points' } } },
    { $sort: { totalPoints: -1 } },
    { $limit: 20 },
    { $lookup: { from: 'students', localField: '_id', foreignField: '_id', as: 'student' } },
    { $unwind: '$student' },
  ]);
  res.json({ success: true, data: leaderboard });
});

// ---------- Discipline (#48) — access gated by 'discipline.view'/'manage' ----------
const getDisciplineIncidents = asyncHandler(async (req, res) => {
  const filter = { school: req.schoolId };
  if (req.query.student) filter.student = req.query.student;
  const incidents = await DisciplineIncident.find(filter).populate('student', 'firstName lastName admissionNumber').sort({ date: -1 });
  res.json({ success: true, data: incidents });
});

const createDisciplineIncident = asyncHandler(async (req, res) => {
  const incident = await DisciplineIncident.create({ ...req.body, school: req.schoolId, recordedBy: req.user._id });
  res.status(201).json({ success: true, data: incident });
});

// ---------- Health Records (#47) — access gated by 'health.view'/'manage' ----------
const getHealthRecord = asyncHandler(async (req, res) => {
  const record = await HealthRecord.findOne({ student: req.params.studentId, school: req.schoolId });
  res.json({ success: true, data: record || null });
});

const upsertHealthRecord = asyncHandler(async (req, res) => {
  const record = await HealthRecord.findOneAndUpdate(
    { student: req.params.studentId, school: req.schoolId },
    { ...req.body, updatedBy: req.user._id },
    { new: true, upsert: true, runValidators: true }
  );
  res.json({ success: true, data: record });
});

module.exports = {
  getAchievements, createAchievement, deleteAchievement,
  getMeritPoints, giveMeritPoint, getMeritLeaderboard,
  getDisciplineIncidents, createDisciplineIncident,
  getHealthRecord, upsertHealthRecord,
};
