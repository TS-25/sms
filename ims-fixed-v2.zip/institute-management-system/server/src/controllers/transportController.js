const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Vehicle = require('../models/Vehicle');
const Route = require('../models/Route');
const StudentTransport = require('../models/StudentTransport');

const getVehicles = asyncHandler(async (req, res) => {
  const vehicles = await Vehicle.find({ school: req.schoolId }).populate('route', 'name');
  res.json({ success: true, data: vehicles });
});

const createVehicle = asyncHandler(async (req, res) => {
  const vehicle = await Vehicle.create({ ...req.body, school: req.schoolId });
  res.status(201).json({ success: true, data: vehicle });
});

const updateVehicle = asyncHandler(async (req, res) => {
  const vehicle = await Vehicle.findOneAndUpdate({ _id: req.params.id, school: req.schoolId }, req.body, { new: true, runValidators: true });
  if (!vehicle) throw new ApiError(404, 'Vehicle not found.');
  res.json({ success: true, data: vehicle });
});

const deleteVehicle = asyncHandler(async (req, res) => {
  const vehicle = await Vehicle.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!vehicle) throw new ApiError(404, 'Vehicle not found.');
  res.json({ success: true, message: 'Vehicle deleted.' });
});

const getRoutes = asyncHandler(async (req, res) => {
  const routes = await Route.find({ school: req.schoolId });
  res.json({ success: true, data: routes });
});

const createRoute = asyncHandler(async (req, res) => {
  const route = await Route.create({ ...req.body, school: req.schoolId });
  res.status(201).json({ success: true, data: route });
});

const updateRoute = asyncHandler(async (req, res) => {
  const route = await Route.findOneAndUpdate({ _id: req.params.id, school: req.schoolId }, req.body, { new: true, runValidators: true });
  if (!route) throw new ApiError(404, 'Route not found.');
  res.json({ success: true, data: route });
});

const deleteRoute = asyncHandler(async (req, res) => {
  const route = await Route.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!route) throw new ApiError(404, 'Route not found.');
  res.json({ success: true, message: 'Route deleted.' });
});

const assignStudent = asyncHandler(async (req, res) => {
  const { student, vehicle, route, stopId, monthlyFee } = req.body;
  const existing = await StudentTransport.findOne({ student, school: req.schoolId });
  if (existing) {
    Object.assign(existing, { vehicle, route, stopId, monthlyFee });
    await existing.save();
    return res.json({ success: true, data: existing });
  }
  const assignment = await StudentTransport.create({ school: req.schoolId, student, vehicle, route, stopId, monthlyFee });
  res.status(201).json({ success: true, data: assignment });
});

const getAssignments = asyncHandler(async (req, res) => {
  const filter = { school: req.schoolId };
  if (req.query.vehicle) filter.vehicle = req.query.vehicle;
  const assignments = await StudentTransport.find(filter)
    .populate('student', 'firstName lastName admissionNumber')
    .populate('vehicle', 'vehicleNumber')
    .populate('route', 'name');
  res.json({ success: true, data: assignments });
});

const removeAssignment = asyncHandler(async (req, res) => {
  const assignment = await StudentTransport.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!assignment) throw new ApiError(404, 'Assignment not found.');
  res.json({ success: true, message: 'Assignment removed.' });
});

module.exports = {
  getVehicles, createVehicle, updateVehicle, deleteVehicle,
  getRoutes, createRoute, updateRoute, deleteRoute,
  assignStudent, getAssignments, removeAssignment,
};
