const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const GalleryAlbum = require('../models/GalleryAlbum');
const School = require('../models/School');

const getAlbums = asyncHandler(async (req, res) => {
  const albums = await GalleryAlbum.find({ school: req.schoolId }).sort({ createdAt: -1 });
  res.json({ success: true, data: albums });
});

const createAlbum = asyncHandler(async (req, res) => {
  const album = await GalleryAlbum.create({ ...req.body, school: req.schoolId, images: [] });
  res.status(201).json({ success: true, data: album });
});

const updateAlbum = asyncHandler(async (req, res) => {
  const album = await GalleryAlbum.findOneAndUpdate({ _id: req.params.id, school: req.schoolId }, req.body, { new: true, runValidators: true });
  if (!album) throw new ApiError(404, 'Album not found.');
  res.json({ success: true, data: album });
});

const deleteAlbum = asyncHandler(async (req, res) => {
  const album = await GalleryAlbum.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!album) throw new ApiError(404, 'Album not found.');
  res.json({ success: true, message: 'Album deleted.' });
});

// POST /api/gallery/:id/images  body: { url, caption }
const addImage = asyncHandler(async (req, res) => {
  const album = await GalleryAlbum.findOne({ _id: req.params.id, school: req.schoolId });
  if (!album) throw new ApiError(404, 'Album not found.');
  album.images.push({ url: req.body.url, caption: req.body.caption });
  await album.save();
  res.status(201).json({ success: true, data: album });
});

const removeImage = asyncHandler(async (req, res) => {
  const album = await GalleryAlbum.findOne({ _id: req.params.id, school: req.schoolId });
  if (!album) throw new ApiError(404, 'Album not found.');
  album.images.id(req.params.imageId)?.deleteOne();
  await album.save();
  res.json({ success: true, data: album });
});

// GET /api/public/institutes/:slug/gallery — no auth required
const getPublicGallery = asyncHandler(async (req, res) => {
  const school = await School.findOne({ slug: req.params.slug, isActive: true });
  if (!school) throw new ApiError(404, 'Institute not found.');
  const albums = await GalleryAlbum.find({ school: school._id, isPublic: true }).sort({ createdAt: -1 });
  res.json({ success: true, data: albums });
});

module.exports = { getAlbums, createAlbum, updateAlbum, deleteAlbum, addImage, removeImage, getPublicGallery };
