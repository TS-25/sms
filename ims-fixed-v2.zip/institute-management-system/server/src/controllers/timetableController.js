const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Timetable = require('../models/Timetable');

async function findConflicts({ day, startTime, endTime, teacher, room, schoolId, excludeTimetableId, excludePeriodId }) {
  const timetables = await Timetable.find({
    school: schoolId,
    'periods.day': day,
    ...(excludeTimetableId ? { _id: { $ne: excludeTimetableId } } : {}),
  });

  const conflicts = [];
  for (const tt of timetables) {
    for (const p of tt.periods) {
      if (String(p._id) === String(excludePeriodId)) continue;
      if (p.day !== day) continue;
      const overlaps = startTime < p.endTime && endTime > p.startTime;
      if (!overlaps) continue;
      if (teacher && p.teacher && String(p.teacher) === String(teacher)) {
        conflicts.push({ type: 'teacher', timetable: tt._id, period: p._id });
      }
      if (room && p.room && p.room === room) {
        conflicts.push({ type: 'room', timetable: tt._id, period: p._id });
      }
    }
  }
  return conflicts;
}

const getTimetable = asyncHandler(async (req, res) => {
  const { class: classId, section } = req.query;
  if (!classId || !section) throw new ApiError(400, 'class and section are required.');

  const timetable = await Timetable.findOne({ class: classId, section, school: req.schoolId })
    .populate('periods.subject', 'name')
    .populate('periods.teacher', 'firstName lastName');

  res.json({ success: true, data: timetable || { class: classId, section, periods: [] } });
});

const getTeacherTimetable = asyncHandler(async (req, res) => {
  const timetables = await Timetable.find({ 'periods.teacher': req.params.teacherId, school: req.schoolId })
    .populate('class', 'name')
    .populate('section', 'name')
    .populate('periods.subject', 'name');

  const periods = [];
  timetables.forEach((tt) => {
    tt.periods
      .filter((p) => String(p.teacher) === req.params.teacherId)
      .forEach((p) => periods.push({ ...p.toObject(), class: tt.class, section: tt.section }));
  });

  res.json({ success: true, data: periods });
});

const addPeriod = asyncHandler(async (req, res) => {
  const { class: classId, section } = req.params;
  const { day, startTime, endTime, subject, teacher, room, academicSession } = req.body;

  if (startTime >= endTime) throw new ApiError(400, 'startTime must be before endTime.');

  const conflicts = await findConflicts({ day, startTime, endTime, teacher, room, schoolId: req.schoolId });
  if (conflicts.length > 0) {
    throw new ApiError(409, 'Scheduling conflict: teacher or room already booked in this time slot.', conflicts);
  }

  let timetable = await Timetable.findOne({ class: classId, section, school: req.schoolId });
  if (!timetable) {
    timetable = new Timetable({ school: req.schoolId, class: classId, section, academicSession, periods: [] });
  }
  timetable.periods.push({ day, startTime, endTime, subject, teacher, room });
  await timetable.save();

  res.status(201).json({ success: true, data: timetable });
});

const updatePeriod = asyncHandler(async (req, res) => {
  const { class: classId, section, periodId } = req.params;
  const timetable = await Timetable.findOne({ class: classId, section, school: req.schoolId });
  if (!timetable) throw new ApiError(404, 'Timetable not found.');

  const period = timetable.periods.id(periodId);
  if (!period) throw new ApiError(404, 'Period not found.');

  const merged = { ...period.toObject(), ...req.body };
  const conflicts = await findConflicts({
    day: merged.day,
    startTime: merged.startTime,
    endTime: merged.endTime,
    teacher: merged.teacher,
    room: merged.room,
    schoolId: req.schoolId,
    excludeTimetableId: timetable._id,
    excludePeriodId: periodId,
  });
  if (conflicts.length > 0) {
    throw new ApiError(409, 'Scheduling conflict: teacher or room already booked in this time slot.', conflicts);
  }

  Object.assign(period, req.body);
  await timetable.save();
  res.json({ success: true, data: timetable });
});

const deletePeriod = asyncHandler(async (req, res) => {
  const { class: classId, section, periodId } = req.params;
  const timetable = await Timetable.findOne({ class: classId, section, school: req.schoolId });
  if (!timetable) throw new ApiError(404, 'Timetable not found.');

  timetable.periods.id(periodId)?.deleteOne();
  await timetable.save();
  res.json({ success: true, data: timetable });
});

module.exports = { getTimetable, getTeacherTimetable, addPeriod, updatePeriod, deletePeriod };
