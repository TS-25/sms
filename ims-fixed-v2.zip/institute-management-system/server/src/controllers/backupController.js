const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const path = require('path');
const Backup = require('../models/Backup');
const { runBackup, BACKUP_DIR } = require('../services/backupService');

// POST /api/platform/backups — SUPER_ADMIN only (see backupRoutes.js).
// Runs synchronously and reports the result — for a large production
// database this would ideally be queued (e.g. via a job runner), but a
// direct mongodump call is genuinely functional for small-to-medium
// deployments without adding a job-queue dependency.
const triggerBackup = asyncHandler(async (req, res) => {
  const backup = await Backup.create({ status: 'running', triggeredBy: req.user._id });

  try {
    const { filePath, fileSizeBytes } = await runBackup();
    backup.status = 'completed';
    backup.filePath = filePath;
    backup.fileSizeBytes = fileSizeBytes;
    await backup.save();
    res.status(201).json({ success: true, data: backup });
  } catch (err) {
    backup.status = 'failed';
    backup.errorMessage = err.message;
    await backup.save();
    throw new ApiError(500, `Backup failed: ${err.message}. Make sure MongoDB Database Tools (mongodump) are installed on this server.`);
  }
});

const getBackups = asyncHandler(async (req, res) => {
  const backups = await Backup.find().sort({ createdAt: -1 }).limit(50);
  res.json({ success: true, data: backups });
});

// GET /api/platform/backups/:id/download
const downloadBackup = asyncHandler(async (req, res) => {
  const backup = await Backup.findById(req.params.id);
  if (!backup || backup.status !== 'completed' || !backup.filePath) {
    throw new ApiError(404, 'Backup not found or not completed.');
  }
  res.download(backup.filePath, path.basename(backup.filePath));
});

module.exports = { triggerBackup, getBackups, downloadBackup };
