const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Fee = require('../models/Fee');
const Payment = require('../models/Payment');
const Student = require('../models/Student');
const SchoolSettings = require('../models/SchoolSettings');
const Notification = require('../models/Notification');
const { generateFeeReceiptPDF } = require('../services/pdfService');
const paymentProvider = require('../services/paymentProviderService');
const { sendTemplatedEmail } = require('../services/emailService');

// ---------- Fees ----------
const getFees = asyncHandler(async (req, res) => {
  const { student, status, category, page = 1, limit = 20 } = req.query;
  const filter = { school: req.schoolId };
  if (student) filter.student = student;
  if (status) filter.status = status;
  if (category) filter.category = category;

  const skip = (Number(page) - 1) * Number(limit);
  const [fees, total] = await Promise.all([
    Fee.find(filter).populate('student', 'firstName lastName admissionNumber').sort({ dueDate: 1 }).skip(skip).limit(Number(limit)),
    Fee.countDocuments(filter),
  ]);

  res.json({ success: true, data: fees, pagination: { total, page: Number(page), limit: Number(limit) } });
});

const createFee = asyncHandler(async (req, res) => {
  const fee = await Fee.create({ ...req.body, school: req.schoolId });

  const student = await Student.findOne({ _id: fee.student, school: req.schoolId });
  if (student?.user) {
    await Notification.create({
      school: req.schoolId,
      user: student.user,
      title: 'New Fee Invoice',
      message: `A new fee invoice "${fee.title}" of amount ${fee.amount} has been added, due ${new Date(fee.dueDate).toLocaleDateString()}.`,
      type: 'fee_due',
    });
  }

  res.status(201).json({ success: true, data: fee });
});

const updateFee = asyncHandler(async (req, res) => {
  const fee = await Fee.findOneAndUpdate({ _id: req.params.id, school: req.schoolId }, req.body, { new: true, runValidators: true });
  if (!fee) throw new ApiError(404, 'Fee not found.');
  res.json({ success: true, data: fee });
});

const deleteFee = asyncHandler(async (req, res) => {
  const fee = await Fee.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!fee) throw new ApiError(404, 'Fee not found.');
  res.json({ success: true, message: 'Fee deleted.' });
});

// ---------- Payments ----------
const recordPayment = asyncHandler(async (req, res) => {
  const { fee: feeId, amount, method, notes } = req.body;
  const fee = await Fee.findOne({ _id: feeId, school: req.schoolId });
  if (!fee) throw new ApiError(404, 'Fee invoice not found.');

  const amountDue = fee.amount - fee.discount - fee.amountPaid;
  if (amount > amountDue) throw new ApiError(400, `Payment exceeds amount due (${amountDue}).`);

  const receiptNumber = `RCPT-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  const payment = await Payment.create({
    school: req.schoolId,
    fee: fee._id,
    student: fee.student,
    amount,
    method,
    notes,
    receiptNumber,
    receivedBy: req.user._id,
  });

  fee.amountPaid += amount;
  fee.status = fee.amountPaid >= fee.amount - fee.discount ? 'paid' : 'partial';
  await fee.save();

  const student = await Student.findOne({ _id: fee.student, school: req.schoolId });
  if (student?.email) {
    sendTemplatedEmail({
      schoolId: req.schoolId,
      type: 'payment_confirmation',
      to: student.email,
      variables: { studentName: student.fullName, amount, receiptNumber, institutionName: req.school?.name || 'your institute' },
    }).catch((err) => console.error('Payment confirmation email failed:', err.message));
  }

  res.status(201).json({ success: true, data: { payment, fee } });
});

// GET /api/payments/:id/receipt  (PDF)
const downloadReceipt = asyncHandler(async (req, res) => {
  const payment = await Payment.findOne({ _id: req.params.id, school: req.schoolId }).populate('fee');
  if (!payment) throw new ApiError(404, 'Payment not found.');

  const student = await Student.findOne({ _id: payment.student, school: req.schoolId }).populate('class section');
  const school = await SchoolSettings.findOne({ school: req.schoolId });

  generateFeeReceiptPDF(res, { school, student, fee: payment.fee, payment });
});

// GET /api/payments?student=&from=&to=
const getPayments = asyncHandler(async (req, res) => {
  const { student, from, to, page = 1, limit = 20 } = req.query;
  const filter = { school: req.schoolId };
  if (student) filter.student = student;
  if (from || to) {
    filter.paidAt = {};
    if (from) filter.paidAt.$gte = new Date(from);
    if (to) filter.paidAt.$lte = new Date(to);
  }

  const skip = (Number(page) - 1) * Number(limit);
  const [payments, total] = await Promise.all([
    Payment.find(filter).populate('student', 'firstName lastName admissionNumber').populate('fee', 'title category').sort({ paidAt: -1 }).skip(skip).limit(Number(limit)),
    Payment.countDocuments(filter),
  ]);

  res.json({ success: true, data: payments, pagination: { total, page: Number(page), limit: Number(limit) } });
});

// POST /api/fees/:id/pay-online — (#11) returns a hosted checkout URL if
// an online provider is configured, or a clear message to use the manual
// flow otherwise. Never assumes a provider is available.
const initiateOnlinePayment = asyncHandler(async (req, res) => {
  const fee = await Fee.findOne({ _id: req.params.id, school: req.schoolId });
  if (!fee) throw new ApiError(404, 'Fee invoice not found.');
  if (fee.status === 'paid') throw new ApiError(400, 'This invoice is already fully paid.');

  const student = await Student.findOne({ _id: fee.student, school: req.schoolId });
  const clientUrl = (process.env.CLIENT_URL || 'http://localhost:5173').split(',')[0];

  const checkoutUrl = await paymentProvider.createCheckoutSession({
    fee,
    student,
    successUrl: `${clientUrl}/student/fees?payment=success`,
    cancelUrl: `${clientUrl}/student/fees?payment=cancelled`,
  });

  if (!checkoutUrl) {
    return res.json({
      success: true,
      data: { provider: 'manual', message: 'Online payments are not enabled for this school. Please pay in person or by bank transfer.' },
    });
  }

  res.json({ success: true, data: { provider: paymentProvider.getActiveProvider(), checkoutUrl } });
});

// POST /api/fees/webhook — provider calls this on payment completion.
// Deliberately NOT behind requireSchool/protect (see feeRoutes.js) since
// it's called by the payment provider's servers, not a logged-in user;
// signature verification inside parseWebhookEvent is what secures it.
const handlePaymentWebhook = asyncHandler(async (req, res) => {
  let event;
  try {
    event = await paymentProvider.parseWebhookEvent(req);
  } catch (err) {
    throw new ApiError(400, `Webhook verification failed: ${err.message}`);
  }
  if (!event) return res.json({ received: true });

  const fee = await Fee.findById(event.feeId);
  if (!fee) return res.json({ received: true });

  const receiptNumber = `RCPT-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  await Payment.create({
    school: fee.school,
    fee: fee._id,
    student: fee.student,
    amount: event.amount,
    method: 'online',
    notes: `Transaction ID: ${event.transactionId}`,
    receiptNumber,
  });

  fee.amountPaid += event.amount;
  fee.status = fee.amountPaid >= fee.amount - fee.discount ? 'paid' : 'partial';
  await fee.save();

  res.json({ received: true });
});

// POST /api/fees/:id/remind — manually send a fee_reminder email for one
// invoice (bounded, admin-triggered — not an automatic mass mailing).
const sendFeeReminder = asyncHandler(async (req, res) => {
  const fee = await Fee.findOne({ _id: req.params.id, school: req.schoolId });
  if (!fee) throw new ApiError(404, 'Fee invoice not found.');

  const student = await Student.findOne({ _id: fee.student, school: req.schoolId });
  if (!student?.email) throw new ApiError(400, 'This student has no email on file.');

  await sendTemplatedEmail({
    schoolId: req.schoolId,
    type: 'fee_reminder',
    to: student.email,
    variables: {
      studentName: student.fullName,
      amount: fee.amount - fee.discount - fee.amountPaid,
      dueDate: new Date(fee.dueDate).toLocaleDateString(),
      institutionName: req.school?.name || 'your institute',
    },
  });

  res.json({ success: true, message: `Reminder sent to ${student.email}.` });
});

module.exports = {
  getFees, createFee, updateFee, deleteFee,
  recordPayment, downloadReceipt, getPayments,
  initiateOnlinePayment, handlePaymentWebhook, sendFeeReminder,
};
