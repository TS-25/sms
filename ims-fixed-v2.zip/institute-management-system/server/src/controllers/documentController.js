const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Document = require('../models/Document');
const { getPublicUrl } = require('../services/storageService');

const getDocuments = asyncHandler(async (req, res) => {
  const { category, relatedKind, relatedId, page = 1, limit = 20 } = req.query;
  const filter = { school: req.schoolId };
  if (category) filter.category = category;
  if (relatedKind) filter['relatedTo.kind'] = relatedKind;
  if (relatedId) filter['relatedTo.id'] = relatedId;

  const skip = (Number(page) - 1) * Number(limit);
  const [documents, total] = await Promise.all([
    Document.find(filter).populate('uploadedBy', 'name').sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Document.countDocuments(filter),
  ]);

  res.json({ success: true, data: documents, pagination: { total, page: Number(page), limit: Number(limit) } });
});

const uploadDocument = asyncHandler(async (req, res) => {
  if (!req.file) throw new ApiError(400, 'A file is required (field name: file).');

  const { title, category, relatedKind, relatedId } = req.body;
  const fileUrl = getPublicUrl(req, req.file.filename || req.file.path);

  const document = await Document.create({
    school: req.schoolId,
    title: title || req.file.originalname,
    category: category || 'other',
    fileUrl,
    relatedTo: relatedKind && relatedId ? { kind: relatedKind, id: relatedId } : undefined,
    uploadedBy: req.user._id,
  });

  res.status(201).json({ success: true, data: document });
});

const deleteDocument = asyncHandler(async (req, res) => {
  const document = await Document.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!document) throw new ApiError(404, 'Document not found.');
  res.json({ success: true, message: 'Document deleted.' });
});

module.exports = { getDocuments, uploadDocument, deleteDocument };
