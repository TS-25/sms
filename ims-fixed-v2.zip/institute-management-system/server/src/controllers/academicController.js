const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const AcademicSession = require('../models/AcademicSession');
const Class = require('../models/Class');
const Section = require('../models/Section');
const Subject = require('../models/Subject');

// ---------- Academic Sessions ----------
const getSessions = asyncHandler(async (req, res) => {
  const sessions = await AcademicSession.find({ school: req.schoolId }).sort({ startDate: -1 });
  res.json({ success: true, data: sessions });
});

const createSession = asyncHandler(async (req, res) => {
  const { name, startDate, endDate, isCurrent } = req.body;
  if (isCurrent) await AcademicSession.updateMany({ school: req.schoolId }, { isCurrent: false });
  const session = await AcademicSession.create({ school: req.schoolId, name, startDate, endDate, isCurrent });
  res.status(201).json({ success: true, data: session });
});

const updateSession = asyncHandler(async (req, res) => {
  const session = await AcademicSession.findOne({ _id: req.params.id, school: req.schoolId });
  if (!session) throw new ApiError(404, 'Academic session not found.');
  if (req.body.isCurrent) await AcademicSession.updateMany({ school: req.schoolId }, { isCurrent: false });
  Object.assign(session, req.body);
  await session.save();
  res.json({ success: true, data: session });
});

const deleteSession = asyncHandler(async (req, res) => {
  const session = await AcademicSession.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!session) throw new ApiError(404, 'Academic session not found.');
  res.json({ success: true, message: 'Academic session deleted.' });
});

// ---------- Classes ----------
const getClasses = asyncHandler(async (req, res) => {
  const filter = { school: req.schoolId };
  if (req.query.academicSession) filter.academicSession = req.query.academicSession;
  const classes = await Class.find(filter).populate('academicSession', 'name').populate('classTeacher', 'firstName lastName');
  res.json({ success: true, data: classes });
});

const createClass = asyncHandler(async (req, res) => {
  const cls = await Class.create({ ...req.body, school: req.schoolId });
  res.status(201).json({ success: true, data: cls });
});

const updateClass = asyncHandler(async (req, res) => {
  const cls = await Class.findOneAndUpdate({ _id: req.params.id, school: req.schoolId }, req.body, { new: true, runValidators: true });
  if (!cls) throw new ApiError(404, 'Class not found.');
  res.json({ success: true, data: cls });
});

const deleteClass = asyncHandler(async (req, res) => {
  const cls = await Class.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!cls) throw new ApiError(404, 'Class not found.');
  res.json({ success: true, message: 'Class deleted.' });
});

// ---------- Sections ----------
const getSections = asyncHandler(async (req, res) => {
  const filter = { school: req.schoolId };
  if (req.query.class) filter.class = req.query.class;
  const sections = await Section.find(filter).populate('class', 'name').populate('classTeacher', 'firstName lastName');
  res.json({ success: true, data: sections });
});

const createSection = asyncHandler(async (req, res) => {
  const section = await Section.create({ ...req.body, school: req.schoolId });
  res.status(201).json({ success: true, data: section });
});

const updateSection = asyncHandler(async (req, res) => {
  const section = await Section.findOneAndUpdate({ _id: req.params.id, school: req.schoolId }, req.body, { new: true, runValidators: true });
  if (!section) throw new ApiError(404, 'Section not found.');
  res.json({ success: true, data: section });
});

const deleteSection = asyncHandler(async (req, res) => {
  const section = await Section.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!section) throw new ApiError(404, 'Section not found.');
  res.json({ success: true, message: 'Section deleted.' });
});

// ---------- Subjects ----------
const getSubjects = asyncHandler(async (req, res) => {
  const filter = { school: req.schoolId };
  if (req.query.class) filter.class = req.query.class;
  const subjects = await Subject.find(filter).populate('class', 'name').populate('teacher', 'firstName lastName');
  res.json({ success: true, data: subjects });
});

const createSubject = asyncHandler(async (req, res) => {
  const subject = await Subject.create({ ...req.body, school: req.schoolId });
  res.status(201).json({ success: true, data: subject });
});

const updateSubject = asyncHandler(async (req, res) => {
  const subject = await Subject.findOneAndUpdate({ _id: req.params.id, school: req.schoolId }, req.body, { new: true, runValidators: true });
  if (!subject) throw new ApiError(404, 'Subject not found.');
  res.json({ success: true, data: subject });
});

const deleteSubject = asyncHandler(async (req, res) => {
  const subject = await Subject.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!subject) throw new ApiError(404, 'Subject not found.');
  res.json({ success: true, message: 'Subject deleted.' });
});

module.exports = {
  getSessions, createSession, updateSession, deleteSession,
  getClasses, createClass, updateClass, deleteClass,
  getSections, createSection, updateSection, deleteSection,
  getSubjects, createSubject, updateSubject, deleteSubject,
};
