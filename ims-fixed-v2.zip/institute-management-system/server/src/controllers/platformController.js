const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const School = require('../models/School');
const SchoolSettings = require('../models/SchoolSettings');
const User = require('../models/User');
const { ROLES } = require('../config/roles');
const logAction = require('../utils/logAction');

// GET /api/platform/schools
const getSchools = asyncHandler(async (req, res) => {
  const schools = await School.find().sort({ createdAt: -1 });

  const counts = await User.aggregate([
    { $match: { school: { $ne: null } } },
    { $group: { _id: '$school', userCount: { $sum: 1 } } },
  ]);
  const countMap = Object.fromEntries(counts.map((c) => [String(c._id), c.userCount]));

  res.json({
    success: true,
    data: schools.map((s) => ({ ...s.toObject(), userCount: countMap[String(s._id)] || 0 })),
  });
});

// GET /api/platform/schools/:id
const getSchool = asyncHandler(async (req, res) => {
  const school = await School.findById(req.params.id);
  if (!school) throw new ApiError(404, 'School not found.');
  res.json({ success: true, data: school });
});

// POST /api/platform/schools
const createSchool = asyncHandler(async (req, res) => {
  const { name, slug, address, phone, email, website, plan, adminName, adminEmail, adminPassword } = req.body;

  const existingSlug = await School.findOne({ slug: slug.toLowerCase() });
  if (existingSlug) throw new ApiError(409, 'This school slug is already in use.');

  const existingAdmin = await User.findOne({ email: adminEmail.toLowerCase() });
  if (existingAdmin) throw new ApiError(409, 'A user with this admin email already exists.');

  const school = await School.create({ name, slug: slug.toLowerCase(), address, phone, email, website, plan });

  await SchoolSettings.create({ school: school._id, schoolName: name, address, phone, email, website });

  const adminUser = await User.create({
    school: school._id,
    name: adminName,
    email: adminEmail,
    password: adminPassword,
    role: ROLES.ADMIN,
  });

  await logAction({ user: req.user, action: 'created', entity: 'School', entityId: school._id, school: school._id, req });

  res.status(201).json({ success: true, data: { school, admin: adminUser.toSafeObject() } });
});

// PUT /api/platform/schools/:id
const updateSchool = asyncHandler(async (req, res) => {
  const { name, address, phone, email, website, plan } = req.body;
  const school = await School.findById(req.params.id);
  if (!school) throw new ApiError(404, 'School not found.');

  if (name !== undefined) school.name = name;
  if (address !== undefined) school.address = address;
  if (phone !== undefined) school.phone = phone;
  if (email !== undefined) school.email = email;
  if (website !== undefined) school.website = website;
  if (plan !== undefined) school.plan = plan;
  await school.save();

  await logAction({ user: req.user, action: 'updated', entity: 'School', entityId: school._id, school: school._id, req });
  res.json({ success: true, data: school });
});

// PATCH /api/platform/schools/:id/status  body: { isActive }
const setSchoolStatus = asyncHandler(async (req, res) => {
  const school = await School.findByIdAndUpdate(req.params.id, { isActive: req.body.isActive }, { new: true });
  if (!school) throw new ApiError(404, 'School not found.');

  await logAction({
    user: req.user,
    action: req.body.isActive ? 'activated' : 'deactivated',
    entity: 'School',
    entityId: school._id,
    school: school._id,
    req,
  });
  res.json({ success: true, data: school });
});

// PATCH /api/platform/schools/:id/modules  body: { enabledModules: {...} }
const updateSchoolModules = asyncHandler(async (req, res) => {
  const school = await School.findById(req.params.id);
  if (!school) throw new ApiError(404, 'School not found.');

  school.enabledModules = { ...school.enabledModules.toObject(), ...req.body.enabledModules };
  await school.save();

  await logAction({ user: req.user, action: 'updated_modules', entity: 'School', entityId: school._id, school: school._id, req });
  res.json({ success: true, data: school });
});

// GET /api/platform/stats
const getPlatformStats = asyncHandler(async (req, res) => {
  const [totalSchools, activeSchools, totalUsers] = await Promise.all([
    School.countDocuments(),
    School.countDocuments({ isActive: true }),
    User.countDocuments({ school: { $ne: null } }),
  ]);

  res.json({
    success: true,
    data: { totalSchools, activeSchools, inactiveSchools: totalSchools - activeSchools, totalUsers },
  });
});

module.exports = {
  getSchools,
  getSchool,
  createSchool,
  updateSchool,
  setSchoolStatus,
  updateSchoolModules,
  getPlatformStats,
};
