const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Teacher = require('../models/Teacher');
const User = require('../models/User');
const { ROLES } = require('../config/roles');
const { defaultPassword } = require('../utils/defaultPassword');
const logAction = require('../utils/logAction');
const { sendTemplatedEmail } = require('../services/emailService');

const POPULATE = [
  { path: 'subjects', select: 'name code' },
  { path: 'assignedClasses', select: 'name' },
];

const getTeachers = asyncHandler(async (req, res) => {
  const { search, status, page = 1, limit = 20 } = req.query;
  const filter = { school: req.schoolId };
  if (status) filter.status = status;
  if (search) {
    filter.$or = [
      { firstName: { $regex: search, $options: 'i' } },
      { lastName: { $regex: search, $options: 'i' } },
      { employeeId: { $regex: search, $options: 'i' } },
    ];
  }

  const skip = (Number(page) - 1) * Number(limit);
  const [teachers, total] = await Promise.all([
    Teacher.find(filter).populate(POPULATE).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Teacher.countDocuments(filter),
  ]);

  res.json({
    success: true,
    data: teachers,
    pagination: { total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) },
  });
});

const getTeacherById = asyncHandler(async (req, res) => {
  const teacher = await Teacher.findOne({ _id: req.params.id, school: req.schoolId }).populate(POPULATE);
  if (!teacher) throw new ApiError(404, 'Teacher not found.');
  res.json({ success: true, data: teacher });
});

const createTeacher = asyncHandler(async (req, res) => {
  const {
    firstName, lastName, email, password, employeeId, qualification,
    designation, subjects, assignedClasses, phone, address, joiningDate, salary,
  } = req.body;

  const existingUser = await User.findOne({ email: email.toLowerCase() });
  if (existingUser) throw new ApiError(409, 'A user with this email already exists.');

  const existingEmp = await Teacher.findOne({ employeeId, school: req.schoolId });
  if (existingEmp) throw new ApiError(409, 'This employee ID is already in use.');

  const finalPassword = password || defaultPassword(phone, employeeId);

  const user = await User.create({
    school: req.schoolId,
    name: `${firstName} ${lastName || ''}`.trim(),
    email,
    password: finalPassword,
    role: ROLES.TEACHER,
    phone,
  });

  const teacher = await Teacher.create({
    school: req.schoolId,
    user: user._id,
    employeeId,
    firstName,
    lastName,
    qualification,
    designation,
    subjects,
    assignedClasses,
    phone,
    email,
    address,
    joiningDate,
    salary,
  });

  user.profileRef = { kind: 'Teacher', id: teacher._id };
  await user.save();

  await logAction({ user: req.user, action: 'created', entity: 'Teacher', entityId: teacher._id, req });

  sendTemplatedEmail({
    schoolId: req.schoolId,
    type: 'welcome',
    to: email,
    variables: { recipientName: `${firstName} ${lastName || ''}`.trim(), institutionName: req.school?.name || 'your institute' },
  }).catch((err) => console.error('Welcome email failed:', err.message));

  res.status(201).json({
    success: true,
    data: teacher,
    meta: password ? undefined : { generatedPassword: finalPassword },
  });
});

const updateTeacher = asyncHandler(async (req, res) => {
  const teacher = await Teacher.findOne({ _id: req.params.id, school: req.schoolId });
  if (!teacher) throw new ApiError(404, 'Teacher not found.');

  const allowedFields = [
    'firstName', 'lastName', 'qualification', 'designation', 'subjects',
    'assignedClasses', 'phone', 'email', 'address', 'salary', 'status', 'photoUrl',
  ];
  allowedFields.forEach((field) => {
    if (req.body[field] !== undefined) teacher[field] = req.body[field];
  });
  await teacher.save();

  await logAction({ user: req.user, action: 'updated', entity: 'Teacher', entityId: teacher._id, req });
  res.json({ success: true, data: teacher });
});

const deleteTeacher = asyncHandler(async (req, res) => {
  const teacher = await Teacher.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!teacher) throw new ApiError(404, 'Teacher not found.');
  await User.findByIdAndDelete(teacher.user);

  await logAction({ user: req.user, action: 'deleted', entity: 'Teacher', entityId: teacher._id, req });
  res.json({ success: true, message: 'Teacher deleted successfully.' });
});

module.exports = { getTeachers, getTeacherById, createTeacher, updateTeacher, deleteTeacher };
