const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const SportsTeam = require('../models/SportsTeam');

const getTeams = asyncHandler(async (req, res) => {
  const teams = await SportsTeam.find({ school: req.schoolId }).populate('coach', 'firstName lastName').populate('players', 'firstName lastName admissionNumber');
  res.json({ success: true, data: teams });
});

const createTeam = asyncHandler(async (req, res) => {
  const team = await SportsTeam.create({ ...req.body, school: req.schoolId });
  res.status(201).json({ success: true, data: team });
});

const updateTeam = asyncHandler(async (req, res) => {
  const team = await SportsTeam.findOneAndUpdate({ _id: req.params.id, school: req.schoolId }, req.body, { new: true, runValidators: true });
  if (!team) throw new ApiError(404, 'Team not found.');
  res.json({ success: true, data: team });
});

const deleteTeam = asyncHandler(async (req, res) => {
  const team = await SportsTeam.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!team) throw new ApiError(404, 'Team not found.');
  res.json({ success: true, message: 'Team deleted.' });
});

const addMatch = asyncHandler(async (req, res) => {
  const team = await SportsTeam.findOne({ _id: req.params.id, school: req.schoolId });
  if (!team) throw new ApiError(404, 'Team not found.');
  team.matches.push(req.body);
  await team.save();
  res.status(201).json({ success: true, data: team });
});

module.exports = { getTeams, createTeam, updateTeam, deleteTeam, addMatch };
