const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Notice = require('../models/Notice');
const User = require('../models/User');
const Student = require('../models/Student');
const Notification = require('../models/Notification');
const { ROLES } = require('../config/roles');

// GET /api/notices?audience=
const getNotices = asyncHandler(async (req, res) => {
  const now = new Date();
  const filter = {
    school: req.schoolId,
    publishDate: { $lte: now },
    $or: [{ expiryDate: null }, { expiryDate: { $gte: now } }, { expiryDate: { $exists: false } }],
  };
  const notices = await Notice.find(filter).sort({ publishDate: -1 }).populate('createdBy', 'name role');
  res.json({ success: true, data: notices });
});

// POST /api/notices
const createNotice = asyncHandler(async (req, res) => {
  const notice = await Notice.create({ ...req.body, school: req.schoolId, createdBy: req.user._id });

  // Fan out in-app notifications to the relevant audience — always scoped
  // to this school so notices never leak across tenants.
  let targetUsers = [];
  const schoolFilter = { school: req.schoolId };
  if (notice.targetAudience === 'everyone') {
    targetUsers = await User.find(schoolFilter, '_id');
  } else if (notice.targetAudience === 'teachers') {
    targetUsers = await User.find({ ...schoolFilter, role: ROLES.TEACHER }, '_id');
  } else if (notice.targetAudience === 'students') {
    targetUsers = await User.find({ ...schoolFilter, role: ROLES.STUDENT }, '_id');
  } else if (notice.targetAudience === 'parents') {
    targetUsers = await User.find({ ...schoolFilter, role: ROLES.PARENT }, '_id');
  } else if (notice.targetAudience === 'staff') {
    targetUsers = await User.find({ ...schoolFilter, role: { $in: [ROLES.STAFF, ROLES.ACCOUNTANT, ROLES.LIBRARIAN, ROLES.RECEPTIONIST] } }, '_id');
  } else if (notice.targetAudience === 'class' && notice.targetClass) {
    const students = await Student.find({ class: notice.targetClass, school: req.schoolId }, 'user');
    targetUsers = students.map((s) => ({ _id: s.user })).filter((u) => u._id);
  }

  if (targetUsers.length) {
    await Notification.insertMany(
      targetUsers.map((u) => ({
        school: req.schoolId,
        user: u._id,
        title: 'New Notice',
        message: notice.title,
        type: 'new_notice',
      }))
    );
  }

  res.status(201).json({ success: true, data: notice });
});

const updateNotice = asyncHandler(async (req, res) => {
  const notice = await Notice.findOneAndUpdate({ _id: req.params.id, school: req.schoolId }, req.body, { new: true, runValidators: true });
  if (!notice) throw new ApiError(404, 'Notice not found.');
  res.json({ success: true, data: notice });
});

const deleteNotice = asyncHandler(async (req, res) => {
  const notice = await Notice.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!notice) throw new ApiError(404, 'Notice not found.');
  res.json({ success: true, message: 'Notice deleted.' });
});

module.exports = { getNotices, createNotice, updateNotice, deleteNotice };
