const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Event = require('../models/Event');

const getEvents = asyncHandler(async (req, res) => {
  const { from, to, type } = req.query;
  const filter = { school: req.schoolId };
  if (type) filter.type = type;
  if (from || to) {
    filter.startDate = {};
    if (from) filter.startDate.$gte = new Date(from);
    if (to) filter.startDate.$lte = new Date(to);
  }

  const events = await Event.find(filter).sort({ startDate: 1 });
  res.json({ success: true, data: events });
});

const createEvent = asyncHandler(async (req, res) => {
  const event = await Event.create({ ...req.body, school: req.schoolId, createdBy: req.user._id });
  res.status(201).json({ success: true, data: event });
});

const updateEvent = asyncHandler(async (req, res) => {
  const event = await Event.findOneAndUpdate({ _id: req.params.id, school: req.schoolId }, req.body, { new: true, runValidators: true });
  if (!event) throw new ApiError(404, 'Event not found.');
  res.json({ success: true, data: event });
});

const deleteEvent = asyncHandler(async (req, res) => {
  const event = await Event.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!event) throw new ApiError(404, 'Event not found.');
  res.json({ success: true, message: 'Event deleted.' });
});

module.exports = { getEvents, createEvent, updateEvent, deleteEvent };
