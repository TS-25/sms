const asyncHandler = require('../utils/asyncHandler');
const LoginAttempt = require('../models/LoginAttempt');
const AuditLog = require('../models/AuditLog');

// GET /api/security/dashboard — a consolidated view for admins (#88):
// failed logins, password/permission changes, and recent admin actions.
const getSecurityDashboard = asyncHandler(async (req, res) => {
  const since = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000); // last 30 days

  const [failedLogins, recentFailedLogins, passwordChanges, permissionChanges, recentAdminActions] = await Promise.all([
    LoginAttempt.countDocuments({ school: req.schoolId, success: false, createdAt: { $gte: since } }),
    LoginAttempt.find({ school: req.schoolId, success: false }).sort({ createdAt: -1 }).limit(20),
    AuditLog.countDocuments({ school: req.schoolId, action: { $in: ['changed_password', 'reset_password'] }, createdAt: { $gte: since } }),
    AuditLog.find({ school: req.schoolId, entity: 'User', action: 'updated' }).sort({ createdAt: -1 }).limit(20),
    AuditLog.find({ school: req.schoolId }).sort({ createdAt: -1 }).limit(20),
  ]);

  res.json({
    success: true,
    data: {
      failedLoginsLast30Days: failedLogins,
      passwordChangesLast30Days: passwordChanges,
      recentFailedLogins,
      recentPermissionChanges: permissionChanges,
      recentAdminActions,
    },
  });
});

module.exports = { getSecurityDashboard };
