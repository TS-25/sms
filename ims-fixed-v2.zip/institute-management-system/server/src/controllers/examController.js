const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Exam = require('../models/Exam');
const ExamResult = require('../models/ExamResult');
const Student = require('../models/Student');
const SchoolSettings = require('../models/SchoolSettings');
const { generateReportCardPDF } = require('../services/pdfService');
const { computeResultFields, getGradingScale } = require('../utils/grading');
const { sendTemplatedEmail } = require('../services/emailService');

// ---------- Exams ----------
const getExams = asyncHandler(async (req, res) => {
  const filter = { school: req.schoolId };
  if (req.query.class) filter.class = req.query.class;
  if (req.query.academicSession) filter.academicSession = req.query.academicSession;
  const exams = await Exam.find(filter).populate('class', 'name').populate('subjects.subject', 'name code');
  res.json({ success: true, data: exams });
});

const createExam = asyncHandler(async (req, res) => {
  const exam = await Exam.create({ ...req.body, school: req.schoolId });
  res.status(201).json({ success: true, data: exam });
});

const updateExam = asyncHandler(async (req, res) => {
  const exam = await Exam.findOne({ _id: req.params.id, school: req.schoolId });
  if (!exam) throw new ApiError(404, 'Exam not found.');
  if (exam.resultLocked) throw new ApiError(400, 'This exam is locked and cannot be modified.');
  Object.assign(exam, req.body);
  await exam.save();
  res.json({ success: true, data: exam });
});

const deleteExam = asyncHandler(async (req, res) => {
  const exam = await Exam.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!exam) throw new ApiError(404, 'Exam not found.');
  res.json({ success: true, message: 'Exam deleted.' });
});

// ---------- Results ----------
const upsertResult = asyncHandler(async (req, res) => {
  const exam = await Exam.findOne({ _id: req.params.examId, school: req.schoolId });
  if (!exam) throw new ApiError(404, 'Exam not found.');
  if (exam.resultLocked) throw new ApiError(400, 'Results for this exam are locked.');

  const { student, marks, remarks } = req.body;
  if (!Array.isArray(marks) || marks.length === 0) {
    throw new ApiError(400, 'At least one subject mark is required.');
  }

  const computed = await computeResultFields(marks, req.schoolId);

  let result = await ExamResult.findOne({ exam: exam._id, student, school: req.schoolId });
  if (result) {
    result.marks = marks;
    result.remarks = remarks;
  } else {
    result = new ExamResult({ exam: exam._id, student, marks, remarks, school: req.schoolId });
  }
  result.totalFullMarks = computed.totalFullMarks;
  result.totalObtained = computed.totalObtained;
  result.percentage = computed.percentage;
  result.isPass = computed.isPass;
  result.grade = computed.grade;
  result.gpa = computed.gpa;

  await result.save();
  res.status(201).json({ success: true, data: result });
});

// GET /api/exams/:examId/results  (ranked)
const getExamResults = asyncHandler(async (req, res) => {
  const results = await ExamResult.find({ exam: req.params.examId, school: req.schoolId })
    .populate('student', 'firstName lastName admissionNumber rollNumber')
    .populate('marks.subject', 'name code')
    .sort({ totalObtained: -1 });

  results.forEach((r, idx) => {
    r.rank = idx + 1;
  });
  await Promise.all(results.map((r) => r.save()));

  res.json({ success: true, data: results });
});

// PATCH /api/exams/:examId/publish
const publishResults = asyncHandler(async (req, res) => {
  const exam = await Exam.findOneAndUpdate(
    { _id: req.params.examId, school: req.schoolId },
    { resultPublished: true },
    { new: true }
  );
  if (!exam) throw new ApiError(404, 'Exam not found.');

  // Best-effort notification to every student who has a result for this
  // exam — bounded to just this one exam's cohort, not a broad blast.
  const results = await ExamResult.find({ exam: exam._id, school: req.schoolId }).populate('student', 'email firstName lastName');
  for (const result of results) {
    if (!result.student?.email) continue;
    sendTemplatedEmail({
      schoolId: req.schoolId,
      type: 'result_published',
      to: result.student.email,
      variables: {
        studentName: `${result.student.firstName} ${result.student.lastName || ''}`.trim(),
        examName: exam.name,
        institutionName: req.school?.name || 'your institute',
      },
    }).catch((err) => console.error('Result published email failed:', err.message));
  }

  res.json({ success: true, data: exam });
});

// PATCH /api/exams/:examId/lock
const lockResults = asyncHandler(async (req, res) => {
  const exam = await Exam.findOneAndUpdate(
    { _id: req.params.examId, school: req.schoolId },
    { resultLocked: true },
    { new: true }
  );
  if (!exam) throw new ApiError(404, 'Exam not found.');
  res.json({ success: true, data: exam });
});

// GET /api/exams/:examId/results/:studentId/report-card  (PDF)
const downloadReportCard = asyncHandler(async (req, res) => {
  const exam = await Exam.findOne({ _id: req.params.examId, school: req.schoolId });
  if (!exam) throw new ApiError(404, 'Exam not found.');

  const result = await ExamResult.findOne({ exam: exam._id, student: req.params.studentId, school: req.schoolId }).populate(
    'marks.subject',
    'name'
  );
  if (!result) throw new ApiError(404, 'Result not found for this student.');

  const student = await Student.findOne({ _id: req.params.studentId, school: req.schoolId }).populate('class section');
  const school = await SchoolSettings.findOne({ school: req.schoolId });
  const gradingScale = await getGradingScale(req.schoolId);

  generateReportCardPDF(res, { school, student, exam, result, gradingScale });
});

module.exports = {
  getExams, createExam, updateExam, deleteExam,
  upsertResult, getExamResults, publishResults, lockResults, downloadReportCard,
};
