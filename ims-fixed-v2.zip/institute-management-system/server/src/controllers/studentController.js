const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const fs = require('fs');
const Student = require('../models/Student');
const User = require('../models/User');
const Attendance = require('../models/Attendance');
const ExamResult = require('../models/ExamResult');
const Fee = require('../models/Fee');
const { ROLES } = require('../config/roles');
const { parseCsvBuffer, toCsv } = require('../services/csvService');
const { defaultPassword } = require('../utils/defaultPassword');
const logAction = require('../utils/logAction');
const { sendTemplatedEmail } = require('../services/emailService');

const POPULATE = [
  { path: 'class', select: 'name' },
  { path: 'section', select: 'name' },
  { path: 'academicSession', select: 'name' },
];

// GET /api/students?search=&class=&section=&status=&page=&limit=
const getStudents = asyncHandler(async (req, res) => {
  const { search, class: classId, section, status, page = 1, limit = 20 } = req.query;
  const filter = { school: req.schoolId };
  if (classId) filter.class = classId;
  if (section) filter.section = section;
  if (status) filter.status = status;
  if (search) {
    filter.$or = [
      { firstName: { $regex: search, $options: 'i' } },
      { lastName: { $regex: search, $options: 'i' } },
      { admissionNumber: { $regex: search, $options: 'i' } },
    ];
  }

  const skip = (Number(page) - 1) * Number(limit);
  const [students, total] = await Promise.all([
    Student.find(filter).populate(POPULATE).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Student.countDocuments(filter),
  ]);

  res.json({
    success: true,
    data: students,
    pagination: { total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) },
  });
});

// GET /api/students/:id  (full profile: attendance, results, fees)
const getStudentProfile = asyncHandler(async (req, res) => {
  const student = await Student.findOne({ _id: req.params.id, school: req.schoolId }).populate(POPULATE);
  if (!student) throw new ApiError(404, 'Student not found.');

  const [attendance, results, fees] = await Promise.all([
    Attendance.find({ student: student._id, school: req.schoolId }).sort({ date: -1 }).limit(30),
    ExamResult.find({ student: student._id, school: req.schoolId }).populate('exam', 'name'),
    Fee.find({ student: student._id, school: req.schoolId }).sort({ dueDate: -1 }),
  ]);

  res.json({ success: true, data: { student, attendance, results, fees } });
});

// POST /api/students  — creates linked User account + Student profile
const createStudent = asyncHandler(async (req, res) => {
  const {
    firstName, lastName, email, password, admissionNumber, rollNumber,
    dateOfBirth, gender, bloodGroup, address, phone,
    guardianName, guardianPhone, guardianRelation, emergencyContact,
    class: classId, section, academicSession, admissionDate,
  } = req.body;

  const existingUser = await User.findOne({ email: email.toLowerCase() });
  if (existingUser) throw new ApiError(409, 'A user with this email already exists.');

  const existingAdmission = await Student.findOne({ admissionNumber, school: req.schoolId });
  if (existingAdmission) throw new ApiError(409, 'This admission number is already in use.');

  const finalPassword = password || defaultPassword(phone, admissionNumber);

  const user = await User.create({
    school: req.schoolId,
    name: `${firstName} ${lastName || ''}`.trim(),
    email,
    password: finalPassword,
    role: ROLES.STUDENT,
    phone,
  });

  const student = await Student.create({
    school: req.schoolId,
    user: user._id,
    admissionNumber,
    rollNumber,
    firstName,
    lastName,
    dateOfBirth,
    gender,
    bloodGroup,
    address,
    phone,
    guardianName,
    guardianPhone,
    guardianRelation,
    emergencyContact,
    class: classId,
    section,
    academicSession,
    admissionDate,
  });

  user.profileRef = { kind: 'Student', id: student._id };
  await user.save();

  await logAction({ user: req.user, action: 'created', entity: 'Student', entityId: student._id, req });

  // Best-effort welcome email — never let a mail failure block account
  // creation (e.g. no email provider configured yet is a normal state).
  sendTemplatedEmail({
    schoolId: req.schoolId,
    type: 'welcome',
    to: email,
    variables: { recipientName: `${firstName} ${lastName || ''}`.trim(), institutionName: req.school?.name || 'your institute' },
  }).catch((err) => console.error('Welcome email failed:', err.message));

  res.status(201).json({
    success: true,
    data: student,
    meta: password ? undefined : { generatedPassword: finalPassword },
  });
});

// PUT /api/students/:id
const updateStudent = asyncHandler(async (req, res) => {
  const student = await Student.findOne({ _id: req.params.id, school: req.schoolId });
  if (!student) throw new ApiError(404, 'Student not found.');

  const allowedFields = [
    'firstName', 'lastName', 'rollNumber', 'dateOfBirth', 'gender', 'bloodGroup',
    'address', 'phone', 'email', 'guardianName', 'guardianPhone', 'guardianRelation',
    'emergencyContact', 'class', 'section', 'academicSession', 'status', 'photoUrl',
  ];
  allowedFields.forEach((field) => {
    if (req.body[field] !== undefined) student[field] = req.body[field];
  });
  await student.save();

  await logAction({ user: req.user, action: 'updated', entity: 'Student', entityId: student._id, req });
  res.json({ success: true, data: student });
});

// DELETE /api/students/:id
const deleteStudent = asyncHandler(async (req, res) => {
  const student = await Student.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!student) throw new ApiError(404, 'Student not found.');
  await User.findByIdAndDelete(student.user);

  await logAction({ user: req.user, action: 'deleted', entity: 'Student', entityId: student._id, req });
  res.json({ success: true, message: 'Student deleted successfully.' });
});

// GET /api/students/export/csv
const exportStudentsCsv = asyncHandler(async (req, res) => {
  const students = await Student.find({ school: req.schoolId }).populate(POPULATE).lean();
  const records = students.map((s) => ({
    admissionNumber: s.admissionNumber,
    firstName: s.firstName,
    lastName: s.lastName,
    rollNumber: s.rollNumber,
    class: s.class?.name,
    section: s.section?.name,
    gender: s.gender,
    phone: s.phone,
    guardianName: s.guardianName,
    guardianPhone: s.guardianPhone,
    status: s.status,
  }));
  const csv = toCsv(records, Object.keys(records[0] || { admissionNumber: '' }));

  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename=students.csv');
  res.send(csv);
});

// POST /api/students/import/csv  (multipart file field: "file")
const importStudentsCsv = asyncHandler(async (req, res) => {
  if (!req.file) throw new ApiError(400, 'CSV file is required (field name: file).');

  const rows = parseCsvBuffer(req.file.buffer || fs.readFileSync(req.file.path));
  const results = { created: 0, skipped: 0, errors: [] };

  for (const [index, row] of rows.entries()) {
    try {
      if (!row.admissionNumber || !row.firstName || !row.email || !row.class || !row.section || !row.academicSession) {
        results.skipped += 1;
        results.errors.push({ row: index + 2, reason: 'Missing required fields.' });
        continue;
      }
      const existing = await Student.findOne({ admissionNumber: row.admissionNumber, school: req.schoolId });
      if (existing) {
        results.skipped += 1;
        results.errors.push({ row: index + 2, reason: 'Admission number already exists.' });
        continue;
      }
      const user = await User.create({
        school: req.schoolId,
        name: `${row.firstName} ${row.lastName || ''}`.trim(),
        email: row.email,
        password: defaultPassword(row.phone, row.admissionNumber),
        role: ROLES.STUDENT,
        phone: row.phone,
      });
      const student = await Student.create({
        school: req.schoolId,
        user: user._id,
        admissionNumber: row.admissionNumber,
        firstName: row.firstName,
        lastName: row.lastName,
        rollNumber: row.rollNumber,
        gender: row.gender,
        phone: row.phone,
        class: row.class,
        section: row.section,
        academicSession: row.academicSession,
      });
      user.profileRef = { kind: 'Student', id: student._id };
      await user.save();
      results.created += 1;
    } catch (err) {
      results.skipped += 1;
      results.errors.push({ row: index + 2, reason: err.message });
    }
  }

  res.json({ success: true, data: results });
});

module.exports = {
  getStudents,
  getStudentProfile,
  createStudent,
  updateStudent,
  deleteStudent,
  exportStudentsCsv,
  importStudentsCsv,
};
