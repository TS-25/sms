const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Alumni = require('../models/Alumni');

// GET /api/alumni?search=&year=&page=&limit=
const getAlumni = asyncHandler(async (req, res) => {
  const { year, page = 1, limit = 20 } = req.query;
  const filter = { school: req.schoolId };
  if (year) filter.graduationYear = Number(year);

  const skip = (Number(page) - 1) * Number(limit);
  const [alumni, total] = await Promise.all([
    Alumni.find(filter)
      .populate('student', 'firstName lastName admissionNumber')
      .sort({ graduationYear: -1 })
      .skip(skip)
      .limit(Number(limit)),
    Alumni.countDocuments(filter),
  ]);

  res.json({ success: true, data: alumni, pagination: { total, page: Number(page), limit: Number(limit) } });
});

const updateAlumni = asyncHandler(async (req, res) => {
  const alumni = await Alumni.findOneAndUpdate({ _id: req.params.id, school: req.schoolId }, req.body, {
    new: true,
    runValidators: true,
  });
  if (!alumni) throw new ApiError(404, 'Alumni record not found.');
  res.json({ success: true, data: alumni });
});

// GET /api/alumni/stats — simple counts by graduation year
const getAlumniStats = asyncHandler(async (req, res) => {
  const stats = await Alumni.aggregate([
    { $match: { school: req.schoolId } },
    { $group: { _id: '$graduationYear', count: { $sum: 1 } } },
    { $sort: { _id: -1 } },
  ]);
  res.json({ success: true, data: stats.map((s) => ({ year: s._id, count: s.count })) });
});

module.exports = { getAlumni, updateAlumni, getAlumniStats };
