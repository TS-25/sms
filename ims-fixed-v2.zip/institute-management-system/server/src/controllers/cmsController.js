const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Page = require('../models/Page');
const School = require('../models/School');

// GET /api/cms/pages (admin — all pages including drafts)
const getPages = asyncHandler(async (req, res) => {
  const pages = await Page.find({ school: req.schoolId }).sort({ title: 1 });
  res.json({ success: true, data: pages });
});

const createPage = asyncHandler(async (req, res) => {
  const existing = await Page.findOne({ slug: req.body.slug, school: req.schoolId });
  if (existing) throw new ApiError(409, 'A page with this slug already exists.');
  const page = await Page.create({ ...req.body, school: req.schoolId });
  res.status(201).json({ success: true, data: page });
});

const updatePage = asyncHandler(async (req, res) => {
  const page = await Page.findOneAndUpdate({ _id: req.params.id, school: req.schoolId }, req.body, { new: true, runValidators: true });
  if (!page) throw new ApiError(404, 'Page not found.');
  res.json({ success: true, data: page });
});

const deletePage = asyncHandler(async (req, res) => {
  const page = await Page.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!page) throw new ApiError(404, 'Page not found.');
  res.json({ success: true, message: 'Page deleted.' });
});

// GET /api/public/institutes/:slug/pages/:pageSlug — no auth required
const getPublicPage = asyncHandler(async (req, res) => {
  const school = await School.findOne({ slug: req.params.slug, isActive: true });
  if (!school) throw new ApiError(404, 'Institute not found.');

  const page = await Page.findOne({ school: school._id, slug: req.params.pageSlug, isPublished: true });
  if (!page) throw new ApiError(404, 'Page not found.');

  res.json({ success: true, data: page });
});

module.exports = { getPages, createPage, updatePage, deletePage, getPublicPage };
