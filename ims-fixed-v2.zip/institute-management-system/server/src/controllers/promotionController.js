const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Student = require('../models/Student');
const PromotionHistory = require('../models/PromotionHistory');
const Alumni = require('../models/Alumni');
const Certificate = require('../models/Certificate');
const logAction = require('../utils/logAction');

// POST /api/promotions/promote
// body: { studentIds: [...], toClass, toSection, toSession }
// Promotes one, several, or an entire class of students at once (#3:
// "promote selected students" / "promote entire class" are the same
// operation with a different studentIds list from the frontend).
const promoteStudents = asyncHandler(async (req, res) => {
  const { studentIds, toClass, toSection, toSession } = req.body;
  if (!Array.isArray(studentIds) || studentIds.length === 0) {
    throw new ApiError(400, 'studentIds array is required.');
  }

  const students = await Student.find({ _id: { $in: studentIds }, school: req.schoolId });
  const results = [];

  for (const student of students) {
    await PromotionHistory.create({
      school: req.schoolId,
      student: student._id,
      action: 'promoted',
      fromClass: student.class,
      fromSection: student.section,
      fromSession: student.academicSession,
      toClass,
      toSection,
      toSession,
      performedBy: req.user._id,
    });

    student.class = toClass;
    student.section = toSection;
    if (toSession) student.academicSession = toSession;
    await student.save();
    results.push(student._id);
  }

  await logAction({ user: req.user, action: 'promoted', entity: 'Student', entityId: null, req, meta: { count: results.length } });
  res.json({ success: true, data: { promoted: results.length } });
});

// POST /api/promotions/repeat  body: { studentIds: [...] }
// Keeps a student in the same class/section but moves them to a new
// session — used when a student doesn't meet promotion criteria.
const repeatStudents = asyncHandler(async (req, res) => {
  const { studentIds, toSession } = req.body;
  if (!Array.isArray(studentIds) || studentIds.length === 0) {
    throw new ApiError(400, 'studentIds array is required.');
  }
  if (!toSession) throw new ApiError(400, 'toSession is required.');

  const students = await Student.find({ _id: { $in: studentIds }, school: req.schoolId });
  for (const student of students) {
    await PromotionHistory.create({
      school: req.schoolId,
      student: student._id,
      action: 'repeated',
      fromClass: student.class,
      fromSection: student.section,
      fromSession: student.academicSession,
      toClass: student.class,
      toSection: student.section,
      toSession,
      performedBy: req.user._id,
    });
    student.academicSession = toSession;
    await student.save();
  }

  res.json({ success: true, data: { repeated: students.length } });
});

// POST /api/promotions/transfer/:studentId
// body: { toClass, toSection, reason }  — transfer within the school.
// Also generates a transfer certificate automatically (#4).
const transferStudent = asyncHandler(async (req, res) => {
  const { toClass, toSection, reason } = req.body;
  const student = await Student.findOne({ _id: req.params.studentId, school: req.schoolId });
  if (!student) throw new ApiError(404, 'Student not found.');

  await PromotionHistory.create({
    school: req.schoolId,
    student: student._id,
    action: 'transferred',
    fromClass: student.class,
    fromSection: student.section,
    fromSession: student.academicSession,
    toClass: toClass || student.class,
    toSection: toSection || student.section,
    reason,
    performedBy: req.user._id,
  });

  if (toClass) student.class = toClass;
  if (toSection) student.section = toSection;
  await student.save();

  const certificate = await Certificate.create({
    school: req.schoolId,
    student: student._id,
    type: 'transfer',
    title: 'Transfer Certificate',
    body: `This is to certify that {{studentName}} has been transferred within the school. Reason: ${reason || 'Not specified'}.`,
    certificateNumber: `CERT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    issuedBy: req.user._id,
  });

  res.json({ success: true, data: { student, certificate } });
});

// POST /api/promotions/graduate  body: { studentIds: [...], graduationYear }
const graduateStudents = asyncHandler(async (req, res) => {
  const { studentIds, graduationYear } = req.body;
  if (!Array.isArray(studentIds) || studentIds.length === 0) {
    throw new ApiError(400, 'studentIds array is required.');
  }

  const students = await Student.find({ _id: { $in: studentIds }, school: req.schoolId });
  for (const student of students) {
    await PromotionHistory.create({
      school: req.schoolId,
      student: student._id,
      action: 'graduated',
      fromClass: student.class,
      fromSection: student.section,
      fromSession: student.academicSession,
      performedBy: req.user._id,
    });

    student.status = 'graduated';
    await student.save();

    const existingAlumni = await Alumni.findOne({ student: student._id, school: req.schoolId });
    if (!existingAlumni) {
      await Alumni.create({
        school: req.schoolId,
        student: student._id,
        graduationYear: graduationYear || new Date().getFullYear(),
        contactEmail: student.email,
        contactPhone: student.phone,
      });
    }
  }

  res.json({ success: true, data: { graduated: students.length } });
});

// GET /api/promotions/history/:studentId
const getStudentHistory = asyncHandler(async (req, res) => {
  const history = await PromotionHistory.find({ student: req.params.studentId, school: req.schoolId })
    .populate('fromClass toClass', 'name')
    .populate('fromSection toSection', 'name')
    .populate('fromSession toSession', 'name')
    .sort({ createdAt: -1 });
  res.json({ success: true, data: history });
});

module.exports = { promoteStudents, repeatStudents, transferStudent, graduateStudents, getStudentHistory };
