const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const SchoolSettings = require('../models/SchoolSettings');
const School = require('../models/School');
const { clearTransporterCache } = require('../services/emailService');

// GET /api/settings
const getSettings = asyncHandler(async (req, res) => {
  let settings = await SchoolSettings.findOne({ school: req.schoolId }).select('+emailConfig.password');
  if (!settings) settings = await SchoolSettings.create({ school: req.schoolId });

  // Password has select:false by default (excluded above via the explicit
  // +select just so we can compute this flag) — never send the actual
  // value back, only whether one is saved.
  const settingsObj = settings.toObject();
  const hasPassword = !!settings.emailConfig?.password;
  if (settingsObj.emailConfig) delete settingsObj.emailConfig.password;
  settingsObj.emailConfig = { ...(settingsObj.emailConfig || {}), hasPassword };

  res.json({ success: true, data: settingsObj });
});

// GET /api/settings/public?school=<slug> — unauthenticated; exposes only
// branding fields (name/logo) so the login screen can display a school's
// identity before anyone has signed in.
//
// Multi-tenant note: without a `school` slug query param, this falls back
// to the single active school on the installation — this keeps existing
// single-school deployments (the default docker-compose setup) working
// with zero extra configuration. A real multi-school deployment should
// pass ?school=<slug> (e.g. resolved from a subdomain on the frontend).
const getPublicSettings = asyncHandler(async (req, res) => {
  let school;
  if (req.query.school) {
    school = await School.findOne({ slug: req.query.school.toLowerCase(), isActive: true });
    if (!school) throw new ApiError(404, 'School not found.');
  } else {
    school = await School.findOne({ isActive: true }).sort({ createdAt: 1 });
  }

  if (!school) {
    return res.json({ success: true, data: { schoolName: 'Institute', logoUrl: '' } });
  }

  let settings = await SchoolSettings.findOne({ school: school._id }).select('schoolName logoUrl');
  if (!settings) settings = await SchoolSettings.create({ school: school._id, schoolName: school.name });

  res.json({ success: true, data: { schoolName: settings.schoolName, logoUrl: settings.logoUrl } });
});

// PUT /api/settings
// emailConfig is handled specially: it's merged field-by-field (via dot
// paths) rather than replacing the whole subdocument, so saving other
// settings — or even other emailConfig fields — never silently wipes an
// already-saved password that the frontend doesn't (and shouldn't) resend.
const updateSettings = asyncHandler(async (req, res) => {
  const { emailConfig, ...rest } = req.body;
  const setOps = { ...rest };

  if (emailConfig) {
    for (const [key, value] of Object.entries(emailConfig)) {
      if (key === 'password' && !value) continue; // blank = "leave unchanged"
      if (key === 'hasPassword') continue; // read-only flag, never persisted
      setOps[`emailConfig.${key}`] = value;
    }
  }

  const settings = await SchoolSettings.findOneAndUpdate(
    { school: req.schoolId },
    { $set: setOps },
    { new: true, upsert: true, runValidators: true }
  ).select('+emailConfig.password');

  if (emailConfig) clearTransporterCache(req.schoolId);

  const settingsObj = settings.toObject();
  const hasPassword = !!settings.emailConfig?.password;
  if (settingsObj.emailConfig) delete settingsObj.emailConfig.password;
  settingsObj.emailConfig = { ...(settingsObj.emailConfig || {}), hasPassword };

  res.json({ success: true, data: settingsObj });
});

module.exports = { getSettings, getPublicSettings, updateSettings };
