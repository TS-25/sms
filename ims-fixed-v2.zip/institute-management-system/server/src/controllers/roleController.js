const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Role = require('../models/Role');
const { PERMISSION_CATALOG } = require('../config/permissions');

// GET /api/roles/permissions — the static catalog, grouped for UI checkboxes
const getPermissionCatalog = asyncHandler(async (req, res) => {
  res.json({ success: true, data: PERMISSION_CATALOG });
});

const getRoles = asyncHandler(async (req, res) => {
  const roles = await Role.find({ school: req.schoolId }).sort({ name: 1 });
  res.json({ success: true, data: roles });
});

const createRole = asyncHandler(async (req, res) => {
  const { name, description, permissions } = req.body;
  const existing = await Role.findOne({ name, school: req.schoolId });
  if (existing) throw new ApiError(409, 'A role with this name already exists.');

  const role = await Role.create({ school: req.schoolId, name, description, permissions });
  res.status(201).json({ success: true, data: role });
});

const updateRole = asyncHandler(async (req, res) => {
  const role = await Role.findOneAndUpdate(
    { _id: req.params.id, school: req.schoolId },
    req.body,
    { new: true, runValidators: true }
  );
  if (!role) throw new ApiError(404, 'Role not found.');
  res.json({ success: true, data: role });
});

const deleteRole = asyncHandler(async (req, res) => {
  const role = await Role.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!role) throw new ApiError(404, 'Role not found.');
  res.json({ success: true, message: 'Role deleted.' });
});

module.exports = { getPermissionCatalog, getRoles, createRole, updateRole, deleteRole };
