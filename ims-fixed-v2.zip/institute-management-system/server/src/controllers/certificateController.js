const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Certificate = require('../models/Certificate');
const Student = require('../models/Student');
const SchoolSettings = require('../models/SchoolSettings');
const { generateCertificatePDF } = require('../services/pdfService');

const getCertificates = asyncHandler(async (req, res) => {
  const filter = { school: req.schoolId };
  if (req.query.student) filter.student = req.query.student;
  const certificates = await Certificate.find(filter).populate('student', 'firstName lastName admissionNumber').sort({ createdAt: -1 });
  res.json({ success: true, data: certificates });
});

const createCertificate = asyncHandler(async (req, res) => {
  const certificateNumber = `CERT-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  const certificate = await Certificate.create({ ...req.body, school: req.schoolId, certificateNumber, issuedBy: req.user._id });
  res.status(201).json({ success: true, data: certificate });
});

const updateCertificate = asyncHandler(async (req, res) => {
  const { type, title, body } = req.body;
  const certificate = await Certificate.findOne({ _id: req.params.id, school: req.schoolId });
  if (!certificate) throw new ApiError(404, 'Certificate not found.');

  if (type !== undefined) certificate.type = type;
  if (title !== undefined) certificate.title = title;
  if (body !== undefined) certificate.body = body;
  await certificate.save();

  res.json({ success: true, data: certificate });
});

const deleteCertificate = asyncHandler(async (req, res) => {
  const certificate = await Certificate.findOneAndDelete({ _id: req.params.id, school: req.schoolId });
  if (!certificate) throw new ApiError(404, 'Certificate not found.');
  res.json({ success: true, message: 'Certificate deleted.' });
});

const downloadCertificate = asyncHandler(async (req, res) => {
  const certificate = await Certificate.findOne({ _id: req.params.id, school: req.schoolId });
  if (!certificate) throw new ApiError(404, 'Certificate not found.');

  const student = await Student.findOne({ _id: certificate.student, school: req.schoolId });
  const school = await SchoolSettings.findOne({ school: req.schoolId });

  generateCertificatePDF(res, { school, student, certificate });
});

module.exports = { getCertificates, createCertificate, updateCertificate, deleteCertificate, downloadCertificate };
