const asyncHandler = require('../utils/asyncHandler');
const Student = require('../models/Student');
const Teacher = require('../models/Teacher');
const User = require('../models/User');
const Class = require('../models/Class');
const Attendance = require('../models/Attendance');
const Fee = require('../models/Fee');
const Payment = require('../models/Payment');
const Expense = require('../models/Expense');
const Notice = require('../models/Notice');
const Exam = require('../models/Exam');
const Assignment = require('../models/Assignment');
const { ROLES } = require('../config/roles');

// GET /api/dashboard/admin
const getAdminStats = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);
  const endOfToday = new Date();
  endOfToday.setHours(23, 59, 59, 999);

  const startOfMonth = new Date();
  startOfMonth.setDate(1);
  startOfMonth.setHours(0, 0, 0, 0);

  const [
    totalStudents,
    totalTeachers,
    totalStaff,
    totalClasses,
    todayAttendance,
    recentAdmissions,
    upcomingExams,
    upcomingNotices,
    monthlyCollectionAgg,
    pendingFeesAgg,
    monthlyExpenseAgg,
  ] = await Promise.all([
    Student.countDocuments({ school: schoolId, status: 'active' }),
    Teacher.countDocuments({ school: schoolId, status: 'active' }),
    User.countDocuments({ school: schoolId, role: { $in: [ROLES.STAFF, ROLES.ACCOUNTANT, ROLES.LIBRARIAN, ROLES.RECEPTIONIST] } }),
    Class.countDocuments({ school: schoolId }),
    Attendance.aggregate([
      { $match: { school: schoolId, date: { $gte: startOfToday, $lte: endOfToday } } },
      { $group: { _id: '$status', count: { $sum: 1 } } },
    ]),
    Student.find({ school: schoolId }).sort({ createdAt: -1 }).limit(5).select('firstName lastName admissionNumber createdAt'),
    Exam.find({ school: schoolId, 'subjects.date': { $gte: new Date() } }).sort({ createdAt: -1 }).limit(5).select('name'),
    Notice.find({ school: schoolId }).sort({ publishDate: -1 }).limit(5).select('title publishDate'),
    Payment.aggregate([
      { $match: { school: schoolId, paidAt: { $gte: startOfMonth } } },
      { $group: { _id: null, total: { $sum: '$amount' } } },
    ]),
    Fee.aggregate([
      { $match: { school: schoolId, status: { $in: ['unpaid', 'partial', 'overdue'] } } },
      { $group: { _id: null, total: { $sum: { $subtract: ['$amount', { $add: ['$discount', '$amountPaid'] }] } } } },
    ]),
    Expense.aggregate([
      { $match: { school: schoolId, date: { $gte: startOfMonth } } },
      { $group: { _id: null, total: { $sum: '$amount' } } },
    ]),
  ]);

  const attendanceMap = todayAttendance.reduce((acc, a) => {
    acc[a._id] = a.count;
    return acc;
  }, {});

  res.json({
    success: true,
    data: {
      totals: { totalStudents, totalTeachers, totalStaff, totalClasses },
      todayAttendance: {
        present: attendanceMap.present || 0,
        absent: attendanceMap.absent || 0,
        late: attendanceMap.late || 0,
        leave: attendanceMap.leave || 0,
      },
      finance: {
        monthlyCollection: monthlyCollectionAgg[0]?.total || 0,
        pendingFees: pendingFeesAgg[0]?.total || 0,
        monthlyExpense: monthlyExpenseAgg[0]?.total || 0,
        netBalance: (monthlyCollectionAgg[0]?.total || 0) - (monthlyExpenseAgg[0]?.total || 0),
      },
      recentAdmissions,
      upcomingExams,
      upcomingNotices,
    },
  });
});

// GET /api/dashboard/teacher
const getTeacherStats = asyncHandler(async (req, res) => {
  const teacher = await Teacher.findOne({ user: req.user._id, school: req.schoolId });

  const [classesCount, assignments, notices] = await Promise.all([
    teacher ? teacher.assignedClasses.length : 0,
    teacher ? Assignment.find({ teacher: teacher._id, school: req.schoolId }).sort({ deadline: 1 }).limit(5) : [],
    Notice.find({ school: req.schoolId, targetAudience: { $in: ['everyone', 'teachers'] } }).sort({ publishDate: -1 }).limit(5),
  ]);

  res.json({ success: true, data: { classesCount, assignments, notices } });
});

// GET /api/dashboard/student
const getStudentStats = asyncHandler(async (req, res) => {
  const student = await Student.findOne({ user: req.user._id, school: req.schoolId }).populate('class section');
  if (!student) return res.json({ success: true, data: {} });

  const [attendanceRecords, fees, notices] = await Promise.all([
    Attendance.find({ student: student._id, school: req.schoolId }),
    Fee.find({ student: student._id, school: req.schoolId, status: { $ne: 'paid' } }),
    Notice.find({ school: req.schoolId, targetAudience: { $in: ['everyone', 'students'] } }).sort({ publishDate: -1 }).limit(5),
  ]);

  const present = attendanceRecords.filter((a) => a.status === 'present').length;
  const attendancePercentage = attendanceRecords.length
    ? Math.round((present / attendanceRecords.length) * 10000) / 100
    : 0;

  res.json({
    success: true,
    data: {
      student,
      attendancePercentage,
      pendingFees: fees,
      notices,
    },
  });
});

module.exports = { getAdminStats, getTeacherStats, getStudentStats };
