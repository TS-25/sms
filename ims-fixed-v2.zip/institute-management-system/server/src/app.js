const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const mongoSanitize = require('express-mongo-sanitize');
const rateLimit = require('express-rate-limit');
const path = require('path');

const routes = require('./routes');
const { errorConverter, errorHandler, notFound } = require('./middleware/errorHandler');

const app = express();

// Behind a reverse proxy (Render/Railway/Heroku-style hosts) so req.ip and
// secure cookies work correctly.
app.set('trust proxy', 1);

app.use(helmet());

// CORS is driven entirely by CLIENT_URL so this never has to be hardcoded
// per-deployment. Add more comma-separated origins by extending this list.
const allowedOrigins = (process.env.CLIENT_URL || 'http://localhost:5173')
  .split(',')
  .map((o) => o.trim());

// Browsers treat http://localhost and http://127.0.0.1 as different origins
// even though they're the same machine, which trips people up in local/
// Docker setups depending on which one they type into the address bar.
// This normalizes only that specific loopback pair for comparison — it
// does not affect matching for any real (non-loopback) domain.
const normalizeLoopback = (origin) =>
  origin.replace('://127.0.0.1', '://localhost');

const normalizedAllowedOrigins = allowedOrigins.map(normalizeLoopback);

app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin || normalizedAllowedOrigins.includes(normalizeLoopback(origin))) {
        return callback(null, true);
      }
      callback(new Error('Not allowed by CORS'));
    },
    credentials: true,
  })
);

// The payment webhook must be mounted BEFORE express.json() with a raw
// body parser — Stripe (and most providers) sign the exact raw bytes of
// the request, so JSON-parsing it first would break signature
// verification in paymentProviderService.js. This is deliberately outside
// the /api router and its requireSchool/protect chain, since the caller
// is the payment provider's servers, not a logged-in user.
app.post(
  '/api/fees/webhook',
  express.raw({ type: 'application/json' }),
  require('./controllers/feeController').handlePaymentWebhook
);

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());
app.use(mongoSanitize());

// General API rate limiting (auth routes have their own stricter limiter).
app.use(
  '/api',
  rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 300,
    standardHeaders: true,
    legacyHeaders: false,
  })
);

// Serve locally-uploaded files (only relevant when STORAGE_PROVIDER=local).
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

app.use('/api', routes);

app.use(notFound);
app.use(errorConverter);
app.use(errorHandler);

module.exports = app;
