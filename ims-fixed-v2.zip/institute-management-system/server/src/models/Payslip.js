const mongoose = require('mongoose');

const payslipSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    employee: { type: mongoose.Schema.Types.ObjectId, required: true, refPath: 'employeeModel' },
    employeeModel: { type: String, enum: ['Teacher', 'Staff'], required: true },
    month: { type: Number, required: true }, // 1-12
    year: { type: Number, required: true },
    basicSalary: { type: Number, required: true },
    allowances: { type: Number, default: 0 },
    deductions: { type: Number, default: 0 },
    bonus: { type: Number, default: 0 },
    netPay: { type: Number, required: true },
    status: { type: String, enum: ['pending', 'paid'], default: 'pending' },
    paidAt: { type: Date },
  },
  { timestamps: true }
);

payslipSchema.index({ employee: 1, month: 1, year: 1, school: 1 }, { unique: true });

module.exports = mongoose.model('Payslip', payslipSchema);
