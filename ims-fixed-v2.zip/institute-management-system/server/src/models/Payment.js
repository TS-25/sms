const mongoose = require('mongoose');

const paymentSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    fee: { type: mongoose.Schema.Types.ObjectId, ref: 'Fee', required: true },
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    amount: { type: Number, required: true },
    method: {
      type: String,
      enum: ['cash', 'card', 'bank_transfer', 'online', 'cheque'],
      default: 'cash',
    },
    receiptNumber: { type: String, required: true },
    paidAt: { type: Date, default: Date.now },
    receivedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    notes: { type: String },
  },
  { timestamps: true }
);

paymentSchema.index({ receiptNumber: 1, school: 1 }, { unique: true });

module.exports = mongoose.model('Payment', paymentSchema);
