const mongoose = require('mongoose');

// #49 Positive-behavior points, separate from Achievement (a bigger,
// named accomplishment) — merit points are small, frequent, teacher-given.
const meritPointSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    points: { type: Number, required: true },
    reason: { type: String, required: true },
    givenBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('MeritPoint', meritPointSchema);
