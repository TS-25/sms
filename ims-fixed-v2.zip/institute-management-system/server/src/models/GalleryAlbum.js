const mongoose = require('mongoose');

const galleryImageSchema = new mongoose.Schema(
  {
    url: { type: String, required: true },
    caption: { type: String },
  },
  { _id: true, timestamps: true }
);

// #44 Photo gallery — albums containing images, each independently
// public/private so an admin can stage an album before releasing it.
const galleryAlbumSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    title: { type: String, required: true },
    category: { type: String },
    isPublic: { type: Boolean, default: false },
    images: [galleryImageSchema],
  },
  { timestamps: true }
);

module.exports = mongoose.model('GalleryAlbum', galleryAlbumSchema);
