const mongoose = require('mongoose');

// #48 Discipline records — access restricted to authorized staff only
// (see disciplineRoutes.js), since this is sensitive behavioral data.
const disciplineIncidentSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    date: { type: Date, default: Date.now },
    description: { type: String, required: true },
    actionTaken: { type: String },
    followUp: { type: String },
    recordedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('DisciplineIncident', disciplineIncidentSchema);
