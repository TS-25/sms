const mongoose = require('mongoose');

const periodSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    day: {
      type: String,
      enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
      required: true,
    },
    startTime: { type: String, required: true }, // "09:00"
    endTime: { type: String, required: true }, // "09:45"
    subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject' },
    teacher: { type: mongoose.Schema.Types.ObjectId, ref: 'Teacher' },
    room: { type: String },
  },
  { _id: true }
);

const timetableSchema = new mongoose.Schema(
  {
    class: { type: mongoose.Schema.Types.ObjectId, ref: 'Class', required: true },
    section: { type: mongoose.Schema.Types.ObjectId, ref: 'Section', required: true },
    academicSession: { type: mongoose.Schema.Types.ObjectId, ref: 'AcademicSession' },
    periods: [periodSchema],
  },
  { timestamps: true }
);

timetableSchema.index({ class: 1, section: 1, academicSession: 1 }, { unique: true });

module.exports = mongoose.model('Timetable', timetableSchema);
