const mongoose = require('mongoose');

const stopSchema = new mongoose.Schema(
  {
    // A stop belongs to its parent route, so keeping a second required
    // school field here creates validation failures when seeding routes.
    name: { type: String, required: true, trim: true },
    pickupTime: { type: String, trim: true }, // "07:30"
    dropTime: { type: String, trim: true }, // "14:30"
    fare: { type: Number, default: 0, min: 0 },
  },
  { _id: true }
);

const routeSchema = new mongoose.Schema(
  {
    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'School',
      required: true,
      index: true,
    },
    name: { type: String, required: true, trim: true },
    stops: { type: [stopSchema], default: [] },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Route', routeSchema);
