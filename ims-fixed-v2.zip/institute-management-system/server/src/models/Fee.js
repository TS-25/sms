const mongoose = require('mongoose');

// Represents a single fee invoice/line-item charged to a student
// (e.g. Tuition Fee - Term 1). Payments reference this document.
const feeSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    academicSession: { type: mongoose.Schema.Types.ObjectId, ref: 'AcademicSession' },
    category: {
      type: String,
      enum: ['tuition', 'admission', 'exam', 'library', 'transport', 'hostel', 'other'],
      required: true,
    },
    title: { type: String, required: true },
    amount: { type: Number, required: true },
    discount: { type: Number, default: 0 },
    dueDate: { type: Date, required: true },
    status: {
      type: String,
      enum: ['unpaid', 'partial', 'paid', 'overdue'],
      default: 'unpaid',
    },
    amountPaid: { type: Number, default: 0 },
  },
  { timestamps: true }
);

feeSchema.virtual('amountDue').get(function amountDue() {
  return Math.max(this.amount - this.discount - this.amountPaid, 0);
});
feeSchema.set('toJSON', { virtuals: true });
feeSchema.set('toObject', { virtuals: true });

module.exports = mongoose.model('Fee', feeSchema);
