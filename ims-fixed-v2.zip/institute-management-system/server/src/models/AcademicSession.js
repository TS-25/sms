const mongoose = require('mongoose');

const academicSessionSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    name: { type: String, required: true, trim: true }, // e.g. "2025-2026"
    startDate: { type: Date, required: true },
    endDate: { type: Date, required: true },
    isCurrent: { type: Boolean, default: false },
  },
  { timestamps: true }
);

academicSessionSchema.index({ name: 1, school: 1 }, { unique: true });

module.exports = mongoose.model('AcademicSession', academicSessionSchema);
