const mongoose = require('mongoose');

// #52 Sports management.
const sportsTeamSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    name: { type: String, required: true },
    sport: { type: String, required: true },
    coach: { type: mongoose.Schema.Types.ObjectId, ref: 'Teacher' },
    players: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Student' }],
    matches: [
      {
        opponent: String,
        date: Date,
        location: String,
        result: { type: String, enum: ['win', 'loss', 'draw', 'upcoming'], default: 'upcoming' },
        score: String,
      },
    ],
  },
  { timestamps: true }
);

module.exports = mongoose.model('SportsTeam', sportsTeamSchema);
