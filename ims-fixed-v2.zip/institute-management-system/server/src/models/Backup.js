const mongoose = require('mongoose');

// Metadata for a database backup. The actual dump lives on disk (or
// object storage, if extended later); this record just tracks history
// and status so the platform-admin UI has something to list (#34).
const backupSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', index: true }, // null for a full-instance backup
    status: { type: String, enum: ['running', 'completed', 'failed'], default: 'running' },
    filePath: { type: String },
    fileSizeBytes: { type: Number },
    errorMessage: { type: String },
    triggeredBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Backup', backupSchema);
