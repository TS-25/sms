const mongoose = require('mongoose');

const bedSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    bedNumber: { type: String, required: true },
    isOccupied: { type: Boolean, default: false },
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student' },
  },
  { _id: true }
);

const roomSchema = new mongoose.Schema(
  {
    roomNumber: { type: String, required: true },
    capacity: { type: Number, default: 4 },
    beds: [bedSchema],
  },
  { _id: true }
);

const hostelSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true }, // building name
    type: { type: String, enum: ['boys', 'girls', 'mixed'], default: 'mixed' },
    warden: { type: String },
    wardenPhone: { type: String },
    monthlyFee: { type: Number, default: 0 },
    rooms: [roomSchema],
  },
  { timestamps: true }
);

module.exports = mongoose.model('Hostel', hostelSchema);
