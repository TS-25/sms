const mongoose = require('mongoose');

// Tracks every login attempt (success and failure) for the security audit
// dashboard (#88) — separate from AuditLog since this needs to record
// attempts against emails that might not even resolve to a valid user
// (e.g. brute-force probing), which AuditLog's `user` reference can't do.
const loginAttemptSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', index: true }, // null if email didn't match any user
    email: { type: String, required: true, lowercase: true },
    success: { type: Boolean, required: true },
    reason: { type: String }, // e.g. "wrong_password", "2fa_required", "account_deactivated"
    ip: { type: String },
    userAgent: { type: String },
  },
  { timestamps: true }
);

loginAttemptSchema.index({ createdAt: -1 });

module.exports = mongoose.model('LoginAttempt', loginAttemptSchema);
