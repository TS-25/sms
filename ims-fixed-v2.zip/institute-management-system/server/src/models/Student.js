const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    admissionNumber: { type: String, required: true, trim: true },
    rollNumber: { type: String, trim: true },
    firstName: { type: String, required: true, trim: true },
    lastName: { type: String, trim: true },
    photoUrl: { type: String },
    dateOfBirth: { type: Date },
    gender: { type: String, enum: ['male', 'female', 'other'] },
    bloodGroup: { type: String },
    address: { type: String },
    phone: { type: String },
    email: { type: String, lowercase: true, trim: true },

    guardianName: { type: String },
    guardianPhone: { type: String },
    guardianRelation: { type: String },
    emergencyContact: { type: String },

    parent: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },

    class: { type: mongoose.Schema.Types.ObjectId, ref: 'Class', required: true },
    section: { type: mongoose.Schema.Types.ObjectId, ref: 'Section', required: true },
    academicSession: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'AcademicSession',
      required: true,
    },

    admissionDate: { type: Date, default: Date.now },
    status: {
      type: String,
      enum: ['active', 'inactive', 'graduated', 'transferred'],
      default: 'active',
    },
  },
  { timestamps: true }
);

studentSchema.index({ firstName: 'text', lastName: 'text', admissionNumber: 'text' });
studentSchema.virtual('fullName').get(function fullName() {
  return [this.firstName, this.lastName].filter(Boolean).join(' ');
});
studentSchema.set('toJSON', { virtuals: true });
studentSchema.set('toObject', { virtuals: true });

studentSchema.index({ admissionNumber: 1, school: 1 }, { unique: true });

module.exports = mongoose.model('Student', studentSchema);
