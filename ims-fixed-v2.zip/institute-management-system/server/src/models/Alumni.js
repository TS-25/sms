const mongoose = require('mongoose');

const alumniSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true, unique: true },
    graduationYear: { type: Number, required: true },
    currentOccupation: { type: String },
    higherEducation: { type: String },
    contactEmail: { type: String, lowercase: true, trim: true },
    contactPhone: { type: String },
    notes: { type: String },
  },
  { timestamps: true }
);

alumniSchema.index({ graduationYear: 1, school: 1 });

module.exports = mongoose.model('Alumni', alumniSchema);
