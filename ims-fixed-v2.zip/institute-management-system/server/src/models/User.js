const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const { ALL_ROLES } = require('../config/roles');

const userSchema = new mongoose.Schema(
  {
    // Which tenant this account belongs to. Only SUPER_ADMIN (a
    // platform-level role — see config/roles.js) has no school; every
    // other role must belong to exactly one, and every tenant-scoped
    // query in the app filters by it.
    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'School',
      required: function requiredUnlessSuperAdmin() {
        return this.role !== 'super_admin';
      },
    },
    name: { type: String, required: true, trim: true },
    email: {
      type: String,
      required: true,
      unique: true, // global, not per-school — see note above login() in authController.js
      lowercase: true,
      trim: true,
    },
    password: { type: String, required: true, minlength: 6, select: false },
    role: { type: String, enum: ALL_ROLES, required: true, index: true },
    // Optional fine-grained permission bundle, additive to `role` — see
    // config/permissions.js and utils/permissions.js.
    customRole: { type: mongoose.Schema.Types.ObjectId, ref: 'Role' },
    phone: { type: String, trim: true },
    avatarUrl: { type: String },
    isActive: { type: Boolean, default: true },

    // Links this account to its role-specific profile document, if any
    // (e.g. a "teacher" user links to a Teacher doc with employment details).
    profileRef: {
      kind: { type: String, enum: ['Student', 'Teacher', 'Staff', 'Parent'] },
      id: { type: mongoose.Schema.Types.ObjectId, refPath: 'profileRef.kind' },
    },

    resetPasswordToken: { type: String, select: false },
    resetPasswordExpires: { type: Date, select: false },

    refreshTokenVersion: { type: Number, default: 0 }, // bump to invalidate all refresh tokens
    lastLoginAt: { type: Date },

    // #37 optional TOTP-based 2FA for administrators — see utils/totp.js.
    twoFactorEnabled: { type: Boolean, default: false },
    twoFactorSecret: { type: String, select: false },
    twoFactorRecoveryCodes: { type: [String], select: false },
  },
  { timestamps: true }
);

userSchema.pre('save', async function hashPassword(next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

userSchema.methods.comparePassword = function comparePassword(candidate) {
  return bcrypt.compare(candidate, this.password);
};

userSchema.methods.toSafeObject = function toSafeObject() {
  const obj = this.toObject();
  delete obj.password;
  delete obj.resetPasswordToken;
  delete obj.resetPasswordExpires;
  return obj;
};

module.exports = mongoose.model('User', userSchema);
