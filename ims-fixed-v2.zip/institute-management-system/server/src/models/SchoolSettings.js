const mongoose = require('mongoose');

const gradingTierSchema = new mongoose.Schema(
  {
    minPercentage: { type: Number, required: true },
    grade: { type: String, required: true, trim: true },
    gpa: { type: Number, required: true },
  },
  { _id: false }
);

const DEFAULT_GRADING_SCALE = [
  { minPercentage: 90, grade: 'A+', gpa: 5.0 },
  { minPercentage: 80, grade: 'A', gpa: 4.0 },
  { minPercentage: 70, grade: 'A-', gpa: 3.5 },
  { minPercentage: 60, grade: 'B', gpa: 3.0 },
  { minPercentage: 50, grade: 'C', gpa: 2.0 },
  { minPercentage: 33, grade: 'D', gpa: 1.0 },
  { minPercentage: 0, grade: 'F', gpa: 0.0 },
];

// Per-school settings document. One per tenant (unique on `school`).
// Older single-school deployments that never set up multi-tenancy will
// have exactly one School document and one settings document — the
// `getPublicSettings` fallback below keeps that working with zero config.
const schoolSettingsSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, unique: true },
    schoolName: { type: String, default: 'My School' },
    logoUrl: { type: String },
    address: { type: String },
    phone: { type: String },
    email: { type: String },
    website: { type: String },
    currency: { type: String, default: 'USD' },
    dateFormat: { type: String, default: 'DD/MM/YYYY' },
    timezone: { type: String, default: 'UTC' },
    currentAcademicSession: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'AcademicSession',
    },
    // Editable grading scale used to compute exam grades/GPA. Sorted by
    // minPercentage descending when evaluated — see examController.js.
    gradingScale: { type: [gradingTierSchema], default: DEFAULT_GRADING_SCALE },

    // Per-institute email provider config, set by the admin in Settings
    // instead of a fixed server-wide .env value — important in a
    // multi-tenant install where different institutes may want their own
    // sending domain/credentials. `password` is select:false so it's never
    // returned by a plain GET /settings; see emailService.js and
    // settingsController.js's emailConfigured flag.
    emailConfig: {
      provider: { type: String, enum: ['none', 'smtp'], default: 'none' },
      host: { type: String },
      port: { type: Number, default: 587 },
      secure: { type: Boolean, default: false },
      user: { type: String },
      password: { type: String, select: false },
      fromAddress: { type: String },
      fromName: { type: String },
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('SchoolSettings', schoolSettingsSchema);
module.exports.DEFAULT_GRADING_SCALE = DEFAULT_GRADING_SCALE;
