const mongoose = require('mongoose');

const auditLogSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    userLabel: { type: String },
    action: { type: String, required: true }, // e.g. "created", "updated", "deleted"
    entity: { type: String, required: true }, // e.g. "Student"
    entityId: { type: mongoose.Schema.Types.ObjectId },
    ip: { type: String },
    meta: { type: mongoose.Schema.Types.Mixed },
  },
  { timestamps: true }
);

auditLogSchema.index({ createdAt: -1 });

module.exports = mongoose.model('AuditLog', auditLogSchema);
