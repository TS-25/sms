const mongoose = require('mongoose');

// #46 Parent-teacher meeting scheduling — a teacher opens slots, a parent
// books one.
const meetingSlotSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    teacher: { type: mongoose.Schema.Types.ObjectId, ref: 'Teacher', required: true },
    startTime: { type: Date, required: true },
    endTime: { type: Date, required: true },
    isBooked: { type: Boolean, default: false },
    bookedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // the parent/guardian
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student' }, // which child it's about
    status: { type: String, enum: ['open', 'booked', 'completed', 'cancelled'], default: 'open' },
    notes: { type: String },
  },
  { timestamps: true }
);

module.exports = mongoose.model('MeetingSlot', meetingSlotSchema);
