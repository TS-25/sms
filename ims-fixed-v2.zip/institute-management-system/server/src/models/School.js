const mongoose = require('mongoose');

// Every tenant-scoped document in the system carries a `school` field
// referencing this collection. This is the root of data isolation: no
// query anywhere should ever run without a school filter except from
// platform-level (super_admin) routes that intentionally operate across
// tenants (see platformController.js).
const schoolSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    slug: { type: String, required: true, unique: true, trim: true, lowercase: true },
    logoUrl: { type: String },
    address: { type: String },
    phone: { type: String },
    email: { type: String, lowercase: true, trim: true },
    website: { type: String },

    isActive: { type: Boolean, default: true },

    // Subscription-ready without implementing real billing — see doc #82.
    plan: { type: String, enum: ['free', 'basic', 'pro', 'enterprise'], default: 'free' },

    // Feature flags (#81, #83). Modules not listed here default to
    // enabled for backward compatibility with the single-school setup;
    // explicitly set a module to false to disable it for this school.
    enabledModules: {
      library: { type: Boolean, default: true },
      transport: { type: Boolean, default: true },
      hostel: { type: Boolean, default: true },
      onlineExams: { type: Boolean, default: false },
      onlinePayments: { type: Boolean, default: false },
      chat: { type: Boolean, default: false },
      publicWebsite: { type: Boolean, default: false },
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('School', schoolSchema);
