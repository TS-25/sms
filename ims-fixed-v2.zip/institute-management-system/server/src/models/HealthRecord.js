const mongoose = require('mongoose');

// #47 Student health records — strictly limited access (nurse/admin only,
// enforced via the 'health.view'/'health.manage' permissions — see
// healthRoutes.js and config/permissions.js). One record per student.
const healthRecordSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true, unique: true },
    allergies: { type: String },
    emergencyContact: { type: String },
    emergencyContactPhone: { type: String },
    medicalNotes: { type: String },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('HealthRecord', healthRecordSchema);
