const mongoose = require('mongoose');

const examSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    name: { type: String, required: true, trim: true }, // e.g. "Mid-Term 2026"
    examType: { type: String, default: 'general' },
    academicSession: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'AcademicSession',
      required: true,
    },
    class: { type: mongoose.Schema.Types.ObjectId, ref: 'Class', required: true },
    subjects: [
      {
        subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject' },
        date: { type: Date },
        fullMarks: { type: Number, default: 100 },
        passMarks: { type: Number, default: 33 },
      },
    ],
    resultPublished: { type: Boolean, default: false },
    resultLocked: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Exam', examSchema);
