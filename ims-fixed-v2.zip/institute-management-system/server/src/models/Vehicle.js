const mongoose = require('mongoose');

const vehicleSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    vehicleNumber: { type: String, required: true, trim: true },
    model: { type: String, trim: true },
    capacity: { type: Number, default: 40 },
    driverName: { type: String, trim: true },
    driverPhone: { type: String, trim: true },
    driverLicenseNumber: { type: String, trim: true },
    route: { type: mongoose.Schema.Types.ObjectId, ref: 'Route' },
    status: { type: String, enum: ['active', 'maintenance', 'inactive'], default: 'active' },
  },
  { timestamps: true }
);

vehicleSchema.index({ vehicleNumber: 1, school: 1 }, { unique: true });

module.exports = mongoose.model('Vehicle', vehicleSchema);
