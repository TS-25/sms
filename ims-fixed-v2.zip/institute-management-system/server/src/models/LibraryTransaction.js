const mongoose = require('mongoose');

const libraryTransactionSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    book: { type: mongoose.Schema.Types.ObjectId, ref: 'Book', required: true },
    // Borrower can be a student or a teacher — borrowerModel disambiguates.
    borrower: { type: mongoose.Schema.Types.ObjectId, required: true, refPath: 'borrowerModel' },
    borrowerModel: { type: String, enum: ['Student', 'Teacher'], required: true },
    issueDate: { type: Date, default: Date.now },
    dueDate: { type: Date, required: true },
    returnDate: { type: Date },
    status: { type: String, enum: ['issued', 'returned', 'overdue', 'lost'], default: 'issued' },
    fineAmount: { type: Number, default: 0 },
    fineRatePerDay: { type: Number, default: 1 },
    issuedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

libraryTransactionSchema.index({ borrower: 1, status: 1 });

module.exports = mongoose.model('LibraryTransaction', libraryTransactionSchema);
