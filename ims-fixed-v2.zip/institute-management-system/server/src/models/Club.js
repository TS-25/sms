const mongoose = require('mongoose');

// #51 Club management.
const clubSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    name: { type: String, required: true },
    description: { type: String },
    teacher: { type: mongoose.Schema.Types.ObjectId, ref: 'Teacher' },
    members: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Student' }],
    activities: [{ title: String, date: Date, description: String }],
  },
  { timestamps: true }
);

module.exports = mongoose.model('Club', clubSchema);
