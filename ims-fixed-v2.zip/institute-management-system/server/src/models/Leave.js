const mongoose = require('mongoose');

const leaveSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    applicant: { type: mongoose.Schema.Types.ObjectId, required: true, refPath: 'applicantModel' },
    applicantModel: { type: String, enum: ['Teacher', 'Staff', 'Student', 'User'], required: true },
    leaveType: {
      type: String,
      enum: ['sick', 'casual', 'earned', 'maternity', 'paternity', 'other'],
      default: 'casual',
    },
    startDate: { type: Date, required: true },
    endDate: { type: Date, required: true },
    reason: { type: String, required: true },
    status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
    reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    reviewNote: { type: String },
  },
  { timestamps: true }
);

leaveSchema.index({ applicant: 1, status: 1 });

module.exports = mongoose.model('Leave', leaveSchema);
