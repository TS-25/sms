const mongoose = require('mongoose');

// Customizable email templates. `type` matches a known trigger point in
// the app (see services/emailService.js's sendTemplatedEmail). Body
// supports {{variable}} placeholders substituted at send time.
const emailTemplateSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    type: {
      type: String,
      enum: ['welcome', 'password_reset', 'fee_reminder', 'payment_confirmation', 'result_published', 'notice_published'],
      required: true,
    },
    subject: { type: String, required: true },
    body: { type: String, required: true },
  },
  { timestamps: true }
);

emailTemplateSchema.index({ type: 1, school: 1 }, { unique: true });

module.exports = mongoose.model('EmailTemplate', emailTemplateSchema);
