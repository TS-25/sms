const mongoose = require('mongoose');
const { ALL_PERMISSIONS } = require('../config/permissions');

// A school-defined custom role bundling a set of fine-grained permissions.
// Assigned to a User via User.customRole — additive to that user's fixed
// `role` field (see config/roles.js), not a replacement for it.
const roleSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    name: { type: String, required: true, trim: true },
    description: { type: String },
    permissions: {
      type: [String],
      validate: {
        validator: (arr) => arr.every((p) => ALL_PERMISSIONS.includes(p)),
        message: 'One or more permissions are not recognized.',
      },
      default: [],
    },
  },
  { timestamps: true }
);

roleSchema.index({ name: 1, school: 1 }, { unique: true });

module.exports = mongoose.model('Role', roleSchema);
