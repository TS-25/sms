const mongoose = require('mongoose');

const marksEntrySchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', required: true },
    marksObtained: { type: Number, required: true },
    fullMarks: { type: Number, required: true },
    passMarks: { type: Number, required: true },
  },
  { _id: false }
);

const examResultSchema = new mongoose.Schema(
  {
    exam: { type: mongoose.Schema.Types.ObjectId, ref: 'Exam', required: true },
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    marks: [marksEntrySchema],
    totalFullMarks: { type: Number },
    totalObtained: { type: Number },
    percentage: { type: Number },
    grade: { type: String },
    gpa: { type: Number },
    isPass: { type: Boolean },
    rank: { type: Number },
    remarks: { type: String },
  },
  { timestamps: true }
);

examResultSchema.index({ exam: 1, student: 1 }, { unique: true });

// Note: grade/GPA are computed in examController.js (upsertResult) using
// the school's configurable gradingScale from SchoolSettings, not here —
// a pre-save hook can't cleanly depend on a separate collection's live
// settings without an extra query on every save, so the controller
// computes totals/grade once and sets them directly before saving.

module.exports = mongoose.model('ExamResult', examResultSchema);
