const mongoose = require('mongoose');

const certificateSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    type: {
      type: String,
      enum: ['character', 'transfer', 'participation', 'achievement', 'bonafide', 'other'],
      required: true,
    },
    title: { type: String, required: true },
    body: { type: String, required: true }, // free-text certificate content, supports simple placeholders
    issueDate: { type: Date, default: Date.now },
    certificateNumber: { type: String, required: true },
    issuedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

certificateSchema.index({ certificateNumber: 1, school: 1 }, { unique: true });

module.exports = mongoose.model('Certificate', certificateSchema);
