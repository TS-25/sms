const mongoose = require('mongoose');

const sectionSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    name: { type: String, required: true, trim: true }, // e.g. "A"
    class: { type: mongoose.Schema.Types.ObjectId, ref: 'Class', required: true },
    classTeacher: { type: mongoose.Schema.Types.ObjectId, ref: 'Teacher' },
    capacity: { type: Number, default: 40 },
  },
  { timestamps: true }
);

sectionSchema.index({ name: 1, class: 1 }, { unique: true });

module.exports = mongoose.model('Section', sectionSchema);
