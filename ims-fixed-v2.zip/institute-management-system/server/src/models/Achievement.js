const mongoose = require('mongoose');

// #49, #50 Student achievements/merit records.
const achievementSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    category: { type: String, enum: ['academic', 'sports', 'cultural', 'competition', 'other'], default: 'other' },
    title: { type: String, required: true },
    description: { type: String },
    date: { type: Date, default: Date.now },
    recordedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Achievement', achievementSchema);
