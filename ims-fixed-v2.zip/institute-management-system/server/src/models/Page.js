const mongoose = require('mongoose');

// Simple CMS page (#42, #43). Public pages are readable without auth via
// the /public/pages endpoint; only admins can create/edit.
const pageSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    slug: { type: String, required: true, trim: true, lowercase: true },
    title: { type: String, required: true },
    content: { type: String, required: true }, // HTML or markdown, rendered as-is by the frontend
    isPublished: { type: Boolean, default: false },
  },
  { timestamps: true }
);

pageSchema.index({ slug: 1, school: 1 }, { unique: true });

module.exports = mongoose.model('Page', pageSchema);
