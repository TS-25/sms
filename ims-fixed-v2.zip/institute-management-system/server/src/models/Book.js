const mongoose = require('mongoose');

const bookSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    title: { type: String, required: true, trim: true },
    author: { type: String, trim: true },
    isbn: { type: String, sparse: true, trim: true },
    category: { type: String, trim: true },
    publisher: { type: String, trim: true },
    quantity: { type: Number, default: 1, min: 0 },
    availableQuantity: { type: Number, default: 1, min: 0 },
    coverImageUrl: { type: String },
    shelfLocation: { type: String },
  },
  { timestamps: true }
);

bookSchema.index({ title: 'text', author: 'text', isbn: 'text' });
bookSchema.index({ isbn: 1, school: 1 }, { unique: true, sparse: true });

module.exports = mongoose.model('Book', bookSchema);
