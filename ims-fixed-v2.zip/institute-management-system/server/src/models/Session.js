const mongoose = require('mongoose');

// One record per issued refresh token, so a user (or an admin) can see and
// revoke individual active sessions (#87) rather than only being able to
// invalidate everything at once.
const sessionSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', index: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    tokenId: { type: String, required: true, unique: true }, // jti claim of the refresh token
    device: { type: String },
    browser: { type: String },
    ip: { type: String },
    lastActiveAt: { type: Date, default: Date.now },
    revoked: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Session', sessionSchema);
