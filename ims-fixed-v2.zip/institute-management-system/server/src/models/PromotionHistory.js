const mongoose = require('mongoose');

// A permanent record of every promotion/repeat/transfer/graduation action —
// never overwritten, so a student's full academic history stays intact
// even after they move classes or sessions (doc requirement #3: "never
// overwrite previous session data").
const promotionHistorySchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    action: { type: String, enum: ['promoted', 'repeated', 'transferred', 'graduated'], required: true },
    fromClass: { type: mongoose.Schema.Types.ObjectId, ref: 'Class' },
    fromSection: { type: mongoose.Schema.Types.ObjectId, ref: 'Section' },
    fromSession: { type: mongoose.Schema.Types.ObjectId, ref: 'AcademicSession' },
    toClass: { type: mongoose.Schema.Types.ObjectId, ref: 'Class' },
    toSection: { type: mongoose.Schema.Types.ObjectId, ref: 'Section' },
    toSession: { type: mongoose.Schema.Types.ObjectId, ref: 'AcademicSession' },
    reason: { type: String },
    performedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('PromotionHistory', promotionHistorySchema);
