const mongoose = require('mongoose');

// One salary structure per employee (teacher or staff) — payroll
// generation reads this each month rather than re-entering figures.
const salaryStructureSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    employee: { type: mongoose.Schema.Types.ObjectId, required: true, refPath: 'employeeModel' },
    employeeModel: { type: String, enum: ['Teacher', 'Staff'], required: true },
    basicSalary: { type: Number, required: true },
    allowances: { type: Number, default: 0 },
    deductions: { type: Number, default: 0 },
  },
  { timestamps: true }
);

salaryStructureSchema.index({ employee: 1, school: 1 }, { unique: true });

module.exports = mongoose.model('SalaryStructure', salaryStructureSchema);
