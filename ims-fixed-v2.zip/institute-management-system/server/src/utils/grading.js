const SchoolSettings = require('../models/SchoolSettings');

// Looks up the grade/GPA tier for a given percentage against the school's
// configurable grading scale (falls back to the model's built-in default
// if settings haven't been created yet). Tiers are evaluated from the
// highest minPercentage down, so the scale doesn't need to be pre-sorted
// by the caller.
function resolveGradeTier(percentage, gradingScale) {
  const sorted = [...gradingScale].sort((a, b) => b.minPercentage - a.minPercentage);
  return (
    sorted.find((tier) => percentage >= tier.minPercentage) ||
    sorted[sorted.length - 1] || { grade: 'F', gpa: 0 }
  );
}

// Fetches the current grading scale for a specific school (creating the
// school's settings doc if it doesn't exist yet).
async function getGradingScale(schoolId) {
  let settings = await SchoolSettings.findOne({ school: schoolId }).select('gradingScale');
  if (!settings) settings = await SchoolSettings.create({ school: schoolId });
  return settings.gradingScale && settings.gradingScale.length
    ? settings.gradingScale
    : SchoolSettings.DEFAULT_GRADING_SCALE;
}

// Computes all aggregate result fields for a set of marks entries against
// the school's live grading scale. Used by examController's upsertResult.
async function computeResultFields(marks, schoolId) {
  const gradingScale = await getGradingScale(schoolId);

  const totalFullMarks = marks.reduce((sum, m) => sum + Number(m.fullMarks), 0);
  const totalObtained = marks.reduce((sum, m) => sum + Number(m.marksObtained), 0);
  const percentage = totalFullMarks > 0 ? (totalObtained / totalFullMarks) * 100 : 0;
  const isPass = marks.every((m) => Number(m.marksObtained) >= Number(m.passMarks));
  const tier = resolveGradeTier(percentage, gradingScale);

  return {
    totalFullMarks,
    totalObtained,
    percentage: Math.round(percentage * 100) / 100,
    isPass,
    grade: isPass ? tier.grade : 'F',
    gpa: isPass ? tier.gpa : 0,
    gradingScale,
  };
}

module.exports = { resolveGradeTier, getGradingScale, computeResultFields };
