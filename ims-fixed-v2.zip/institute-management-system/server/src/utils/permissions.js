const Role = require('../models/Role');

// `admin` implicitly has every permission within their own school — they
// never need a custom role assigned. Everyone else only has a permission
// if it's granted via their assigned custom Role document.
async function userHasPermission(user, permission) {
  if (!user) return false;
  if (user.role === 'admin') return true;
  if (!user.customRole) return false;

  const role = user.customRole.permissions
    ? user.customRole // already populated
    : await Role.findById(user.customRole);
  return !!role && role.permissions.includes(permission);
}

module.exports = { userHasPermission };
