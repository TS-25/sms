const AuditLog = require('../models/AuditLog');

// Fire-and-forget audit logger. Never throws — a logging failure must not
// break the primary request. `req.schoolId` is used automatically when
// available; pass `school` explicitly for platform-level actions (e.g.
// creating a School itself) where there's no single-school context.
const logAction = async ({ user, action, entity, entityId, req, meta, school }) => {
  try {
    const schoolId = school || req?.schoolId;
    if (!schoolId) {
      // Platform-level action with genuinely no school context (e.g. a
      // brand-new School being created) — skip rather than violate the
      // AuditLog schema's required `school` field.
      return;
    }
    await AuditLog.create({
      school: schoolId,
      user: user?._id,
      userLabel: user ? `${user.name} (${user.role})` : 'system',
      action,
      entity,
      entityId,
      ip: req?.ip,
      meta,
    });
  } catch (err) {
    console.error('Audit log failure:', err.message);
  }
};

module.exports = logAction;
