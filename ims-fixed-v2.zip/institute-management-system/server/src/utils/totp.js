// RFC 6238 TOTP implementation using only Node's built-in `crypto` module —
// deliberately dependency-free so 2FA works even without an `npm install`
// for a new package. Compatible with standard authenticator apps (Google
// Authenticator, Authy, 1Password, etc).
const crypto = require('crypto');

const STEP_SECONDS = 30;
const DIGITS = 6;

// Base32 encode/decode (RFC 4648) — needed because TOTP secrets and
// authenticator-app QR setup URIs are conventionally base32, not hex.
const BASE32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

function base32Encode(buffer) {
  let bits = '';
  for (const byte of buffer) bits += byte.toString(2).padStart(8, '0');
  let output = '';
  for (let i = 0; i + 5 <= bits.length; i += 5) {
    output += BASE32_ALPHABET[parseInt(bits.slice(i, i + 5), 2)];
  }
  const remainder = bits.length % 5;
  if (remainder) {
    const lastChunk = bits.slice(bits.length - remainder).padEnd(5, '0');
    output += BASE32_ALPHABET[parseInt(lastChunk, 2)];
  }
  return output;
}

function base32Decode(encoded) {
  const clean = encoded.toUpperCase().replace(/=+$/, '');
  let bits = '';
  for (const char of clean) {
    const val = BASE32_ALPHABET.indexOf(char);
    if (val === -1) continue;
    bits += val.toString(2).padStart(5, '0');
  }
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) {
    bytes.push(parseInt(bits.slice(i, i + 8), 2));
  }
  return Buffer.from(bytes);
}

function generateSecret() {
  return base32Encode(crypto.randomBytes(20)); // 160-bit secret, standard for TOTP
}

function hotp(secretBuffer, counter) {
  const counterBuffer = Buffer.alloc(8);
  counterBuffer.writeBigUInt64BE(BigInt(counter));

  const hmac = crypto.createHmac('sha1', secretBuffer).update(counterBuffer).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code =
    ((hmac[offset] & 0x7f) << 24) |
    ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) |
    (hmac[offset + 3] & 0xff);

  return String(code % 10 ** DIGITS).padStart(DIGITS, '0');
}

function generateTOTP(base32Secret, forTime = Date.now()) {
  const counter = Math.floor(forTime / 1000 / STEP_SECONDS);
  return hotp(base32Decode(base32Secret), counter);
}

// Allows a ±1 step window (±30s) to tolerate minor clock drift between the
// server and the user's phone — standard practice for TOTP verification.
function verifyTOTP(base32Secret, token, forTime = Date.now()) {
  for (const drift of [-1, 0, 1]) {
    const counter = Math.floor(forTime / 1000 / STEP_SECONDS) + drift;
    if (hotp(base32Decode(base32Secret), counter) === token) return true;
  }
  return false;
}

function generateRecoveryCodes(count = 8) {
  return Array.from({ length: count }, () => crypto.randomBytes(5).toString('hex'));
}

// otpauth:// URI for QR-code setup in authenticator apps.
function getSetupUri({ secret, accountName, issuer }) {
  const params = new URLSearchParams({ secret, issuer, algorithm: 'SHA1', digits: String(DIGITS), period: String(STEP_SECONDS) });
  return `otpauth://totp/${encodeURIComponent(issuer)}:${encodeURIComponent(accountName)}?${params.toString()}`;
}

module.exports = { generateSecret, generateTOTP, verifyTOTP, generateRecoveryCodes, getSetupUri };
