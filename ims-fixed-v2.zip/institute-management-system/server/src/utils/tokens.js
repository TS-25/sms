const jwt = require('jsonwebtoken');
const crypto = require('crypto');

const generateAccessToken = (user) =>
  jwt.sign(
    { id: user._id, role: user.role, tokenType: 'access' },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '15m' }
  );

// jti (JWT ID) uniquely identifies this specific refresh token, so it can
// be tracked/revoked individually as a "session" (#87) — returned
// alongside the token so the caller can persist it in the Session model.
const generateRefreshToken = (user) => {
  const jti = crypto.randomUUID();
  const token = jwt.sign(
    { id: user._id, tokenType: 'refresh', jti },
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d' }
  );
  return { token, jti };
};

const verifyAccessToken = (token) => jwt.verify(token, process.env.JWT_SECRET);

const verifyRefreshToken = (token) =>
  jwt.verify(token, process.env.JWT_REFRESH_SECRET);

module.exports = {
  generateAccessToken,
  generateRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
};
