// When an admin creates a student/teacher/staff account without typing an
// explicit password, we default it to the person's phone number — easier
// for schools to communicate ("your password is your phone number") than
// a generated string. Falls back to the old "<id>@123" scheme if no phone
// was given, or if the phone is too short to satisfy the password's
// minimum length requirement.
const MIN_PASSWORD_LENGTH = 6;

function defaultPassword(phone, fallbackId) {
  const cleanedPhone = (phone || '').replace(/\s+/g, '');
  if (cleanedPhone.length >= MIN_PASSWORD_LENGTH) return cleanedPhone;
  return `${fallbackId}@123`;
}

module.exports = { defaultPassword };
