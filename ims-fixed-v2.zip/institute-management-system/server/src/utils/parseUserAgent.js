// Minimal, dependency-free user-agent parsing — just enough to show a
// human-readable device/browser label in the sessions list (#87). Not
// meant to be exhaustive; falls back to "Unknown device" for anything it
// doesn't recognize rather than guessing wrong.
function parseUserAgent(ua = '') {
  let browser = 'Unknown browser';
  if (/Edg\//.test(ua)) browser = 'Edge';
  else if (/Chrome\//.test(ua)) browser = 'Chrome';
  else if (/Firefox\//.test(ua)) browser = 'Firefox';
  else if (/Safari\//.test(ua) && !/Chrome/.test(ua)) browser = 'Safari';

  let device = 'Desktop';
  if (/iPhone/.test(ua)) device = 'iPhone';
  else if (/iPad/.test(ua)) device = 'iPad';
  else if (/Android/.test(ua)) device = 'Android';
  else if (/Macintosh/.test(ua)) device = 'Mac';
  else if (/Windows/.test(ua)) device = 'Windows';
  else if (/Linux/.test(ua)) device = 'Linux';

  return { browser, device };
}

module.exports = { parseUserAgent };
