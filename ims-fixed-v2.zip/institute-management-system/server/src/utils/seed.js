// Seeds a minimal but fully working dataset: one School (tenant), one user
// per key role within it, a class/section/subject, and an academic
// session. Safe to re-run — it skips records that already exist rather
// than duplicating them.
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const { ROLES } = require('../config/roles');

const School = require('../models/School');
const User = require('../models/User');
const AcademicSession = require('../models/AcademicSession');
const Class = require('../models/Class');
const Section = require('../models/Section');
const Subject = require('../models/Subject');
const Teacher = require('../models/Teacher');
const Student = require('../models/Student');
const SchoolSettings = require('../models/SchoolSettings');
const Book = require('../models/Book');
const Route = require('../models/Route');

const upsertUser = async (data) => {
  let user = await User.findOne({ email: data.email });
  if (!user) {
    user = await User.create(data);
    console.log(`Created user: ${data.email} (${data.role})`);
  } else {
    console.log(`User already exists, skipping: ${data.email}`);
  }
  return user;
};

const run = async () => {
  await connectDB();

  console.log('\n--- Seeding Platform Super Admin ---');
  // The Super Admin is platform-level (no school) — see config/roles.js.
  // They manage schools via /api/platform, not any single school's data.
  const superAdminEmail = process.env.SEED_SUPERADMIN_EMAIL || 'superadmin@school.com';
  const superAdminPassword = process.env.SEED_SUPERADMIN_PASSWORD || 'SuperAdmin@123';
  await upsertUser({
    name: 'Super Admin',
    email: superAdminEmail,
    password: superAdminPassword,
    role: ROLES.SUPER_ADMIN,
  });

  console.log('\n--- Seeding School (Tenant) ---');
  let school = await School.findOne({ slug: 'greenwood' });
  if (!school) {
    school = await School.create({
      name: 'Greenwood High School',
      slug: 'greenwood',
      address: '123 Education Lane',
    });
    console.log('Created school: Greenwood High School (slug: greenwood)');
  }

  console.log('\n--- Seeding School Settings ---');
  await SchoolSettings.findOneAndUpdate(
    { school: school._id },
    { $setOnInsert: { school: school._id, schoolName: school.name } },
    { upsert: true }
  );

  console.log('\n--- Seeding Academic Session ---');
  let session = await AcademicSession.findOne({ name: '2025-2026', school: school._id });
  if (!session) {
    session = await AcademicSession.create({
      school: school._id,
      name: '2025-2026',
      startDate: new Date('2025-09-01'),
      endDate: new Date('2026-06-30'),
      isCurrent: true,
    });
    console.log('Created academic session 2025-2026');
  }

  console.log('\n--- Seeding Class & Section ---');
  let cls = await Class.findOne({ name: 'Class 6', academicSession: session._id, school: school._id });
  if (!cls) {
    cls = await Class.create({ school: school._id, name: 'Class 6', academicSession: session._id });
    console.log('Created Class 6');
  }
  let section = await Section.findOne({ name: 'A', class: cls._id, school: school._id });
  if (!section) {
    section = await Section.create({ school: school._id, name: 'A', class: cls._id, capacity: 40 });
    console.log('Created Section A');
  }

  console.log('\n--- Seeding Subject ---');
  let subject = await Subject.findOne({ code: 'MATH6', school: school._id });
  if (!subject) {
    subject = await Subject.create({
      school: school._id,
      name: 'Mathematics',
      code: 'MATH6',
      class: cls._id,
      fullMarks: 100,
      passMarks: 33,
    });
    console.log('Created Mathematics subject');
  }

  console.log('\n--- Seeding Users ---');
  await upsertUser({
    school: school._id,
    name: 'School Admin',
    email: 'admin@school.com',
    password: 'Admin@123',
    role: ROLES.ADMIN,
  });

  const teacherUser = await upsertUser({
    school: school._id,
    name: 'Jane Teacher',
    email: 'teacher@school.com',
    password: 'Teacher@123',
    role: ROLES.TEACHER,
  });
  let teacher = await Teacher.findOne({ user: teacherUser._id, school: school._id });
  if (!teacher) {
    teacher = await Teacher.create({
      school: school._id,
      user: teacherUser._id,
      employeeId: 'EMP-0001',
      firstName: 'Jane',
      lastName: 'Teacher',
      qualification: 'M.Sc. Mathematics',
      designation: 'Senior Teacher',
      subjects: [subject._id],
      assignedClasses: [cls._id],
      email: teacherUser.email,
    });
    teacherUser.profileRef = { kind: 'Teacher', id: teacher._id };
    await teacherUser.save();
    console.log('Created teacher profile for Jane Teacher');
  }

  const parentUser = await upsertUser({
    school: school._id,
    name: 'John Parent',
    email: 'parent@school.com',
    password: 'Parent@123',
    role: ROLES.PARENT,
  });

  const studentUser = await upsertUser({
    school: school._id,
    name: 'Alex Student',
    email: 'student@school.com',
    password: 'Student@123',
    role: ROLES.STUDENT,
  });
  let student = await Student.findOne({ user: studentUser._id, school: school._id });
  if (!student) {
    student = await Student.create({
      school: school._id,
      user: studentUser._id,
      admissionNumber: 'ADM-2025-0001',
      rollNumber: '1',
      firstName: 'Alex',
      lastName: 'Student',
      gender: 'male',
      class: cls._id,
      section: section._id,
      academicSession: session._id,
      parent: parentUser._id,
      guardianName: 'John Parent',
      guardianPhone: '+1-555-0100',
    });
    studentUser.profileRef = { kind: 'Student', id: student._id };
    await studentUser.save();
    console.log('Created student profile for Alex Student');
  }

  await upsertUser({
    school: school._id,
    name: 'Amy Accountant',
    email: 'accountant@school.com',
    password: 'Accountant@123',
    role: ROLES.ACCOUNTANT,
  });

  console.log('\n--- Seeding Sample Library Book ---');
  const existingBook = await Book.findOne({ isbn: '978-0-13-468599-1', school: school._id });
  if (!existingBook) {
    await Book.create({
      school: school._id,
      title: 'Introduction to Algorithms',
      author: 'Thomas H. Cormen',
      isbn: '978-0-13-468599-1',
      category: 'Computer Science',
      publisher: 'MIT Press',
      quantity: 3,
      availableQuantity: 3,
      shelfLocation: 'CS-1',
    });
    console.log('Created sample library book');
  }

  console.log('\n--- Seeding Sample Transport Route ---');
  let existingRoute = await Route.findOne({ name: 'Route A - Downtown', school: school._id });
  if (!existingRoute) {
    existingRoute = await Route.findOne({ name: 'Route A - Downtown' });
  }

  if (!existingRoute) {
    await Route.create({
      school: school._id,
      name: 'Route A - Downtown',
      stops: [
        { name: 'Main Street', pickupTime: '07:15', dropTime: '14:30', fare: 20 },
        { name: 'Park Avenue', pickupTime: '07:30', dropTime: '14:45', fare: 15 },
      ],
    });
    console.log('Created sample transport route');
  } else if (!existingRoute.school) {
    existingRoute.school = school._id;
    await existingRoute.save();
    console.log('Repaired existing sample transport route');
  } else {
    console.log('Sample transport route already exists, skipping');
  }

  console.log('\n=================================================');
  console.log('SEED COMPLETE — Default login credentials:');
  console.log('=================================================');
  console.log(`Super Admin (platform) : ${superAdminEmail} / ${superAdminPassword}`);
  console.log(`  → manages schools at /platform, not day-to-day school data`);
  console.log(`School             : Greenwood High School (slug: greenwood)`);
  console.log('Admin (school)     : admin@school.com / Admin@123');
  console.log('Teacher            : teacher@school.com / Teacher@123');
  console.log('Student            : student@school.com / Student@123');
  console.log('Parent             : parent@school.com / Parent@123');
  console.log('Accountant         : accountant@school.com / Accountant@123');
  console.log('=================================================');
  console.log('IMPORTANT: Change all these passwords after first login.');
  console.log('=================================================\n');

  await mongoose.connection.close();
  process.exit(0);
};

run().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
