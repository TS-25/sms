import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SchoolSettingsProvider } from './context/SchoolSettingsContext';
import ProtectedRoute from './components/ProtectedRoute';
import DashboardLayout from './components/layout/DashboardLayout';
import FullPageLoader from './components/ui/FullPageLoader';

import LoginPage from './pages/auth/LoginPage';
import ForgotPasswordPage from './pages/auth/ForgotPasswordPage';
import ResetPasswordPage from './pages/auth/ResetPasswordPage';
import { UnauthorizedPage, NotFoundPage } from './pages/shared/StatusPages';

import AdminDashboard from './pages/admin/AdminDashboard';
import StudentsPage from './pages/admin/StudentsPage';
import TeachersPage from './pages/admin/TeachersPage';
import StaffPage from './pages/admin/StaffPage';
import AcademicsPage from './pages/admin/AcademicsPage';
import TimetablePage from './pages/admin/TimetablePage';
import AttendancePage from './pages/admin/AttendancePage';
import ExamsPage from './pages/admin/ExamsPage';
import FeesPage from './pages/admin/FeesPage';
import ExpensesPage from './pages/admin/ExpensesPage';
import LibraryPage from './pages/admin/LibraryPage';
import TransportPage from './pages/admin/TransportPage';
import HostelPage from './pages/admin/HostelPage';
import LeavePage from './pages/admin/LeavePage';
import EventsPage from './pages/admin/EventsPage';
import DocumentsPage from './pages/admin/DocumentsPage';
import CertificatesPage from './pages/admin/CertificatesPage';
import PromotionPage from './pages/admin/PromotionPage';
import AlumniPage from './pages/admin/AlumniPage';
import PayrollPage from './pages/admin/PayrollPage';
import RolesPage from './pages/admin/RolesPage';
import SecurityDashboardPage from './pages/admin/SecurityDashboardPage';
import EmailTemplatesPage from './pages/admin/EmailTemplatesPage';
import ContentPage from './pages/admin/ContentPage';
import ActivitiesPage from './pages/admin/ActivitiesPage';
import StudentRecordsPage from './pages/admin/StudentRecordsPage';
import MeetingsPage from './pages/admin/MeetingsPage';
import NoticesPage from './pages/admin/NoticesPage';
import SettingsPage from './pages/admin/SettingsPage';
import UsersPage from './pages/admin/UsersPage';
import AuditLogsPage from './pages/admin/AuditLogsPage';

import TeacherDashboard from './pages/teacher/TeacherDashboard';
import TeacherAssignmentsPage from './pages/teacher/TeacherAssignmentsPage';

import StudentDashboard from './pages/student/StudentDashboard';
import StudentAttendancePage from './pages/student/StudentAttendancePage';
import StudentResultsPage from './pages/student/StudentResultsPage';
import StudentAssignmentsPage from './pages/student/StudentAssignmentsPage';
import StudentFeesPage from './pages/student/StudentFeesPage';

import ParentDashboard from './pages/parent/ParentDashboard';
import { ParentAttendancePage, ParentResultsPage, ParentFeesPage } from './pages/parent/ParentPages';

import StaffDashboard from './pages/shared/StaffDashboard';
import SchoolsPage from './pages/platform/SchoolsPage';
import BackupsPage from './pages/platform/BackupsPage';
import MySecurityPage from './pages/shared/MySecurityPage';
import { roleHomePath } from './utils/roleHomePath';

const ADMIN_LIKE = ['admin', 'principal', 'accountant', 'receptionist', 'librarian'];

function RootRedirect() {
  const { user, loading } = useAuth();
  if (loading) return <FullPageLoader />;
  if (!user) return <Navigate to="/login" replace />;
  return <Navigate to={roleHomePath(user.role)} replace />;
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <SchoolSettingsProvider>
        <Toaster position="top-right" toastOptions={{ duration: 4000 }} />
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          <Route path="/reset-password/:token" element={<ResetPasswordPage />} />
          <Route path="/unauthorized" element={<UnauthorizedPage />} />

          <Route path="/" element={<RootRedirect />} />

          {/* Super Admin — platform-level, manages schools/tenants */}
          <Route
            path="/platform"
            element={
              <ProtectedRoute roles={['super_admin']}>
                <DashboardLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<SchoolsPage />} />
            <Route path="my-security" element={<MySecurityPage />} />
            <Route path="backups" element={<BackupsPage />} />
          </Route>

          {/* Admin / Principal / Accountant / Receptionist */}
          <Route
            path="/admin"
            element={
              <ProtectedRoute roles={ADMIN_LIKE}>
                <DashboardLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<AdminDashboard />} />
            <Route path="students" element={<StudentsPage />} />
            <Route path="teachers" element={<TeachersPage />} />
            <Route path="staff" element={<StaffPage />} />
            <Route path="academics" element={<AcademicsPage />} />
            <Route path="timetable" element={<TimetablePage />} />
            <Route path="attendance" element={<AttendancePage />} />
            <Route path="exams" element={<ExamsPage />} />
            <Route path="fees" element={<FeesPage />} />
            <Route path="expenses" element={<ExpensesPage />} />
            <Route path="library" element={<LibraryPage />} />
            <Route path="transport" element={<TransportPage />} />
            <Route path="hostel" element={<HostelPage />} />
            <Route path="leaves" element={<LeavePage />} />
            <Route path="events" element={<EventsPage />} />
            <Route path="documents" element={<DocumentsPage />} />
            <Route path="certificates" element={<CertificatesPage />} />
            <Route path="promotions" element={<PromotionPage />} />
            <Route path="alumni" element={<AlumniPage />} />
            <Route path="payroll" element={<PayrollPage />} />
            <Route path="roles" element={<RolesPage />} />
            <Route path="security" element={<SecurityDashboardPage />} />
            <Route path="email-templates" element={<EmailTemplatesPage />} />
            <Route path="content" element={<ContentPage />} />
            <Route path="activities" element={<ActivitiesPage />} />
            <Route path="student-records" element={<StudentRecordsPage />} />
            <Route path="meetings" element={<MeetingsPage />} />
            <Route path="notices" element={<NoticesPage />} />
            <Route path="my-security" element={<MySecurityPage />} />
            <Route path="settings" element={<SettingsPage />} />
            <Route path="users" element={<UsersPage />} />
            <Route path="audit-logs" element={<AuditLogsPage />} />
          </Route>

          {/* Teacher */}
          <Route
            path="/teacher"
            element={
              <ProtectedRoute roles={['teacher']}>
                <DashboardLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<TeacherDashboard />} />
            <Route path="timetable" element={<TimetablePage />} />
            <Route path="attendance" element={<AttendancePage />} />
            <Route path="exams" element={<ExamsPage />} />
            <Route path="assignments" element={<TeacherAssignmentsPage />} />
            <Route path="leaves" element={<LeavePage />} />
            <Route path="events" element={<EventsPage />} />
            <Route path="meetings" element={<MeetingsPage />} />
            <Route path="notices" element={<NoticesPage />} />
            <Route path="my-security" element={<MySecurityPage />} />
          </Route>

          {/* Student */}
          <Route
            path="/student"
            element={
              <ProtectedRoute roles={['student']}>
                <DashboardLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<StudentDashboard />} />
            <Route path="attendance" element={<StudentAttendancePage />} />
            <Route path="results" element={<StudentResultsPage />} />
            <Route path="assignments" element={<StudentAssignmentsPage />} />
            <Route path="fees" element={<StudentFeesPage />} />
            <Route path="events" element={<EventsPage />} />
            <Route path="meetings" element={<MeetingsPage />} />
            <Route path="notices" element={<NoticesPage />} />
            <Route path="my-security" element={<MySecurityPage />} />
          </Route>

          {/* Parent */}
          <Route
            path="/parent"
            element={
              <ProtectedRoute roles={['parent']}>
                <DashboardLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<ParentDashboard />} />
            <Route path="attendance" element={<ParentAttendancePage />} />
            <Route path="results" element={<ParentResultsPage />} />
            <Route path="fees" element={<ParentFeesPage />} />
            <Route path="meetings" element={<MeetingsPage />} />
            <Route path="notices" element={<NoticesPage />} />
            <Route path="my-security" element={<MySecurityPage />} />
          </Route>

          {/* Other staff roles (librarian, general staff) */}
          <Route
            path="/staff"
            element={
              <ProtectedRoute roles={['staff', 'librarian', 'receptionist']}>
                <DashboardLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<StaffDashboard />} />
            <Route path="my-security" element={<MySecurityPage />} />
            <Route path="leaves" element={<LeavePage />} />
          </Route>

          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </SchoolSettingsProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
