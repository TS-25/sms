import api from './api';

export const promotionService = {
  promote: (data) => api.post('/promotions/promote', data),
  repeat: (data) => api.post('/promotions/repeat', data),
  transfer: (studentId, data) => api.post(`/promotions/transfer/${studentId}`, data),
  graduate: (data) => api.post('/promotions/graduate', data),
  history: (studentId) => api.get(`/promotions/history/${studentId}`),
};

export const alumniService = {
  list: (params) => api.get('/alumni', { params }),
  update: (id, data) => api.put(`/alumni/${id}`, data),
  stats: () => api.get('/alumni/stats'),
};
