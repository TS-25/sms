import api from './api';

export const studentService = {
  list: (params) => api.get('/students', { params }),
  get: (id) => api.get(`/students/${id}`),
  create: (data) => api.post('/students', data),
  update: (id, data) => api.put(`/students/${id}`, data),
  remove: (id) => api.delete(`/students/${id}`),
  exportCsv: () => api.get('/students/export/csv', { responseType: 'blob' }),
  importCsv: (file) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post('/students/import/csv', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
};

export const teacherService = {
  list: (params) => api.get('/teachers', { params }),
  get: (id) => api.get(`/teachers/${id}`),
  create: (data) => api.post('/teachers', data),
  update: (id, data) => api.put(`/teachers/${id}`, data),
  remove: (id) => api.delete(`/teachers/${id}`),
};

export const academicService = {
  sessions: {
    list: () => api.get('/academics/sessions'),
    create: (data) => api.post('/academics/sessions', data),
    update: (id, data) => api.put(`/academics/sessions/${id}`, data),
    remove: (id) => api.delete(`/academics/sessions/${id}`),
  },
  classes: {
    list: (params) => api.get('/academics/classes', { params }),
    create: (data) => api.post('/academics/classes', data),
    update: (id, data) => api.put(`/academics/classes/${id}`, data),
    remove: (id) => api.delete(`/academics/classes/${id}`),
  },
  sections: {
    list: (params) => api.get('/academics/sections', { params }),
    create: (data) => api.post('/academics/sections', data),
    update: (id, data) => api.put(`/academics/sections/${id}`, data),
    remove: (id) => api.delete(`/academics/sections/${id}`),
  },
  subjects: {
    list: (params) => api.get('/academics/subjects', { params }),
    create: (data) => api.post('/academics/subjects', data),
    update: (id, data) => api.put(`/academics/subjects/${id}`, data),
    remove: (id) => api.delete(`/academics/subjects/${id}`),
  },
};

export const attendanceService = {
  mark: (data) => api.post('/attendance/mark', data),
  getByDate: (params) => api.get('/attendance', { params }),
  getForStudent: (studentId, params) => api.get(`/attendance/student/${studentId}`, { params }),
  exportCsv: (params) => api.get('/attendance/export/csv', { params, responseType: 'blob' }),
};

export const examService = {
  list: (params) => api.get('/exams', { params }),
  create: (data) => api.post('/exams', data),
  update: (id, data) => api.put(`/exams/${id}`, data),
  remove: (id) => api.delete(`/exams/${id}`),
  upsertResult: (examId, data) => api.post(`/exams/${examId}/results`, data),
  getResults: (examId) => api.get(`/exams/${examId}/results`),
  publish: (examId) => api.patch(`/exams/${examId}/publish`),
  lock: (examId) => api.patch(`/exams/${examId}/lock`),
  reportCardUrl: (examId, studentId) => `/exams/${examId}/results/${studentId}/report-card`,
};

export const feeService = {
  list: (params) => api.get('/fees', { params }),
  create: (data) => api.post('/fees', data),
  update: (id, data) => api.put(`/fees/${id}`, data),
  remove: (id) => api.delete(`/fees/${id}`),
  recordPayment: (data) => api.post('/payments', data),
  listPayments: (params) => api.get('/payments', { params }),
  receiptUrl: (paymentId) => `/payments/${paymentId}/receipt`,
  sendReminder: (feeId) => api.post(`/fees/${feeId}/remind`),
};

export const expenseService = {
  list: (params) => api.get('/expenses', { params }),
  create: (data) => api.post('/expenses', data),
  update: (id, data) => api.put(`/expenses/${id}`, data),
  remove: (id) => api.delete(`/expenses/${id}`),
};

export const noticeService = {
  list: () => api.get('/notices'),
  create: (data) => api.post('/notices', data),
  update: (id, data) => api.put(`/notices/${id}`, data),
  remove: (id) => api.delete(`/notices/${id}`),
};

export const notificationService = {
  list: () => api.get('/notifications'),
  markRead: (id) => api.patch(`/notifications/${id}/read`),
  markAllRead: () => api.patch('/notifications/read-all'),
};

export const assignmentService = {
  list: (params) => api.get('/assignments', { params }),
  create: (data) => api.post('/assignments', data),
  update: (id, data) => api.put(`/assignments/${id}`, data),
  remove: (id) => api.delete(`/assignments/${id}`),
  submit: (id, data) => api.post(`/assignments/${id}/submit`, data),
};

export const dashboardService = {
  admin: () => api.get('/dashboard/admin'),
  teacher: () => api.get('/dashboard/teacher'),
  student: () => api.get('/dashboard/student'),
};

export const settingsService = {
  get: () => api.get('/settings'),
  getPublic: () => api.get('/settings/public'),
  update: (data) => api.put('/settings', data),
};

export const userService = {
  list: (params) => api.get('/users', { params }),
  create: (data) => api.post('/users', data),
  update: (id, data) => api.put(`/users/${id}`, data),
  remove: (id) => api.delete(`/users/${id}`),
};

export const auditLogService = {
  list: (params) => api.get('/audit-logs', { params }),
};

export const uploadService = {
  upload: (file) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post('/uploads', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
};

export const timetableService = {
  get: (params) => api.get('/timetables', { params }),
  getForTeacher: (teacherId) => api.get(`/timetables/teacher/${teacherId}`),
  addPeriod: (classId, section, data) => api.post(`/timetables/${classId}/${section}/periods`, data),
  updatePeriod: (classId, section, periodId, data) => api.put(`/timetables/${classId}/${section}/periods/${periodId}`, data),
  removePeriod: (classId, section, periodId) => api.delete(`/timetables/${classId}/${section}/periods/${periodId}`),
};

export const libraryService = {
  books: {
    list: (params) => api.get('/library/books', { params }),
    create: (data) => api.post('/library/books', data),
    update: (id, data) => api.put(`/library/books/${id}`, data),
    remove: (id) => api.delete(`/library/books/${id}`),
  },
  issue: (data) => api.post('/library/issue', data),
  return: (transactionId) => api.patch(`/library/return/${transactionId}`),
  transactions: (params) => api.get('/library/transactions', { params }),
};

export const transportService = {
  vehicles: {
    list: () => api.get('/transport/vehicles'),
    create: (data) => api.post('/transport/vehicles', data),
    update: (id, data) => api.put(`/transport/vehicles/${id}`, data),
    remove: (id) => api.delete(`/transport/vehicles/${id}`),
  },
  routes: {
    list: () => api.get('/transport/routes'),
    create: (data) => api.post('/transport/routes', data),
    update: (id, data) => api.put(`/transport/routes/${id}`, data),
    remove: (id) => api.delete(`/transport/routes/${id}`),
  },
  assignments: {
    list: (params) => api.get('/transport/assignments', { params }),
    assign: (data) => api.post('/transport/assign', data),
    remove: (id) => api.delete(`/transport/assignments/${id}`),
  },
};

export const hostelService = {
  list: () => api.get('/hostels'),
  create: (data) => api.post('/hostels', data),
  update: (id, data) => api.put(`/hostels/${id}`, data),
  remove: (id) => api.delete(`/hostels/${id}`),
  addRoom: (id, data) => api.post(`/hostels/${id}/rooms`, data),
  allocateBed: (id, roomId, bedId, data) => api.patch(`/hostels/${id}/rooms/${roomId}/beds/${bedId}/allocate`, data),
  checkoutBed: (id, roomId, bedId) => api.patch(`/hostels/${id}/rooms/${roomId}/beds/${bedId}/checkout`),
};

export const staffService = {
  list: (params) => api.get('/staff', { params }),
  create: (data) => api.post('/staff', data),
  update: (id, data) => api.put(`/staff/${id}`, data),
  remove: (id) => api.delete(`/staff/${id}`),
};

export const leaveService = {
  list: (params) => api.get('/leaves', { params }),
  apply: (data) => api.post('/leaves', data),
  review: (id, data) => api.patch(`/leaves/${id}/review`, data),
  remove: (id) => api.delete(`/leaves/${id}`),
};

export const eventService = {
  list: (params) => api.get('/events', { params }),
  create: (data) => api.post('/events', data),
  update: (id, data) => api.put(`/events/${id}`, data),
  remove: (id) => api.delete(`/events/${id}`),
};

export const documentService = {
  list: (params) => api.get('/documents', { params }),
  upload: (file, meta = {}) => {
    const formData = new FormData();
    formData.append('file', file);
    Object.entries(meta).forEach(([k, v]) => v && formData.append(k, v));
    return api.post('/documents', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
  },
  remove: (id) => api.delete(`/documents/${id}`),
};

export const idCardService = {
  studentCardUrl: (studentId) => `/id-cards/student/${studentId}`,
  teacherCardUrl: (teacherId) => `/id-cards/teacher/${teacherId}`,
};

export const certificateService = {
  list: (params) => api.get('/certificates', { params }),
  create: (data) => api.post('/certificates', data),
  update: (id, data) => api.put(`/certificates/${id}`, data),
  remove: (id) => api.delete(`/certificates/${id}`),
  pdfUrl: (id) => `/certificates/${id}/pdf`,
};

export const platformService = {
  stats: () => api.get('/platform/stats'),
  schools: {
    list: () => api.get('/platform/schools'),
    get: (id) => api.get(`/platform/schools/${id}`),
    create: (data) => api.post('/platform/schools', data),
    update: (id, data) => api.put(`/platform/schools/${id}`, data),
    setStatus: (id, isActive) => api.patch(`/platform/schools/${id}/status`, { isActive }),
    updateModules: (id, enabledModules) => api.patch(`/platform/schools/${id}/modules`, { enabledModules }),
  },
};
