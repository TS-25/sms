import api from './api';

export const cmsService = {
  list: () => api.get('/cms/pages'),
  create: (data) => api.post('/cms/pages', data),
  update: (id, data) => api.put(`/cms/pages/${id}`, data),
  remove: (id) => api.delete(`/cms/pages/${id}`),
};

export const galleryService = {
  list: () => api.get('/gallery'),
  create: (data) => api.post('/gallery', data),
  update: (id, data) => api.put(`/gallery/${id}`, data),
  remove: (id) => api.delete(`/gallery/${id}`),
  addImage: (id, data) => api.post(`/gallery/${id}/images`, data),
  removeImage: (id, imageId) => api.delete(`/gallery/${id}/images/${imageId}`),
};

export const clubService = {
  list: () => api.get('/clubs'),
  create: (data) => api.post('/clubs', data),
  update: (id, data) => api.put(`/clubs/${id}`, data),
  remove: (id) => api.delete(`/clubs/${id}`),
  addActivity: (id, data) => api.post(`/clubs/${id}/activities`, data),
};

export const sportsService = {
  list: () => api.get('/sports'),
  create: (data) => api.post('/sports', data),
  update: (id, data) => api.put(`/sports/${id}`, data),
  remove: (id) => api.delete(`/sports/${id}`),
  addMatch: (id, data) => api.post(`/sports/${id}/matches`, data),
};

export const studentRecordsService = {
  achievements: (params) => api.get('/student-records/achievements', { params }),
  createAchievement: (data) => api.post('/student-records/achievements', data),
  removeAchievement: (id) => api.delete(`/student-records/achievements/${id}`),
  merit: (params) => api.get('/student-records/merit', { params }),
  giveMerit: (data) => api.post('/student-records/merit', data),
  meritLeaderboard: () => api.get('/student-records/merit/leaderboard'),
  discipline: (params) => api.get('/student-records/discipline', { params }),
  createDiscipline: (data) => api.post('/student-records/discipline', data),
  health: (studentId) => api.get(`/student-records/health/${studentId}`),
  saveHealth: (studentId, data) => api.put(`/student-records/health/${studentId}`, data),
};

export const meetingService = {
  list: (params) => api.get('/meetings', { params }),
  create: (data) => api.post('/meetings', data),
  book: (id, data) => api.post(`/meetings/${id}/book`, data),
  cancel: (id) => api.patch(`/meetings/${id}/cancel`),
  remove: (id) => api.delete(`/meetings/${id}`),
};
