import { createContext, useContext, useCallback, useEffect, useState } from 'react';
import { useAuth } from './AuthContext';
import { settingsService } from '../services/resourceServices';

const SchoolSettingsContext = createContext(null);

const DEFAULTS = { schoolName: 'School', logoUrl: '', currency: 'USD' };

// Fetches school settings once a user is authenticated, and exposes a
// refresh() so the Settings page can push an immediate update to every
// component that reads the school name (sidebar, etc.) without a reload.
export function SchoolSettingsProvider({ children }) {
  const { user } = useAuth();
  const [settings, setSettings] = useState(DEFAULTS);

  const refresh = useCallback(async () => {
    // super_admin is platform-level and has no school — /settings would
    // 403 for them (see requireSchool middleware on the backend).
    if (!user || user.role === 'super_admin') return;
    try {
      const { data } = await settingsService.get();
      setSettings({ ...DEFAULTS, ...data.data });
    } catch {
      // Non-critical — keep showing whatever we had (or the defaults).
    }
  }, [user]);

  useEffect(() => {
    if (user) refresh();
    else setSettings(DEFAULTS);
  }, [user, refresh]);

  return (
    <SchoolSettingsContext.Provider value={{ settings, refresh }}>
      {children}
    </SchoolSettingsContext.Provider>
  );
}

export const useSchoolSettings = () => {
  const ctx = useContext(SchoolSettingsContext);
  if (!ctx) throw new Error('useSchoolSettings must be used within SchoolSettingsProvider');
  return ctx;
};
