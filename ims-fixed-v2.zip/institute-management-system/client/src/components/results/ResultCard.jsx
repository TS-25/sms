import { IoDownloadOutline, IoRibbonOutline } from 'react-icons/io5';

// A responsive, "premium-feel" on-screen mirror of the PDF report card —
// used on both the student and parent result pages. Mobile-first: the
// subject table scrolls horizontally on narrow screens instead of
// squeezing columns, and the summary panel stacks into a single column
// below `sm`.
export default function ResultCard({ exam, result, student, gradingScale = [], onDownload }) {
  if (!result) {
    return (
      <div className="card p-5">
        <p className="font-display text-base text-ink-800">{exam.name}</p>
        <p className="mt-1 text-sm text-ink-400">Result not entered yet.</p>
      </div>
    );
  }

  const sortedScale = [...gradingScale].sort((a, b) => b.minPercentage - a.minPercentage);

  return (
    <div className="card overflow-hidden">
      {/* Header */}
      <div className="flex flex-col gap-1 border-b border-ink-100 bg-ink-800 p-5 text-cream sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="font-display text-lg">{exam.name}</p>
          {student && (
            <p className="text-xs text-ink-200">
              {student.fullName || `${student.firstName || ''} ${student.lastName || ''}`.trim()}
              {student.class?.name && ` · ${student.class.name}${student.section?.name ? ` / ${student.section.name}` : ''}`}
            </p>
          )}
        </div>
        {onDownload && (
          <button className="btn-brass self-start sm:self-auto" onClick={onDownload}>
            <IoDownloadOutline /> Download PDF
          </button>
        )}
      </div>

      {/* Subject breakdown — horizontally scrollable on small screens */}
      <div className="overflow-x-auto">
        <table className="table-base min-w-[420px]">
          <thead>
            <tr>
              <th>Subject</th>
              <th>Full Marks</th>
              <th>Obtained</th>
              <th>%</th>
            </tr>
          </thead>
          <tbody>
            {result.marks.map((m, idx) => {
              const pct = m.fullMarks > 0 ? Math.round((m.marksObtained / m.fullMarks) * 1000) / 10 : 0;
              return (
                <tr key={idx}>
                  <td>{m.subject?.name || String(m.subject)}</td>
                  <td>{m.fullMarks}</td>
                  <td>{m.marksObtained}</td>
                  <td>{pct}%</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Summary panel */}
      <div className="grid grid-cols-2 gap-4 bg-brass-50 p-5 sm:grid-cols-4">
        <div>
          <p className="text-xs text-ink-500">Total</p>
          <p className="font-display text-lg text-ink-800">{result.totalObtained}/{result.totalFullMarks}</p>
        </div>
        <div>
          <p className="text-xs text-ink-500">Percentage</p>
          <p className="font-display text-lg text-ink-800">{result.percentage}%</p>
        </div>
        <div>
          <p className="text-xs text-ink-500">Grade / GPA</p>
          <p className="font-display text-lg text-brass-700">{result.grade} · {result.gpa}</p>
        </div>
        <div>
          <p className="text-xs text-ink-500">Result</p>
          <p className={`font-display text-lg ${result.isPass ? 'text-green-700' : 'text-red-600'}`}>
            {result.isPass ? 'PASS' : 'FAIL'}
          </p>
        </div>
      </div>

      {/* Grading scale legend */}
      {sortedScale.length > 0 && (
        <div className="border-t border-ink-100 p-4">
          <p className="mb-2 flex items-center gap-1 text-xs font-medium text-ink-400">
            <IoRibbonOutline /> GRADING SCALE
          </p>
          <div className="flex flex-wrap gap-2">
            {sortedScale.map((t) => (
              <span key={t.grade} className="rounded-full bg-ink-50 px-2.5 py-1 text-xs text-ink-600">
                {t.grade} ({t.minPercentage}%+, GPA {t.gpa})
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
