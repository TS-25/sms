import { NavLink } from 'react-router-dom';
import { IoSchoolOutline } from 'react-icons/io5';
import { NAV_BY_ROLE } from './navConfig';
import { useSchoolSettings } from '../../context/SchoolSettingsContext';

export default function Sidebar({ role, open, onClose }) {
  const items = NAV_BY_ROLE[role] || [];
  const { settings } = useSchoolSettings();
  const isPlatform = role === 'super_admin';

  return (
    <>
      {open && (
        <div className="fixed inset-0 z-30 bg-ink-900/40 lg:hidden" onClick={onClose} />
      )}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 transform bg-ink-800 text-cream transition-transform lg:static lg:translate-x-0 ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center gap-2 border-b border-ink-700 px-6 py-5">
          {!isPlatform && settings.logoUrl ? (
            <img src={settings.logoUrl} alt="" className="h-6 w-6 rounded object-cover" />
          ) : (
            <IoSchoolOutline className="text-brass-400" size={24} />
          )}
          <span className="font-display text-lg tracking-tight truncate">
            {isPlatform ? 'Platform Admin' : settings.schoolName}
          </span>
        </div>
        <nav className="flex flex-col gap-1 p-3">
          {items.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              onClick={onClose}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors ${
                  isActive
                    ? 'bg-brass-400 text-ink-900 font-medium'
                    : 'text-ink-100 hover:bg-ink-700'
                }`
              }
            >
              <Icon size={18} />
              {label}
            </NavLink>
          ))}
        </nav>
      </aside>
    </>
  );
}
