import { useEffect, useState, useRef } from 'react';
import { IoMenuOutline, IoNotificationsOutline, IoLogOutOutline, IoChevronDown, IoShieldCheckmarkOutline } from 'react-icons/io5';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { notificationService } from '../../services/resourceServices';
import { ROLE_LABELS } from './navConfig';
import toast from 'react-hot-toast';

export default function Topbar({ onMenuClick }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [notifOpen, setNotifOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const notifRef = useRef(null);
  const menuRef = useRef(null);

  useEffect(() => {
    // super_admin is platform-level and has no school — notifications are
    // a per-school feature (see requireSchool middleware on the backend).
    if (user?.role === 'super_admin') return;
    const loadNotifications = async () => {
      try {
        const { data } = await notificationService.list();
        setNotifications(data.data);
        setUnreadCount(data.unreadCount);
      } catch {
        // Silently ignore — notifications are non-critical to page function.
      }
    };
    loadNotifications();
    const interval = setInterval(loadNotifications, 60000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (notifRef.current && !notifRef.current.contains(e.target)) setNotifOpen(false);
      if (menuRef.current && !menuRef.current.contains(e.target)) setUserMenuOpen(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleMarkAllRead = async () => {
    await notificationService.markAllRead();
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    setUnreadCount(0);
  };

  const handleLogout = async () => {
    await logout();
    toast.success('Logged out successfully.');
    navigate('/login');
  };

  return (
    <header className="flex h-16 items-center justify-between border-b border-ink-100 bg-white px-4 lg:px-6">
      <button className="text-ink-500 lg:hidden" onClick={onMenuClick} aria-label="Open menu">
        <IoMenuOutline size={24} />
      </button>
      <div className="hidden lg:block" />

      <div className="flex items-center gap-4">
        <div className="relative" ref={notifRef}>
          <button
            className="relative rounded-full p-2 text-ink-500 hover:bg-ink-50"
            onClick={() => setNotifOpen((o) => !o)}
            aria-label="Notifications"
          >
            <IoNotificationsOutline size={20} />
            {unreadCount > 0 && (
              <span className="absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-brass-500 text-[10px] text-white">
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>
          {notifOpen && (
            <div className="absolute right-0 mt-2 w-[85vw] max-w-80 rounded-lg border border-ink-100 bg-white shadow-xl">
              <div className="flex items-center justify-between border-b border-ink-100 px-4 py-3">
                <span className="font-medium text-ink-700">Notifications</span>
                <button className="text-xs text-brass-600 hover:underline" onClick={handleMarkAllRead}>
                  Mark all read
                </button>
              </div>
              <div className="max-h-80 overflow-y-auto">
                {notifications.length === 0 ? (
                  <p className="p-4 text-center text-sm text-ink-400">You're all caught up.</p>
                ) : (
                  notifications.map((n) => (
                    <div key={n._id} className={`border-b border-ink-50 px-4 py-3 text-sm ${!n.isRead ? 'bg-brass-50/60' : ''}`}>
                      <p className="font-medium text-ink-700">{n.title}</p>
                      <p className="text-ink-500">{n.message}</p>
                      <p className="mt-1 text-xs text-ink-300">{new Date(n.createdAt).toLocaleString()}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        <div className="relative" ref={menuRef}>
          <button
            className="flex items-center gap-2 rounded-md px-2 py-1.5 hover:bg-ink-50"
            onClick={() => setUserMenuOpen((o) => !o)}
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-ink-800 text-sm font-medium text-cream">
              {user?.name?.charAt(0).toUpperCase()}
            </div>
            <div className="hidden text-left sm:block">
              <p className="text-sm font-medium text-ink-700 leading-none">{user?.name}</p>
              <p className="text-xs text-ink-400">{ROLE_LABELS[user?.role]}</p>
            </div>
            <IoChevronDown className="text-ink-400" size={14} />
          </button>
          {userMenuOpen && (
            <div className="absolute right-0 mt-2 w-48 rounded-lg border border-ink-100 bg-white py-1 shadow-xl">
              <button
                className="flex w-full items-center gap-2 px-4 py-2 text-sm text-ink-600 hover:bg-ink-50"
                onClick={() => {
                  setUserMenuOpen(false);
                  // Reuse whichever top-level section the user is already
                  // in (admin/teacher/student/parent/staff/platform) so the
                  // link works correctly no matter which role is viewing it.
                  const section = location.pathname.split('/')[1] || 'admin';
                  navigate(`/${section}/my-security`);
                }}
              >
                <IoShieldCheckmarkOutline /> Security
              </button>
              <button
                className="flex w-full items-center gap-2 px-4 py-2 text-sm text-ink-600 hover:bg-ink-50"
                onClick={handleLogout}
              >
                <IoLogOutOutline /> Log out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
