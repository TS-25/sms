import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoTrashOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import EmptyState from '../../components/ui/EmptyState';
import { TextField, SelectField } from '../../components/forms/FormFields';
import { clubService, sportsService } from '../../services/engagementServices';
import { teacherService } from '../../services/resourceServices';

export default function ActivitiesPage() {
  const [tab, setTab] = useState('Clubs');
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Clubs & Sports</h1>
        <p className="text-sm text-ink-400">Extracurricular clubs and sports teams.</p>
      </div>
      <div className="flex gap-1 border-b border-ink-100">
        {['Clubs', 'Sports Teams'].map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 text-sm font-medium ${tab === t ? 'border-b-2 border-brass-400 text-ink-800' : 'text-ink-400'}`}>{t}</button>
        ))}
      </div>
      {tab === 'Clubs' ? <ClubsTab /> : <SportsTab />}
    </div>
  );
}

function ClubsTab() {
  const [clubs, setClubs] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ name: '', description: '', teacher: '' });

  const load = useCallback(async () => {
    const [c, t] = await Promise.all([clubService.list(), teacherService.list({ limit: 100 })]);
    setClubs(c.data.data);
    setTeachers(t.data.data);
  }, []);
  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await clubService.create(form);
      toast.success('Club created.');
      setModalOpen(false);
      setForm({ name: '', description: '', teacher: '' });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create club.');
    }
  };

  const handleDelete = async () => {
    await clubService.remove(deleteTarget._id);
    toast.success('Club deleted.');
    setDeleteTarget(null);
    load();
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end"><button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> New Club</button></div>
      {clubs.length === 0 ? (
        <EmptyState title="No clubs yet" />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {clubs.map((c) => (
            <div key={c._id} className="card p-5">
              <div className="mb-1 flex items-start justify-between">
                <p className="font-display text-base text-ink-800">{c.name}</p>
                <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(c)}><IoTrashOutline /></button>
              </div>
              <p className="text-sm text-ink-500">{c.description}</p>
              <p className="mt-2 text-xs text-ink-400">Teacher: {c.teacher ? `${c.teacher.firstName} ${c.teacher.lastName || ''}` : '—'} · {c.members.length} member(s)</p>
            </div>
          ))}
        </div>
      )}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="New Club">
        <form onSubmit={handleCreate} className="space-y-4">
          <TextField label="Club Name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <TextField label="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <SelectField label="Supervising Teacher" value={form.teacher} onChange={(e) => setForm({ ...form, teacher: e.target.value })}
            options={teachers.map((t) => ({ value: t._id, label: `${t.firstName} ${t.lastName || ''}` }))} />
          <div className="flex justify-end gap-3"><button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button><button className="btn-brass">Create</button></div>
        </form>
      </Modal>
      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete club?" message="This cannot be undone." />
    </div>
  );
}

function SportsTab() {
  const [teams, setTeams] = useState([]);
  const [coaches, setCoaches] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ name: '', sport: '', coach: '' });

  const load = useCallback(async () => {
    const [t, c] = await Promise.all([sportsService.list(), teacherService.list({ limit: 100 })]);
    setTeams(t.data.data);
    setCoaches(c.data.data);
  }, []);
  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await sportsService.create(form);
      toast.success('Team created.');
      setModalOpen(false);
      setForm({ name: '', sport: '', coach: '' });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create team.');
    }
  };

  const handleDelete = async () => {
    await sportsService.remove(deleteTarget._id);
    toast.success('Team deleted.');
    setDeleteTarget(null);
    load();
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end"><button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> New Team</button></div>
      {teams.length === 0 ? (
        <EmptyState title="No sports teams yet" />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {teams.map((t) => (
            <div key={t._id} className="card p-5">
              <div className="mb-1 flex items-start justify-between">
                <p className="font-display text-base text-ink-800">{t.name}</p>
                <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(t)}><IoTrashOutline /></button>
              </div>
              <p className="text-sm text-ink-500">{t.sport}</p>
              <p className="mt-2 text-xs text-ink-400">Coach: {t.coach ? `${t.coach.firstName} ${t.coach.lastName || ''}` : '—'} · {t.players.length} player(s) · {t.matches.length} match(es)</p>
            </div>
          ))}
        </div>
      )}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="New Sports Team">
        <form onSubmit={handleCreate} className="space-y-4">
          <TextField label="Team Name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <TextField label="Sport" required value={form.sport} onChange={(e) => setForm({ ...form, sport: e.target.value })} />
          <SelectField label="Coach" value={form.coach} onChange={(e) => setForm({ ...form, coach: e.target.value })}
            options={coaches.map((t) => ({ value: t._id, label: `${t.firstName} ${t.lastName || ''}` }))} />
          <div className="flex justify-end gap-3"><button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button><button className="btn-brass">Create</button></div>
        </form>
      </Modal>
      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete team?" message="This cannot be undone." />
    </div>
  );
}
