import { useEffect, useState, useCallback } from 'react';
import DataTable from '../../components/ui/DataTable';
import { alumniService } from '../../services/lifecycleServices';

export default function AlumniPage() {
  const [alumni, setAlumni] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await alumniService.list({ page, limit: 10 });
      setAlumni(data.data);
      setPagination(data.pagination);
    } finally {
      setLoading(false);
    }
  }, [page]);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Alumni</h1>
        <p className="text-sm text-ink-400">Graduated students, tracked separately from active enrollment.</p>
      </div>

      <DataTable
        loading={loading}
        rows={alumni}
        pagination={pagination}
        onPageChange={setPage}
        columns={[
          { header: 'Name', accessor: (r) => `${r.student?.firstName || ''} ${r.student?.lastName || ''}` },
          { header: 'Admission No.', accessor: (r) => r.student?.admissionNumber },
          { header: 'Graduation Year', accessor: (r) => r.graduationYear },
          { header: 'Higher Education', accessor: (r) => r.higherEducation || '—' },
          { header: 'Occupation', accessor: (r) => r.currentOccupation || '—' },
          { header: 'Contact', accessor: (r) => r.contactEmail || r.contactPhone || '—' },
        ]}
      />
    </div>
  );
}
