import { useEffect, useState } from 'react';
import api from '../../services/api';
import StatCard from '../../components/ui/StatCard';
import FullPageLoader from '../../components/ui/FullPageLoader';

export default function SecurityDashboardPage() {
  const [data, setData] = useState(null);

  useEffect(() => {
    api.get('/security/dashboard').then(({ data }) => setData(data.data));
  }, []);

  if (!data) return <FullPageLoader />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Security Dashboard</h1>
        <p className="text-sm text-ink-400">Failed logins, permission changes, and recent admin activity.</p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <StatCard label="Failed Logins (30 days)" value={data.failedLoginsLast30Days} />
        <StatCard label="Password Changes (30 days)" value={data.passwordChangesLast30Days} />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="card p-5">
          <h3 className="mb-3 font-display text-base text-ink-700">Recent Failed Logins</h3>
          {data.recentFailedLogins.length === 0 ? (
            <p className="text-sm text-ink-400">None recorded.</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {data.recentFailedLogins.map((a) => (
                <li key={a._id} className="flex justify-between border-b border-ink-50 pb-2">
                  <span>{a.email} <span className="text-ink-400">({a.reason})</span></span>
                  <span className="text-ink-400">{new Date(a.createdAt).toLocaleString()}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="card p-5">
          <h3 className="mb-3 font-display text-base text-ink-700">Recent Admin Actions</h3>
          {data.recentAdminActions.length === 0 ? (
            <p className="text-sm text-ink-400">None recorded.</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {data.recentAdminActions.map((a) => (
                <li key={a._id} className="flex justify-between border-b border-ink-50 pb-2">
                  <span>{a.userLabel} — {a.action} {a.entity}</span>
                  <span className="text-ink-400">{new Date(a.createdAt).toLocaleString()}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
