import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { IoAddOutline, IoTrashOutline, IoRibbonOutline, IoMailOutline, IoSendOutline } from 'react-icons/io5';
import { TextField, SelectField } from '../../components/forms/FormFields';
import { settingsService } from '../../services/resourceServices';
import { useSchoolSettings } from '../../context/SchoolSettingsContext';
import FullPageLoader from '../../components/ui/FullPageLoader';
import api from '../../services/api';

export default function SettingsPage() {
  const { refresh } = useSchoolSettings();
  const [form, setForm] = useState(null);
  const [saving, setSaving] = useState(false);
  const [gradingScale, setGradingScale] = useState([]);
  const [savingGrading, setSavingGrading] = useState(false);
  const [emailForm, setEmailForm] = useState(null);
  const [savingEmail, setSavingEmail] = useState(false);
  const [testEmailAddress, setTestEmailAddress] = useState('');
  const [sendingTest, setSendingTest] = useState(false);

  const loadSettings = () => settingsService.get().then(({ data }) => {
    setForm(data.data);
    setGradingScale(data.data.gradingScale?.length ? data.data.gradingScale : []);
    setEmailForm({
      provider: data.data.emailConfig?.provider || 'none',
      host: data.data.emailConfig?.host || '',
      port: data.data.emailConfig?.port || 587,
      secure: data.data.emailConfig?.secure || false,
      user: data.data.emailConfig?.user || '',
      password: '', // never pre-filled — see hasPassword indicator below
      fromAddress: data.data.emailConfig?.fromAddress || '',
      fromName: data.data.emailConfig?.fromName || '',
      hasPassword: data.data.emailConfig?.hasPassword || false,
    });
  });

  useEffect(() => { loadSettings(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await settingsService.update(form);
      await refresh();
      toast.success('Settings saved.');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save settings.');
    } finally {
      setSaving(false);
    }
  };

  const updateTier = (idx, field, value) => {
    const next = [...gradingScale];
    next[idx] = { ...next[idx], [field]: field === 'grade' ? value : Number(value) };
    setGradingScale(next);
  };

  const addTier = () => setGradingScale([...gradingScale, { minPercentage: 0, grade: '', gpa: 0 }]);
  const removeTier = (idx) => setGradingScale(gradingScale.filter((_, i) => i !== idx));

  const handleSaveGrading = async () => {
    if (gradingScale.some((t) => !t.grade.trim())) {
      toast.error('Every tier needs a grade label.');
      return;
    }
    setSavingGrading(true);
    try {
      await settingsService.update({ gradingScale });
      toast.success('Grading system saved.');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save grading system.');
    } finally {
      setSavingGrading(false);
    }
  };

  const handleSaveEmail = async (e) => {
    e.preventDefault();
    setSavingEmail(true);
    try {
      // Blank password means "leave the saved one unchanged" — enforced
      // server-side too (see settingsController.js), this is just so the
      // admin doesn't have to re-type it every time they tweak other
      // provider fields.
      const { hasPassword, ...emailConfig } = emailForm;
      await settingsService.update({ emailConfig });
      toast.success('Email provider settings saved.');
      loadSettings();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save email settings.');
    } finally {
      setSavingEmail(false);
    }
  };

  const handleSendTest = async () => {
    setSendingTest(true);
    try {
      await api.post('/email-templates/send-test', { to: testEmailAddress || undefined });
      toast.success('Test email sent — check the inbox (and spam folder).');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to send test email. Check your provider settings.');
    } finally {
      setSendingTest(false);
    }
  };

  if (!form || !emailForm) return <FullPageLoader />;

  const sortedPreview = [...gradingScale].sort((a, b) => b.minPercentage - a.minPercentage);

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Institute Settings</h1>
        <p className="text-sm text-ink-400">Configure your institute's identity and system preferences.</p>
      </div>

      <form onSubmit={handleSubmit} className="card grid grid-cols-1 gap-4 p-6 sm:grid-cols-2">
        <TextField label="Institute Name" value={form.schoolName || ''} onChange={(e) => setForm({ ...form, schoolName: e.target.value })} />
        <TextField label="Logo URL" value={form.logoUrl || ''} onChange={(e) => setForm({ ...form, logoUrl: e.target.value })} />
        <TextField label="Address" value={form.address || ''} onChange={(e) => setForm({ ...form, address: e.target.value })} />
        <TextField label="Phone" value={form.phone || ''} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        <TextField label="Email" type="email" value={form.email || ''} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <TextField label="Website" value={form.website || ''} onChange={(e) => setForm({ ...form, website: e.target.value })} />
        <TextField label="Currency (e.g. USD)" value={form.currency || ''} onChange={(e) => setForm({ ...form, currency: e.target.value })} />
        <SelectField label="Date Format" value={form.dateFormat || ''} onChange={(e) => setForm({ ...form, dateFormat: e.target.value })}
          options={[{ value: 'DD/MM/YYYY', label: 'DD/MM/YYYY' }, { value: 'MM/DD/YYYY', label: 'MM/DD/YYYY' }, { value: 'YYYY-MM-DD', label: 'YYYY-MM-DD' }]} />
        <TextField label="Timezone" value={form.timezone || ''} onChange={(e) => setForm({ ...form, timezone: e.target.value })} />

        <div className="col-span-full flex justify-end">
          <button className="btn-brass" disabled={saving}>{saving ? 'Saving…' : 'Save Settings'}</button>
        </div>
      </form>

      <div className="card p-6">
        <div className="mb-1 flex items-center gap-2">
          <IoRibbonOutline className="text-brass-500" />
          <h2 className="font-display text-lg text-ink-800">Grading System</h2>
        </div>
        <p className="mb-4 text-sm text-ink-400">
          Define the percentage thresholds used to compute grades and GPA on every exam result and report card.
        </p>

        <div className="space-y-2">
          {gradingScale.map((tier, idx) => (
            <div key={idx} className="grid grid-cols-3 gap-2 sm:grid-cols-[1fr_1fr_1fr_auto]">
              <TextField label={idx === 0 ? 'Min %' : ''} type="number" min={0} max={100} value={tier.minPercentage}
                onChange={(e) => updateTier(idx, 'minPercentage', e.target.value)} />
              <TextField label={idx === 0 ? 'Grade' : ''} value={tier.grade}
                onChange={(e) => updateTier(idx, 'grade', e.target.value)} />
              <TextField label={idx === 0 ? 'GPA' : ''} type="number" step="0.1" value={tier.gpa}
                onChange={(e) => updateTier(idx, 'gpa', e.target.value)} />
              <div className={idx === 0 ? 'flex items-end' : 'flex items-center'}>
                <button type="button" className="btn-outline w-full sm:w-auto" onClick={() => removeTier(idx)}>
                  <IoTrashOutline />
                </button>
              </div>
            </div>
          ))}
        </div>

        <button type="button" className="btn-outline mt-3" onClick={addTier}>
          <IoAddOutline /> Add Tier
        </button>

        {sortedPreview.length > 0 && (
          <div className="mt-4 rounded-md bg-ink-50 p-3">
            <p className="mb-2 text-xs font-medium text-ink-400">PREVIEW (highest to lowest)</p>
            <div className="flex flex-wrap gap-2">
              {sortedPreview.map((t, i) => (
                <span key={i} className="rounded-full bg-white px-2.5 py-1 text-xs text-ink-600 shadow-sm">
                  {t.grade || '—'} ({t.minPercentage}%+, GPA {t.gpa})
                </span>
              ))}
            </div>
          </div>
        )}

        <div className="mt-4 flex justify-end">
          <button className="btn-brass" onClick={handleSaveGrading} disabled={savingGrading}>
            {savingGrading ? 'Saving…' : 'Save Grading System'}
          </button>
        </div>
      </div>

      <div className="card p-6">
        <div className="mb-1 flex items-center gap-2">
          <IoMailOutline className="text-brass-500" />
          <h2 className="font-display text-lg text-ink-800">Email Provider</h2>
        </div>
        <p className="mb-4 text-sm text-ink-400">
          Configure your own SMTP provider so password resets, welcome emails, and payment/result notifications send
          from your institute's own address. Without this, the server falls back to its shared default (or logs
          emails to the console in development).
        </p>

        <form onSubmit={handleSaveEmail} className="space-y-4">
          <SelectField label="Provider" value={emailForm.provider} onChange={(e) => setEmailForm({ ...emailForm, provider: e.target.value })}
            options={[{ value: 'none', label: 'None (use server default)' }, { value: 'smtp', label: 'Custom SMTP' }]} />

          {emailForm.provider === 'smtp' && (
            <>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <TextField label="SMTP Host" placeholder="smtp.gmail.com" value={emailForm.host} onChange={(e) => setEmailForm({ ...emailForm, host: e.target.value })} />
                <TextField label="Port" type="number" value={emailForm.port} onChange={(e) => setEmailForm({ ...emailForm, port: Number(e.target.value) })} />
              </div>
              <label className="flex items-center gap-2 text-sm text-ink-600">
                <input type="checkbox" checked={emailForm.secure} onChange={(e) => setEmailForm({ ...emailForm, secure: e.target.checked })} />
                Use SSL/TLS (typically port 465)
              </label>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <TextField label="SMTP Username" value={emailForm.user} onChange={(e) => setEmailForm({ ...emailForm, user: e.target.value })} />
                <TextField
                  label={emailForm.hasPassword ? 'SMTP Password (saved — leave blank to keep it)' : 'SMTP Password'}
                  type="password"
                  placeholder={emailForm.hasPassword ? '••••••••' : ''}
                  value={emailForm.password}
                  onChange={(e) => setEmailForm({ ...emailForm, password: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <TextField label="From Address" placeholder="no-reply@yourinstitute.com" value={emailForm.fromAddress} onChange={(e) => setEmailForm({ ...emailForm, fromAddress: e.target.value })} />
                <TextField label="From Name" placeholder="Your Institute" value={emailForm.fromName} onChange={(e) => setEmailForm({ ...emailForm, fromName: e.target.value })} />
              </div>
            </>
          )}

          <div className="flex justify-end">
            <button className="btn-brass" disabled={savingEmail}>{savingEmail ? 'Saving…' : 'Save Email Provider'}</button>
          </div>
        </form>

        <div className="mt-4 flex flex-wrap items-end gap-3 border-t border-ink-100 pt-4">
          <div className="flex-1">
            <TextField label="Send a test email to" placeholder="you@example.com" value={testEmailAddress} onChange={(e) => setTestEmailAddress(e.target.value)} />
          </div>
          <button type="button" className="btn-outline" onClick={handleSendTest} disabled={sendingTest}>
            <IoSendOutline /> {sendingTest ? 'Sending…' : 'Send Test Email'}
          </button>
        </div>
      </div>
    </div>
  );
}
