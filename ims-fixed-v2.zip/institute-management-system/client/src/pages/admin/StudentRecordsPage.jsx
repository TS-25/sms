import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoTrashOutline, IoTrophyOutline, IoWarningOutline, IoMedicalOutline, IoStarOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import Modal from '../../components/ui/Modal';
import EmptyState from '../../components/ui/EmptyState';
import { TextField, TextAreaField, SelectField } from '../../components/forms/FormFields';
import { studentRecordsService } from '../../services/engagementServices';
import { studentService } from '../../services/resourceServices';

function useStudentSearch() {
  const [query, setQuery] = useState('');
  const [options, setOptions] = useState([]);
  useEffect(() => {
    if (query.length < 2) { setOptions([]); return; }
    const t = setTimeout(async () => {
      const { data } = await studentService.list({ search: query, limit: 10 });
      setOptions(data.data);
    }, 300);
    return () => clearTimeout(t);
  }, [query]);
  return { query, setQuery, options, setOptions };
}

function StudentPicker({ value, label, onSelect }) {
  const { query, setQuery, options, setOptions } = useStudentSearch();
  return (
    <div>
      <label className="label">{label}</label>
      <input className="input" placeholder="Search student…" value={value || query} onChange={(e) => setQuery(e.target.value)} />
      {options.length > 0 && (
        <div className="mt-1 max-h-40 overflow-y-auto rounded-md border border-ink-100 bg-white shadow-sm">
          {options.map((s) => (
            <button type="button" key={s._id} className="block w-full px-3 py-2 text-left text-sm hover:bg-ink-50"
              onClick={() => { onSelect(s); setQuery(`${s.firstName} ${s.lastName || ''}`); setOptions([]); }}>
              {s.firstName} {s.lastName} — {s.admissionNumber}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default function StudentRecordsPage() {
  const [tab, setTab] = useState('Achievements');
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Student Records</h1>
        <p className="text-sm text-ink-400">Achievements, merit points, discipline, and health — health/discipline access is permission-gated.</p>
      </div>
      <div className="flex flex-wrap gap-1 border-b border-ink-100">
        {['Achievements', 'Merit Points', 'Discipline', 'Health Records'].map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 text-sm font-medium ${tab === t ? 'border-b-2 border-brass-400 text-ink-800' : 'text-ink-400'}`}>{t}</button>
        ))}
      </div>
      {tab === 'Achievements' && <AchievementsTab />}
      {tab === 'Merit Points' && <MeritTab />}
      {tab === 'Discipline' && <DisciplineTab />}
      {tab === 'Health Records' && <HealthTab />}
    </div>
  );
}

function AchievementsTab() {
  const [items, setItems] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({ student: '', category: 'academic', title: '', description: '' });

  const load = useCallback(async () => { const { data } = await studentRecordsService.achievements(); setItems(data.data); }, []);
  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await studentRecordsService.createAchievement(form);
      toast.success('Achievement recorded.');
      setModalOpen(false);
      setForm({ student: '', category: 'academic', title: '', description: '' });
      load();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed to save.'); }
  };
  const handleDelete = async (id) => { await studentRecordsService.removeAchievement(id); load(); };

  return (
    <div className="space-y-4">
      <div className="flex justify-end"><button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> Record Achievement</button></div>
      {items.length === 0 ? <EmptyState title="No achievements recorded yet" /> : (
        <div className="space-y-2">
          {items.map((a) => (
            <div key={a._id} className="card flex items-start justify-between p-4">
              <div className="flex gap-3">
                <IoTrophyOutline className="mt-0.5 text-brass-500" />
                <div>
                  <p className="text-sm font-medium text-ink-700">{a.title} <span className="text-xs text-ink-400 capitalize">({a.category})</span></p>
                  <p className="text-xs text-ink-500">{a.student?.firstName} {a.student?.lastName} · {new Date(a.date).toLocaleDateString()}</p>
                  {a.description && <p className="mt-1 text-sm text-ink-500">{a.description}</p>}
                </div>
              </div>
              <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => handleDelete(a._id)}><IoTrashOutline /></button>
            </div>
          ))}
        </div>
      )}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Record Achievement">
        <form onSubmit={handleCreate} className="space-y-4">
          <StudentPicker label="Student" onSelect={(s) => setForm({ ...form, student: s._id })} />
          <SelectField label="Category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}
            options={['academic', 'sports', 'cultural', 'competition', 'other'].map((c) => ({ value: c, label: c[0].toUpperCase() + c.slice(1) }))} />
          <TextField label="Title" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <TextAreaField label="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <div className="flex justify-end gap-3"><button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button><button className="btn-brass" disabled={!form.student}>Save</button></div>
        </form>
      </Modal>
    </div>
  );
}

function MeritTab() {
  const [items, setItems] = useState([]);
  const [leaderboard, setLeaderboard] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({ student: '', points: 1, reason: '' });

  const load = useCallback(async () => {
    const [p, l] = await Promise.all([studentRecordsService.merit(), studentRecordsService.meritLeaderboard()]);
    setItems(p.data.data);
    setLeaderboard(l.data.data);
  }, []);
  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await studentRecordsService.giveMerit(form);
      toast.success('Merit points given.');
      setModalOpen(false);
      setForm({ student: '', points: 1, reason: '' });
      load();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed to save.'); }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end"><button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> Give Merit Points</button></div>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="card p-5">
          <h3 className="mb-3 font-display text-base text-ink-700">Leaderboard</h3>
          {leaderboard.length === 0 ? <p className="text-sm text-ink-400">No points given yet.</p> : (
            <ul className="space-y-2 text-sm">
              {leaderboard.map((l, i) => (
                <li key={l._id} className="flex justify-between border-b border-ink-50 pb-2">
                  <span>{i + 1}. {l.student?.firstName} {l.student?.lastName}</span>
                  <span className="font-medium text-brass-600 flex items-center gap-1"><IoStarOutline /> {l.totalPoints}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="card p-5">
          <h3 className="mb-3 font-display text-base text-ink-700">Recent</h3>
          <ul className="space-y-2 text-sm">
            {items.slice(0, 10).map((p) => (
              <li key={p._id} className="flex justify-between border-b border-ink-50 pb-2">
                <span>{p.student?.firstName} {p.student?.lastName} — {p.reason}</span>
                <span className="text-brass-600">+{p.points}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Give Merit Points">
        <form onSubmit={handleCreate} className="space-y-4">
          <StudentPicker label="Student" onSelect={(s) => setForm({ ...form, student: s._id })} />
          <TextField label="Points" type="number" required value={form.points} onChange={(e) => setForm({ ...form, points: Number(e.target.value) })} />
          <TextField label="Reason" required value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} />
          <div className="flex justify-end gap-3"><button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button><button className="btn-brass" disabled={!form.student}>Give Points</button></div>
        </form>
      </Modal>
    </div>
  );
}

function DisciplineTab() {
  const [items, setItems] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({ student: '', description: '', actionTaken: '', followUp: '' });

  const load = useCallback(async () => { const { data } = await studentRecordsService.discipline(); setItems(data.data); }, []);
  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await studentRecordsService.createDiscipline(form);
      toast.success('Incident recorded.');
      setModalOpen(false);
      setForm({ student: '', description: '', actionTaken: '', followUp: '' });
      load();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed to save — you may not have permission.'); }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end"><button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> Record Incident</button></div>
      {items.length === 0 ? <EmptyState title="No incidents recorded" /> : (
        <div className="space-y-2">
          {items.map((d) => (
            <div key={d._id} className="card flex items-start gap-3 p-4">
              <IoWarningOutline className="mt-0.5 text-amber-500" />
              <div>
                <p className="text-sm font-medium text-ink-700">{d.student?.firstName} {d.student?.lastName} — {new Date(d.date).toLocaleDateString()}</p>
                <p className="text-sm text-ink-500">{d.description}</p>
                {d.actionTaken && <p className="text-xs text-ink-400">Action: {d.actionTaken}</p>}
              </div>
            </div>
          ))}
        </div>
      )}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Record Discipline Incident">
        <form onSubmit={handleCreate} className="space-y-4">
          <StudentPicker label="Student" onSelect={(s) => setForm({ ...form, student: s._id })} />
          <TextAreaField label="Description" required value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <TextField label="Action Taken" value={form.actionTaken} onChange={(e) => setForm({ ...form, actionTaken: e.target.value })} />
          <TextField label="Follow-up" value={form.followUp} onChange={(e) => setForm({ ...form, followUp: e.target.value })} />
          <div className="flex justify-end gap-3"><button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button><button className="btn-brass" disabled={!form.student}>Save</button></div>
        </form>
      </Modal>
    </div>
  );
}

function HealthTab() {
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [record, setRecord] = useState(null);
  const [form, setForm] = useState({ allergies: '', emergencyContact: '', emergencyContactPhone: '', medicalNotes: '' });

  const loadRecord = async (studentId) => {
    const { data } = await studentRecordsService.health(studentId);
    setRecord(data.data);
    setForm(data.data || { allergies: '', emergencyContact: '', emergencyContactPhone: '', medicalNotes: '' });
  };

  const handleSave = async (e) => {
    e.preventDefault();
    await studentRecordsService.saveHealth(selectedStudent._id, form);
    toast.success('Health record saved.');
  };

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <StudentPicker label="Select Student" onSelect={(s) => { setSelectedStudent(s); loadRecord(s._id); }} />
      </div>
      {selectedStudent && (
        <form onSubmit={handleSave} className="card space-y-4 p-5">
          <div className="mb-2 flex items-center gap-2">
            <IoMedicalOutline className="text-brass-500" />
            <h3 className="font-display text-base text-ink-700">{selectedStudent.firstName} {selectedStudent.lastName}'s Health Record</h3>
          </div>
          <TextAreaField label="Allergies" value={form.allergies} onChange={(e) => setForm({ ...form, allergies: e.target.value })} />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <TextField label="Emergency Contact Name" value={form.emergencyContact} onChange={(e) => setForm({ ...form, emergencyContact: e.target.value })} />
            <TextField label="Emergency Contact Phone" value={form.emergencyContactPhone} onChange={(e) => setForm({ ...form, emergencyContactPhone: e.target.value })} />
          </div>
          <TextAreaField label="Medical Notes" value={form.medicalNotes} onChange={(e) => setForm({ ...form, medicalNotes: e.target.value })} />
          <div className="flex justify-end"><button className="btn-brass">Save Health Record</button></div>
        </form>
      )}
    </div>
  );
}
