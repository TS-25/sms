import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoTrashOutline, IoPencilOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import DataTable from '../../components/ui/DataTable';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import { TextField, SelectField } from '../../components/forms/FormFields';
import { userService } from '../../services/resourceServices';
import { ROLE_LABELS } from '../../components/layout/navConfig';

// super_admin is a platform-level role — never selectable when creating a
// user from within a single school's Users page (see platformController.js
// for how schools themselves, and their first admin, get created).
const ROLE_OPTIONS = Object.entries(ROLE_LABELS)
  .filter(([value]) => value !== 'super_admin')
  .map(([value, label]) => ({ value, label }));

export default function UsersPage() {
  const [users, setUsers] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'staff', phone: '' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await userService.list({ search, page, limit: 10 });
      setUsers(data.data);
      setPagination(data.pagination);
    } finally {
      setLoading(false);
    }
  }, [search, page]);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => { setEditingId(null); setForm({ name: '', email: '', password: '', role: 'staff', phone: '' }); setModalOpen(true); };
  const openEdit = (u) => { setEditingId(u._id); setForm({ name: u.name, email: u.email, role: u.role, phone: u.phone || '', isActive: u.isActive }); setModalOpen(true); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        await userService.update(editingId, form);
        toast.success('User updated.');
      } else {
        await userService.create(form);
        toast.success('User created.');
      }
      setModalOpen(false);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save user.');
    }
  };

  const handleDelete = async () => {
    await userService.remove(deleteTarget._id);
    toast.success('User deleted.');
    setDeleteTarget(null);
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Users</h1>
          <p className="text-sm text-ink-400">Manage staff accounts and role assignments.</p>
        </div>
        <button className="btn-brass" onClick={openCreate}><IoAddOutline /> Add User</button>
      </div>

      <DataTable
        loading={loading}
        rows={users}
        search={search}
        onSearchChange={(v) => { setSearch(v); setPage(1); }}
        pagination={pagination}
        onPageChange={setPage}
        columns={[
          { header: 'Name', accessor: (r) => r.name },
          { header: 'Email', accessor: (r) => r.email },
          { header: 'Role', accessor: (r) => ROLE_LABELS[r.role] || r.role },
          {
            header: 'Status',
            accessor: (r) => (
              <span className={`rounded-full px-2 py-0.5 text-xs ${r.isActive ? 'bg-brass-50 text-brass-700' : 'bg-ink-100 text-ink-500'}`}>
                {r.isActive ? 'Active' : 'Inactive'}
              </span>
            ),
          },
        ]}
        actions={(row) => (
          <div className="flex justify-end gap-2">
            <button className="p-1.5 text-ink-400 hover:text-ink-700" onClick={() => openEdit(row)}><IoPencilOutline /></button>
            <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(row)}><IoTrashOutline /></button>
          </div>
        )}
      />

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editingId ? 'Edit User' : 'Add User'}>
        <form onSubmit={handleSubmit} className="space-y-4">
          <TextField label="Full Name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <TextField label="Email" type="email" required disabled={!!editingId} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          {!editingId && (
            <TextField label="Password" type="password" required minLength={6} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          )}
          <SelectField label="Role" required value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} options={ROLE_OPTIONS} />
          <TextField label="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          {editingId && (
            <label className="flex items-center gap-2 text-sm text-ink-600">
              <input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} />
              Account active
            </label>
          )}
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass">Save</button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete user?" message="This will permanently remove their account." />
    </div>
  );
}
