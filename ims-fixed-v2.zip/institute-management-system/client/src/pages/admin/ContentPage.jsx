import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoTrashOutline, IoPencilOutline, IoImageOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import EmptyState from '../../components/ui/EmptyState';
import { TextField, TextAreaField, SelectField } from '../../components/forms/FormFields';
import { cmsService, galleryService } from '../../services/engagementServices';

export default function ContentPage() {
  const [tab, setTab] = useState('Pages');
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Content & Website</h1>
        <p className="text-sm text-ink-400">Manage public pages and photo gallery albums.</p>
      </div>
      <div className="flex gap-1 border-b border-ink-100">
        {['Pages', 'Gallery'].map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 text-sm font-medium ${tab === t ? 'border-b-2 border-brass-400 text-ink-800' : 'text-ink-400'}`}>{t}</button>
        ))}
      </div>
      {tab === 'Pages' ? <PagesTab /> : <GalleryTab />}
    </div>
  );
}

function PagesTab() {
  const [pages, setPages] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ slug: '', title: '', content: '', isPublished: false });

  const load = useCallback(async () => {
    const { data } = await cmsService.list();
    setPages(data.data);
  }, []);
  useEffect(() => { load(); }, [load]);

  const openCreate = () => { setEditingId(null); setForm({ slug: '', title: '', content: '', isPublished: false }); setModalOpen(true); };
  const openEdit = (p) => { setEditingId(p._id); setForm(p); setModalOpen(true); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingId) await cmsService.update(editingId, form);
      else await cmsService.create(form);
      toast.success('Page saved.');
      setModalOpen(false);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save page.');
    }
  };

  const handleDelete = async () => {
    await cmsService.remove(deleteTarget._id);
    toast.success('Page deleted.');
    setDeleteTarget(null);
    load();
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end"><button className="btn-brass" onClick={openCreate}><IoAddOutline /> New Page</button></div>
      {pages.length === 0 ? (
        <EmptyState title="No pages yet" description="Create pages like About, Admissions, or Contact for your public site." />
      ) : (
        <div className="card overflow-hidden">
          <table className="table-base">
            <thead><tr><th>Title</th><th>Slug</th><th>Status</th><th className="text-right">Actions</th></tr></thead>
            <tbody>
              {pages.map((p) => (
                <tr key={p._id}>
                  <td>{p.title}</td>
                  <td className="text-ink-400">/{p.slug}</td>
                  <td><span className={`rounded-full px-2 py-0.5 text-xs ${p.isPublished ? 'bg-brass-50 text-brass-700' : 'bg-ink-100 text-ink-500'}`}>{p.isPublished ? 'Published' : 'Draft'}</span></td>
                  <td className="text-right">
                    <button className="p-1.5 text-ink-400 hover:text-ink-700" onClick={() => openEdit(p)}><IoPencilOutline /></button>
                    <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(p)}><IoTrashOutline /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editingId ? 'Edit Page' : 'New Page'} size="lg">
        <form onSubmit={handleSubmit} className="space-y-4">
          <TextField label="Title" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <TextField label="Slug (URL path)" required value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '-') })} />
          <TextAreaField label="Content (HTML or plain text)" required rows={8} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} />
          <label className="flex items-center gap-2 text-sm text-ink-600">
            <input type="checkbox" checked={form.isPublished} onChange={(e) => setForm({ ...form, isPublished: e.target.checked })} /> Published (visible on public site)
          </label>
          <div className="flex justify-end gap-3"><button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button><button className="btn-brass">Save Page</button></div>
        </form>
      </Modal>
      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete page?" message="This cannot be undone." />
    </div>
  );
}

function GalleryTab() {
  const [albums, setAlbums] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [imageModal, setImageModal] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ title: '', category: '', isPublic: false });
  const [imageForm, setImageForm] = useState({ url: '', caption: '' });

  const load = useCallback(async () => {
    const { data } = await galleryService.list();
    setAlbums(data.data);
  }, []);
  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await galleryService.create(form);
      toast.success('Album created.');
      setModalOpen(false);
      setForm({ title: '', category: '', isPublic: false });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create album.');
    }
  };

  const handleAddImage = async (e) => {
    e.preventDefault();
    const { data } = await galleryService.addImage(imageModal._id, imageForm);
    setImageModal(data.data);
    setImageForm({ url: '', caption: '' });
    load();
  };

  const handleRemoveImage = async (imageId) => {
    const { data } = await galleryService.removeImage(imageModal._id, imageId);
    setImageModal(data.data);
    load();
  };

  const handleDelete = async () => {
    await galleryService.remove(deleteTarget._id);
    toast.success('Album deleted.');
    setDeleteTarget(null);
    load();
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end"><button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> New Album</button></div>
      {albums.length === 0 ? (
        <EmptyState title="No albums yet" description="Create an album, then add image URLs to it." />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {albums.map((a) => (
            <div key={a._id} className="card p-5">
              <div className="mb-2 flex items-start justify-between">
                <div>
                  <p className="font-display text-base text-ink-800">{a.title}</p>
                  <p className="text-xs text-ink-400">{a.images.length} image(s) · {a.isPublic ? 'Public' : 'Private'}</p>
                </div>
                <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(a)}><IoTrashOutline /></button>
              </div>
              <button className="btn-outline w-full" onClick={() => setImageModal(a)}><IoImageOutline /> Manage Images</button>
            </div>
          ))}
        </div>
      )}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="New Album">
        <form onSubmit={handleCreate} className="space-y-4">
          <TextField label="Title" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <TextField label="Category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />
          <label className="flex items-center gap-2 text-sm text-ink-600">
            <input type="checkbox" checked={form.isPublic} onChange={(e) => setForm({ ...form, isPublic: e.target.checked })} /> Public (visible on public site)
          </label>
          <div className="flex justify-end gap-3"><button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button><button className="btn-brass">Create</button></div>
        </form>
      </Modal>
      {imageModal && (
        <Modal isOpen onClose={() => setImageModal(null)} title={`${imageModal.title} — Images`} size="lg">
          <form onSubmit={handleAddImage} className="mb-4 flex flex-wrap items-end gap-3">
            <div className="flex-1"><TextField label="Image URL" required value={imageForm.url} onChange={(e) => setImageForm({ ...imageForm, url: e.target.value })} /></div>
            <TextField label="Caption" value={imageForm.caption} onChange={(e) => setImageForm({ ...imageForm, caption: e.target.value })} />
            <button className="btn-brass">Add</button>
          </form>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {imageModal.images.map((img) => (
              <div key={img._id} className="relative rounded-md border border-ink-100 p-2">
                <img src={img.url} alt={img.caption} className="mb-1 h-24 w-full rounded object-cover" />
                <p className="truncate text-xs text-ink-500">{img.caption}</p>
                <button className="absolute right-1 top-1 rounded-full bg-white p-1 text-red-600 shadow" onClick={() => handleRemoveImage(img._id)}><IoTrashOutline size={12} /></button>
              </div>
            ))}
          </div>
        </Modal>
      )}
      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete album?" message="This cannot be undone." />
    </div>
  );
}
