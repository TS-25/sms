import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoTrashOutline, IoPencilOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import api from '../../services/api';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import EmptyState from '../../components/ui/EmptyState';
import { TextField } from '../../components/forms/FormFields';

const roleService = {
  catalog: () => api.get('/roles/permissions'),
  list: () => api.get('/roles'),
  create: (data) => api.post('/roles', data),
  update: (id, data) => api.put(`/roles/${id}`, data),
  remove: (id) => api.delete(`/roles/${id}`),
};

export default function RolesPage() {
  const [catalog, setCatalog] = useState([]);
  const [roles, setRoles] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ name: '', description: '', permissions: [] });

  const load = useCallback(async () => {
    const [c, r] = await Promise.all([roleService.catalog(), roleService.list()]);
    setCatalog(c.data.data);
    setRoles(r.data.data);
  }, []);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => { setEditingId(null); setForm({ name: '', description: '', permissions: [] }); setModalOpen(true); };
  const openEdit = (r) => { setEditingId(r._id); setForm({ name: r.name, description: r.description || '', permissions: r.permissions }); setModalOpen(true); };

  const togglePerm = (perm) => {
    setForm((f) => ({
      ...f,
      permissions: f.permissions.includes(perm) ? f.permissions.filter((p) => p !== perm) : [...f.permissions, perm],
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        await roleService.update(editingId, form);
        toast.success('Role updated.');
      } else {
        await roleService.create(form);
        toast.success('Role created.');
      }
      setModalOpen(false);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save role.');
    }
  };

  const handleDelete = async () => {
    await roleService.remove(deleteTarget._id);
    toast.success('Role deleted.');
    setDeleteTarget(null);
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Custom Roles</h1>
          <p className="text-sm text-ink-400">
            Grant staff accounts fine-grained permissions beyond their base role. `admin` always has full access and never needs a custom role.
          </p>
        </div>
        <button className="btn-brass" onClick={openCreate}><IoAddOutline /> New Role</button>
      </div>

      {roles.length === 0 ? (
        <EmptyState title="No custom roles yet" description="Create one to grant specific permissions to a staff account." />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {roles.map((r) => (
            <div key={r._id} className="card p-5">
              <div className="mb-2 flex items-start justify-between">
                <div>
                  <p className="font-display text-base text-ink-800">{r.name}</p>
                  {r.description && <p className="text-sm text-ink-500">{r.description}</p>}
                </div>
                <div className="flex gap-1">
                  <button className="p-1.5 text-ink-400 hover:text-ink-700" onClick={() => openEdit(r)}><IoPencilOutline /></button>
                  <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(r)}><IoTrashOutline /></button>
                </div>
              </div>
              <div className="flex flex-wrap gap-1">
                {r.permissions.map((p) => (
                  <span key={p} className="rounded-full bg-ink-50 px-2 py-0.5 text-xs text-ink-600">{p}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editingId ? 'Edit Role' : 'New Role'} size="lg">
        <form onSubmit={handleSubmit} className="space-y-4">
          <TextField label="Role Name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <TextField label="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <div>
            <p className="label mb-2">Permissions</p>
            <div className="max-h-72 space-y-3 overflow-y-auto rounded-md border border-ink-100 p-3">
              {catalog.map((group) => (
                <div key={group.group}>
                  <p className="mb-1 text-xs font-medium uppercase text-ink-400">{group.group}</p>
                  <div className="flex flex-wrap gap-2">
                    {group.permissions.map((perm) => (
                      <button
                        type="button"
                        key={perm}
                        onClick={() => togglePerm(perm)}
                        className={`rounded-full px-2.5 py-1 text-xs ${form.permissions.includes(perm) ? 'bg-brass-400 text-ink-900' : 'bg-ink-50 text-ink-600'}`}
                      >
                        {perm}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass">Save Role</button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete role?" message="Users with this role assigned will lose its permissions immediately." />
    </div>
  );
}
