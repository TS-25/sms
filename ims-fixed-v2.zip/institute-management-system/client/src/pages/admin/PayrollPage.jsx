import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoCalculatorOutline, IoCheckmarkOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import api from '../../services/api';
import { TextField, SelectField } from '../../components/forms/FormFields';
import { teacherService, staffService } from '../../services/resourceServices';

const payrollService = {
  structures: () => api.get('/payroll/structures'),
  upsertStructure: (data) => api.post('/payroll/structures', data),
  generate: (data) => api.post('/payroll/generate', data),
  payslips: (params) => api.get('/payroll/payslips', { params }),
  markPaid: (id) => api.patch(`/payroll/payslips/${id}/pay`),
};

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

export default function PayrollPage() {
  const [tab, setTab] = useState('Payslips');
  const [teachers, setTeachers] = useState([]);
  const [staff, setStaff] = useState([]);
  const [structures, setStructures] = useState([]);
  const [payslips, setPayslips] = useState([]);
  const [structureForm, setStructureForm] = useState({ employee: '', employeeModel: 'Teacher', basicSalary: '', allowances: 0, deductions: 0 });
  const now = new Date();
  const [genMonth, setGenMonth] = useState(now.getMonth() + 1);
  const [genYear, setGenYear] = useState(now.getFullYear());

  const load = useCallback(async () => {
    const [t, s, st, p] = await Promise.all([
      teacherService.list({ limit: 100 }), staffService.list({ limit: 100 }),
      payrollService.structures(), payrollService.payslips({ year: genYear, month: genMonth }),
    ]);
    setTeachers(t.data.data);
    setStaff(s.data.data);
    setStructures(st.data.data);
    setPayslips(p.data.data);
  }, [genMonth, genYear]);

  useEffect(() => { load(); }, [load]);

  const employeeOptions = structureForm.employeeModel === 'Teacher'
    ? teachers.map((t) => ({ value: t._id, label: `${t.firstName} ${t.lastName || ''}` }))
    : staff.map((s) => ({ value: s._id, label: `${s.firstName} ${s.lastName || ''}` }));

  const findEmployeeName = (id, model) => {
    const list = model === 'Teacher' ? teachers : staff;
    const emp = list.find((e) => e._id === id);
    return emp ? `${emp.firstName} ${emp.lastName || ''}` : '—';
  };

  const handleSaveStructure = async (e) => {
    e.preventDefault();
    try {
      await payrollService.upsertStructure(structureForm);
      toast.success('Salary structure saved.');
      setStructureForm({ employee: '', employeeModel: 'Teacher', basicSalary: '', allowances: 0, deductions: 0 });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save salary structure.');
    }
  };

  const handleGenerate = async () => {
    try {
      const { data } = await payrollService.generate({ month: genMonth, year: genYear });
      toast.success(`Generated ${data.data.created} payslip(s), skipped ${data.data.skipped} (already existed).`);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to generate payroll.');
    }
  };

  const handleMarkPaid = async (id) => {
    await payrollService.markPaid(id);
    toast.success('Marked as paid.');
    load();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Payroll</h1>
        <p className="text-sm text-ink-400">Salary structures and monthly payslip generation for teachers and staff.</p>
      </div>

      <div className="flex gap-1 border-b border-ink-100">
        {['Payslips', 'Salary Structures'].map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 text-sm font-medium ${tab === t ? 'border-b-2 border-brass-400 text-ink-800' : 'text-ink-400'}`}>{t}</button>
        ))}
      </div>

      {tab === 'Payslips' ? (
        <div className="space-y-4">
          <div className="card flex flex-wrap items-end gap-3 p-5">
            <SelectField label="Month" value={genMonth} onChange={(e) => setGenMonth(Number(e.target.value))}
              options={MONTHS.map((m, i) => ({ value: i + 1, label: m }))} />
            <TextField label="Year" type="number" value={genYear} onChange={(e) => setGenYear(Number(e.target.value))} />
            <button className="btn-brass" onClick={handleGenerate}><IoCalculatorOutline /> Generate Payroll</button>
          </div>
          <div className="card overflow-hidden">
            <table className="table-base">
              <thead><tr><th>Employee</th><th>Basic</th><th>Allowances</th><th>Deductions</th><th>Net Pay</th><th>Status</th><th className="text-right">Actions</th></tr></thead>
              <tbody>
                {payslips.length === 0 ? (
                  <tr><td colSpan={7} className="py-8 text-center text-ink-400">No payslips for this period yet — click Generate.</td></tr>
                ) : payslips.map((p) => (
                  <tr key={p._id}>
                    <td>{findEmployeeName(p.employee, p.employeeModel)}</td>
                    <td>{p.basicSalary}</td>
                    <td>{p.allowances}</td>
                    <td>{p.deductions}</td>
                    <td className="font-medium">{p.netPay}</td>
                    <td><span className={`rounded-full px-2 py-0.5 text-xs ${p.status === 'paid' ? 'bg-brass-50 text-brass-700' : 'bg-ink-100 text-ink-500'}`}>{p.status}</span></td>
                    <td className="text-right">
                      {p.status !== 'paid' && (
                        <button className="btn-outline px-2 py-1 text-xs" onClick={() => handleMarkPaid(p._id)}><IoCheckmarkOutline /> Mark Paid</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <form onSubmit={handleSaveStructure} className="card grid grid-cols-1 gap-4 p-5 sm:grid-cols-5">
            <SelectField label="Type" value={structureForm.employeeModel} onChange={(e) => setStructureForm({ ...structureForm, employeeModel: e.target.value, employee: '' })}
              options={[{ value: 'Teacher', label: 'Teacher' }, { value: 'Staff', label: 'Staff' }]} />
            <SelectField label="Employee" value={structureForm.employee} onChange={(e) => setStructureForm({ ...structureForm, employee: e.target.value })} options={employeeOptions} />
            <TextField label="Basic Salary" type="number" required value={structureForm.basicSalary} onChange={(e) => setStructureForm({ ...structureForm, basicSalary: e.target.value })} />
            <TextField label="Allowances" type="number" value={structureForm.allowances} onChange={(e) => setStructureForm({ ...structureForm, allowances: e.target.value })} />
            <TextField label="Deductions" type="number" value={structureForm.deductions} onChange={(e) => setStructureForm({ ...structureForm, deductions: e.target.value })} />
            <div className="col-span-full flex justify-end">
              <button className="btn-brass" disabled={!structureForm.employee}><IoAddOutline /> Save Structure</button>
            </div>
          </form>
          <div className="card overflow-hidden">
            <table className="table-base">
              <thead><tr><th>Employee</th><th>Type</th><th>Basic</th><th>Allowances</th><th>Deductions</th></tr></thead>
              <tbody>
                {structures.map((s) => (
                  <tr key={s._id}>
                    <td>{findEmployeeName(s.employee, s.employeeModel)}</td>
                    <td>{s.employeeModel}</td>
                    <td>{s.basicSalary}</td>
                    <td>{s.allowances}</td>
                    <td>{s.deductions}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
