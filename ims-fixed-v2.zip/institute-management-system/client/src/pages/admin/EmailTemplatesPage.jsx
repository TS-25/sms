import { useEffect, useState } from 'react';
import { IoMailOutline, IoRefreshOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import api from '../../services/api';
import { TextAreaField, TextField } from '../../components/forms/FormFields';
import FullPageLoader from '../../components/ui/FullPageLoader';

const TYPE_LABELS = {
  welcome: 'Welcome Email',
  password_reset: 'Password Reset',
  fee_reminder: 'Fee Reminder',
  payment_confirmation: 'Payment Confirmation',
  result_published: 'Result Published',
  notice_published: 'Notice Published',
};

const templateService = {
  list: () => api.get('/email-templates'),
  save: (type, data) => api.put(`/email-templates/${type}`, data),
  reset: (type) => api.delete(`/email-templates/${type}`),
};

export default function EmailTemplatesPage() {
  const [templates, setTemplates] = useState(null);
  const [active, setActive] = useState(null);
  const [saving, setSaving] = useState(false);

  const load = () => templateService.list().then(({ data }) => {
    setTemplates(data.data);
    setActive((prev) => prev ? data.data.find((t) => t.type === prev.type) : data.data[0]);
  });

  useEffect(() => { load(); }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await templateService.save(active.type, { subject: active.subject, body: active.body });
      toast.success('Template saved.');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save template.');
    } finally {
      setSaving(false);
    }
  };

  const handleReset = async () => {
    await templateService.reset(active.type);
    toast.success('Reverted to default.');
    load();
  };

  if (!templates || !active) return <FullPageLoader />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Email Templates</h1>
        <p className="text-sm text-ink-400">
          Customize the wording sent for each automated email. Use placeholders like <code>{'{{studentName}}'}</code>, <code>{'{{institutionName}}'}</code>, <code>{'{{amount}}'}</code> — they're filled in automatically when sent.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="card">
          {templates.map((t) => (
            <button
              key={t.type}
              onClick={() => setActive(t)}
              className={`flex w-full items-center justify-between border-b border-ink-50 px-4 py-3 text-left text-sm last:border-0 hover:bg-ink-50 ${active.type === t.type ? 'bg-brass-50' : ''}`}
            >
              <span className="flex items-center gap-2"><IoMailOutline className="text-ink-300" /> {TYPE_LABELS[t.type] || t.type}</span>
              {t.isCustomized && <span className="rounded-full bg-brass-400 px-2 py-0.5 text-xs text-ink-900">Custom</span>}
            </button>
          ))}
        </div>

        <form onSubmit={handleSave} className="card space-y-4 p-6 lg:col-span-2">
          <h2 className="font-display text-lg text-ink-800">{TYPE_LABELS[active.type]}</h2>
          <TextField label="Subject" required value={active.subject} onChange={(e) => setActive({ ...active, subject: e.target.value })} />
          <TextAreaField label="Body" required rows={8} value={active.body} onChange={(e) => setActive({ ...active, body: e.target.value })} />
          <div className="flex justify-between">
            <button type="button" className="btn-outline text-ink-500" onClick={handleReset}>
              <IoRefreshOutline /> Revert to Default
            </button>
            <button className="btn-brass" disabled={saving}>{saving ? 'Saving…' : 'Save Template'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
