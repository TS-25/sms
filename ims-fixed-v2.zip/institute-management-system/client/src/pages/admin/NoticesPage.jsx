import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoTrashOutline, IoMegaphoneOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import EmptyState from '../../components/ui/EmptyState';
import { TextField, SelectField, TextAreaField } from '../../components/forms/FormFields';
import { noticeService } from '../../services/resourceServices';
import { useAuth } from '../../context/AuthContext';
import { useAcademicLookups } from '../../hooks/useAcademicLookups';

const AUDIENCE_OPTIONS = ['everyone', 'teachers', 'students', 'parents', 'staff', 'class'].map((a) => ({
  value: a, label: a[0].toUpperCase() + a.slice(1),
}));

export default function NoticesPage() {
  const { user } = useAuth();
  const { classes } = useAcademicLookups();
  const canManage = ['super_admin', 'admin', 'principal', 'teacher'].includes(user?.role);
  const canDelete = ['super_admin', 'admin', 'principal'].includes(user?.role);

  const [notices, setNotices] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ title: '', description: '', targetAudience: 'everyone', targetClass: '', expiryDate: '' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await noticeService.list();
      setNotices(data.data);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      // Only send targetClass/expiryDate when they're actually set — an
      // empty string fails Mongoose's ObjectId/Date cast and previously
      // broke creation for every notice that wasn't targeted at a class.
      const payload = { title: form.title, description: form.description, targetAudience: form.targetAudience };
      if (form.targetAudience === 'class' && form.targetClass) payload.targetClass = form.targetClass;
      if (form.expiryDate) payload.expiryDate = form.expiryDate;

      await noticeService.create(payload);
      toast.success('Notice published.');
      setModalOpen(false);
      setForm({ title: '', description: '', targetAudience: 'everyone', targetClass: '', expiryDate: '' });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to publish notice.');
    }
  };

  const handleDelete = async () => {
    await noticeService.remove(deleteTarget._id);
    toast.success('Notice deleted.');
    setDeleteTarget(null);
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Notices</h1>
          <p className="text-sm text-ink-400">Announcements and updates for the school community.</p>
        </div>
        {canManage && (
          <button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> New Notice</button>
        )}
      </div>

      {loading ? (
        <p className="text-ink-400">Loading…</p>
      ) : notices.length === 0 ? (
        <EmptyState title="No notices yet" description="Published notices will appear here." />
      ) : (
        <div className="space-y-3">
          {notices.map((n) => (
            <div key={n._id} className="card flex items-start justify-between gap-4 p-5">
              <div className="flex gap-3">
                <IoMegaphoneOutline className="mt-1 shrink-0 text-brass-500" size={20} />
                <div>
                  <h3 className="font-display text-base text-ink-800">{n.title}</h3>
                  <p className="mt-1 text-sm text-ink-500">{n.description}</p>
                  <p className="mt-2 text-xs text-ink-300">
                    {new Date(n.publishDate).toLocaleDateString()} · Audience: {n.targetAudience} · By {n.createdBy?.name}
                  </p>
                </div>
              </div>
              {canDelete && (
                <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(n)}>
                  <IoTrashOutline />
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="New Notice" size="lg">
        <form onSubmit={handleCreate} className="space-y-4">
          <TextField label="Title" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <TextAreaField label="Description" required value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <SelectField label="Target Audience" value={form.targetAudience} onChange={(e) => setForm({ ...form, targetAudience: e.target.value })} options={AUDIENCE_OPTIONS} />
          {form.targetAudience === 'class' && (
            <SelectField label="Class" value={form.targetClass} onChange={(e) => setForm({ ...form, targetClass: e.target.value })}
              options={classes.map((c) => ({ value: c._id, label: c.name }))} />
          )}
          <TextField label="Expiry Date (optional)" type="date" value={form.expiryDate} onChange={(e) => setForm({ ...form, expiryDate: e.target.value })} />
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass">Publish</button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete notice?" message="This cannot be undone." />
    </div>
  );
}
