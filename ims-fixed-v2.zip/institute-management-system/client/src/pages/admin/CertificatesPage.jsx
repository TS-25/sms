import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoTrashOutline, IoDownloadOutline, IoPencilOutline, IoRibbonOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import EmptyState from '../../components/ui/EmptyState';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import { TextField, SelectField, TextAreaField } from '../../components/forms/FormFields';
import { certificateService, studentService } from '../../services/resourceServices';
import { openPdf } from '../../utils/openPdf';

const CERT_TYPES = ['character', 'transfer', 'participation', 'achievement', 'bonafide', 'other'];

const TEMPLATE_BODY = {
  character: 'This is to certify that {{studentName}} has been a student of good moral character during their time at this school, and has consistently demonstrated discipline, integrity, and respect for others.',
  transfer: 'This is to certify that {{studentName}} has been a bona fide student of this school and is being transferred at the request of their guardian. All dues have been cleared.',
  bonafide: 'This is to certify that {{studentName}} is a bona fide student of this school, currently enrolled in the current academic session.',
  participation: 'This certificate is proudly presented to {{studentName}} for their enthusiastic participation in the school activity.',
  achievement: 'This certificate is proudly presented to {{studentName}} in recognition of their outstanding achievement.',
  other: '',
};

const emptyForm = { student: '', type: 'bonafide', title: '', body: TEMPLATE_BODY.bonafide };

export default function CertificatesPage() {
  const [certificates, setCertificates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [studentQuery, setStudentQuery] = useState('');
  const [studentOptions, setStudentOptions] = useState([]);
  const [studentLabel, setStudentLabel] = useState('');
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await certificateService.list();
      setCertificates(data.data);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (studentQuery.length < 2) { setStudentOptions([]); return; }
    const t = setTimeout(async () => {
      const { data } = await studentService.list({ search: studentQuery, limit: 10 });
      setStudentOptions(data.data);
    }, 300);
    return () => clearTimeout(t);
  }, [studentQuery]);

  const openCreate = () => {
    setEditingId(null);
    setForm(emptyForm);
    setStudentQuery('');
    setStudentLabel('');
    setModalOpen(true);
  };

  const openEdit = (cert) => {
    setEditingId(cert._id);
    setForm({ student: cert.student?._id, type: cert.type, title: cert.title, body: cert.body });
    setStudentLabel(`${cert.student?.firstName || ''} ${cert.student?.lastName || ''}`.trim());
    setStudentQuery('');
    setModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editingId) {
        // Student is fixed once issued; only wording/type/title are editable.
        await certificateService.update(editingId, { type: form.type, title: form.title, body: form.body });
        toast.success('Certificate updated.');
      } else {
        await certificateService.create(form);
        toast.success('Certificate issued.');
      }
      setModalOpen(false);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save certificate.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    await certificateService.remove(deleteTarget._id);
    toast.success('Certificate deleted.');
    setDeleteTarget(null);
    load();
  };

  const handleDownload = (id) => {
    openPdf(certificateService.pdfUrl(id)).catch(() => toast.error('Failed to generate PDF.'));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Certificates</h1>
          <p className="text-sm text-ink-400">Issue, edit, and download student certificates.</p>
        </div>
        <button className="btn-brass" onClick={openCreate}><IoAddOutline /> Issue Certificate</button>
      </div>

      {loading ? (
        <p className="text-ink-400">Loading…</p>
      ) : certificates.length === 0 ? (
        <EmptyState
          title="No certificates issued yet"
          description="Issued certificates will appear here, ready to edit or download as a premium printable PDF."
          action={<button className="btn-brass" onClick={openCreate}><IoRibbonOutline /> Issue your first certificate</button>}
        />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {certificates.map((c) => (
            <div key={c._id} className="card p-5">
              <div className="mb-2 flex items-start justify-between gap-2">
                <div>
                  <p className="font-display text-base text-ink-800">{c.title}</p>
                  <p className="text-xs text-ink-400 capitalize">{c.type} · {c.certificateNumber}</p>
                </div>
                <IoRibbonOutline className="shrink-0 text-brass-500" size={20} />
              </div>
              <p className="text-sm text-ink-600">{c.student?.firstName} {c.student?.lastName}</p>
              <p className="text-xs text-ink-400">{new Date(c.issueDate).toLocaleDateString()}</p>
              <div className="mt-3 flex gap-2">
                <button className="btn-outline flex-1 px-2 py-1.5 text-xs" onClick={() => openEdit(c)}>
                  <IoPencilOutline /> Edit
                </button>
                <button className="btn-outline flex-1 px-2 py-1.5 text-xs" onClick={() => handleDownload(c._id)}>
                  <IoDownloadOutline /> PDF
                </button>
                <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(c)}>
                  <IoTrashOutline />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editingId ? 'Edit Certificate' : 'Issue Certificate'} size="lg">
        <form onSubmit={handleSubmit} className="space-y-4">
          {!editingId ? (
            <div>
              <label className="label">Student</label>
              <input className="input" placeholder="Search by name or admission number…" value={studentQuery} onChange={(e) => setStudentQuery(e.target.value)} />
              {studentOptions.length > 0 && (
                <div className="mt-1 max-h-40 overflow-y-auto rounded-md border border-ink-100 bg-white shadow-sm">
                  {studentOptions.map((s) => (
                    <button type="button" key={s._id} className="block w-full px-3 py-2 text-left text-sm hover:bg-ink-50"
                      onClick={() => { setForm({ ...form, student: s._id }); setStudentQuery(`${s.firstName} ${s.lastName || ''}`); setStudentOptions([]); }}>
                      {s.firstName} {s.lastName} — {s.admissionNumber}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div>
              <label className="label">Student</label>
              <p className="rounded-md border border-ink-100 bg-ink-50 px-3 py-2 text-sm text-ink-500">{studentLabel} (fixed once issued)</p>
            </div>
          )}
          <SelectField label="Type" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value, body: editingId ? form.body : (TEMPLATE_BODY[e.target.value] || '') })}
            options={CERT_TYPES.map((t) => ({ value: t, label: t[0].toUpperCase() + t.slice(1) }))} />
          <TextField label="Title (e.g. Character Certificate)" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <TextAreaField label="Body (use {{studentName}} as placeholder)" required rows={6} value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} />
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass" disabled={saving || (!editingId && !form.student)}>
              {saving ? 'Saving…' : editingId ? 'Save Changes' : 'Issue Certificate'}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete certificate?" message="This cannot be undone." />
    </div>
  );
}
