import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { SelectField, TextField } from '../../components/forms/FormFields';
import { studentService } from '../../services/resourceServices';
import { promotionService } from '../../services/lifecycleServices';
import { useAcademicLookups } from '../../hooks/useAcademicLookups';

export default function PromotionPage() {
  const { classes, sectionsForClass, sessions } = useAcademicLookups();
  const [fromClass, setFromClass] = useState('');
  const [fromSection, setFromSection] = useState('');
  const [students, setStudents] = useState([]);
  const [selected, setSelected] = useState([]);
  const [toClass, setToClass] = useState('');
  const [toSection, setToSection] = useState('');
  const [toSession, setToSession] = useState('');

  useEffect(() => {
    if (!fromClass || !fromSection) { setStudents([]); return; }
    studentService.list({ class: fromClass, section: fromSection, limit: 200 }).then(({ data }) => {
      setStudents(data.data);
      setSelected([]);
    });
  }, [fromClass, fromSection]);

  const toggle = (id) => setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  const toggleAll = () => setSelected(selected.length === students.length ? [] : students.map((s) => s._id));

  const handlePromote = async () => {
    if (!selected.length || !toClass || !toSection) { toast.error('Select students and a target class/section.'); return; }
    try {
      const { data } = await promotionService.promote({ studentIds: selected, toClass, toSection, toSession: toSession || undefined });
      toast.success(`Promoted ${data.data.promoted} student(s).`);
      setStudents((prev) => prev.filter((s) => !selected.includes(s._id)));
      setSelected([]);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to promote students.');
    }
  };

  const handleGraduate = async () => {
    if (!selected.length) { toast.error('Select at least one student.'); return; }
    try {
      const { data } = await promotionService.graduate({ studentIds: selected, graduationYear: new Date().getFullYear() });
      toast.success(`Graduated ${data.data.graduated} student(s) — moved to Alumni.`);
      setStudents((prev) => prev.filter((s) => !selected.includes(s._id)));
      setSelected([]);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to graduate students.');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Student Promotion</h1>
        <p className="text-sm text-ink-400">Promote, repeat, or graduate students — full history is kept, nothing is overwritten.</p>
      </div>

      <div className="card grid grid-cols-1 gap-4 p-5 sm:grid-cols-2">
        <SelectField label="From Class" value={fromClass} onChange={(e) => { setFromClass(e.target.value); setFromSection(''); }}
          options={classes.map((c) => ({ value: c._id, label: c.name }))} />
        <SelectField label="From Section" value={fromSection} onChange={(e) => setFromSection(e.target.value)}
          options={sectionsForClass(fromClass).map((s) => ({ value: s._id, label: s.name }))} />
      </div>

      {students.length > 0 && (
        <div className="card overflow-hidden">
          <table className="table-base">
            <thead>
              <tr>
                <th><input type="checkbox" checked={selected.length === students.length} onChange={toggleAll} /></th>
                <th>Admission No.</th>
                <th>Name</th>
              </tr>
            </thead>
            <tbody>
              {students.map((s) => (
                <tr key={s._id}>
                  <td><input type="checkbox" checked={selected.includes(s._id)} onChange={() => toggle(s._id)} /></td>
                  <td>{s.admissionNumber}</td>
                  <td>{s.firstName} {s.lastName}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="grid grid-cols-1 gap-4 border-t border-ink-100 p-5 sm:grid-cols-4">
            <SelectField label="To Class" value={toClass} onChange={(e) => { setToClass(e.target.value); setToSection(''); }}
              options={classes.map((c) => ({ value: c._id, label: c.name }))} />
            <SelectField label="To Section" value={toSection} onChange={(e) => setToSection(e.target.value)}
              options={sectionsForClass(toClass).map((s) => ({ value: s._id, label: s.name }))} />
            <SelectField label="To Session (optional)" value={toSession} onChange={(e) => setToSession(e.target.value)}
              options={sessions.map((s) => ({ value: s._id, label: s.name }))} />
            <div className="flex items-end gap-2">
              <button className="btn-brass flex-1" onClick={handlePromote}>Promote ({selected.length})</button>
            </div>
          </div>
          <div className="flex justify-end border-t border-ink-100 p-5">
            <button className="btn-outline text-red-600" onClick={handleGraduate}>Graduate Selected → Alumni</button>
          </div>
        </div>
      )}
    </div>
  );
}
