import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoDocumentTextOutline, IoLockClosedOutline, IoCheckmarkCircleOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import Modal from '../../components/ui/Modal';
import { TextField, SelectField } from '../../components/forms/FormFields';
import { examService, studentService } from '../../services/resourceServices';
import { getAccessToken } from '../../services/api';
import { useAcademicLookups } from '../../hooks/useAcademicLookups';

const API_URL = import.meta.env.VITE_API_URL || '/api';

export default function ExamsPage() {
  const { classes, sessions, subjects } = useAcademicLookups();
  const [exams, setExams] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [resultsModal, setResultsModal] = useState(null); // exam being viewed
  const [results, setResults] = useState([]);
  const [students, setStudents] = useState([]);
  const [form, setForm] = useState({ name: '', class: '', academicSession: '', subjects: [] });

  const load = useCallback(async () => {
    const { data } = await examService.list();
    setExams(data.data);
  }, []);

  useEffect(() => { load(); }, [load]);

  const toggleSubject = (subjectId) => {
    setForm((f) => {
      const exists = f.subjects.find((s) => s.subject === subjectId);
      if (exists) return { ...f, subjects: f.subjects.filter((s) => s.subject !== subjectId) };
      return { ...f, subjects: [...f.subjects, { subject: subjectId, fullMarks: 100, passMarks: 33 }] };
    });
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await examService.create(form);
      toast.success('Exam created.');
      setModalOpen(false);
      setForm({ name: '', class: '', academicSession: '', subjects: [] });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create exam.');
    }
  };

  const openResults = async (exam) => {
    setResultsModal(exam);
    const [resultsRes, studentsRes] = await Promise.all([
      examService.getResults(exam._id),
      studentService.list({ class: exam.class?._id, limit: 100 }),
    ]);
    setResults(resultsRes.data.data);
    setStudents(studentsRes.data.data);
  };

  const handleMarksSave = async (studentId, marksBySubject) => {
    const marks = exam2marks(resultsModal, marksBySubject);
    try {
      await examService.upsertResult(resultsModal._id, { student: studentId, marks });
      toast.success('Marks saved.');
      const { data } = await examService.getResults(resultsModal._id);
      setResults(data.data);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save marks.');
    }
  };

  const handlePublish = async () => {
    await examService.publish(resultsModal._id);
    toast.success('Results published. Students/parents can now view them.');
    load();
  };

  const handleLock = async () => {
    await examService.lock(resultsModal._id);
    toast.success('Results locked. No further edits allowed.');
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Exams & Results</h1>
          <p className="text-sm text-ink-400">Create exams, enter marks, and publish report cards.</p>
        </div>
        <button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> New Exam</button>
      </div>

      <div className="card overflow-hidden">
        <table className="table-base">
          <thead><tr><th>Name</th><th>Class</th><th>Status</th><th className="text-right">Actions</th></tr></thead>
          <tbody>
            {exams.length === 0 ? (
              <tr><td colSpan={4} className="py-8 text-center text-ink-400">No exams created yet.</td></tr>
            ) : exams.map((ex) => (
              <tr key={ex._id}>
                <td>{ex.name}</td>
                <td>{ex.class?.name}</td>
                <td>
                  {ex.resultLocked ? 'Locked' : ex.resultPublished ? 'Published' : 'Draft'}
                </td>
                <td className="text-right">
                  <button className="btn-outline px-3 py-1" onClick={() => openResults(ex)}>
                    <IoDocumentTextOutline /> Marks & Results
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="New Exam" size="lg">
        <form onSubmit={handleCreate} className="space-y-4">
          <TextField label="Exam Name (e.g. Mid-Term 2026)" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <div className="grid grid-cols-2 gap-4">
            <SelectField label="Class" required value={form.class} onChange={(e) => setForm({ ...form, class: e.target.value })}
              options={classes.map((c) => ({ value: c._id, label: c.name }))} />
            <SelectField label="Academic Session" required value={form.academicSession} onChange={(e) => setForm({ ...form, academicSession: e.target.value })}
              options={sessions.map((s) => ({ value: s._id, label: s.name }))} />
          </div>
          <div>
            <p className="label">Subjects included</p>
            <div className="flex flex-wrap gap-2">
              {subjects.filter((s) => !form.class || s.class?._id === form.class).map((s) => (
                <button
                  type="button"
                  key={s._id}
                  onClick={() => toggleSubject(s._id)}
                  className={`rounded-md px-3 py-1.5 text-sm ${form.subjects.find((fs) => fs.subject === s._id) ? 'bg-brass-400 text-ink-900' : 'bg-ink-50 text-ink-600 hover:bg-ink-100'}`}
                >
                  {s.name}
                </button>
              ))}
            </div>
          </div>
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass">Create Exam</button>
          </div>
        </form>
      </Modal>

      {resultsModal && (
        <Modal isOpen onClose={() => setResultsModal(null)} title={`${resultsModal.name} — Marks & Results`} size="xl">
          <div className="mb-4 flex justify-end gap-2">
            <button className="btn-outline" onClick={handlePublish} disabled={resultsModal.resultLocked}>
              <IoCheckmarkCircleOutline /> Publish Results
            </button>
            <button className="btn-danger" onClick={handleLock} disabled={resultsModal.resultLocked}>
              <IoLockClosedOutline /> Lock Results
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Student</th>
                  {resultsModal.subjects.map((s) => (
                    <th key={s.subject?._id || s.subject}>{s.subject?.name || 'Subject'}</th>
                  ))}
                  <th>Total</th>
                  <th>Grade</th>
                  <th>Rank</th>
                  <th>Report</th>
                </tr>
              </thead>
              <tbody>
                {students.map((student) => (
                  <ResultRow
                    key={student._id}
                    student={student}
                    exam={resultsModal}
                    existingResult={results.find((r) => r.student._id === student._id)}
                    onSave={(marks) => handleMarksSave(student._id, marks)}
                  />
                ))}
              </tbody>
            </table>
          </div>
        </Modal>
      )}
    </div>
  );
}

function exam2marks(exam, marksBySubject) {
  return exam.subjects.map((s) => ({
    subject: s.subject?._id || s.subject,
    marksObtained: Number(marksBySubject[s.subject?._id || s.subject] || 0),
    fullMarks: s.fullMarks,
    passMarks: s.passMarks,
  }));
}

function ResultRow({ student, exam, existingResult, onSave }) {
  const [marksBySubject, setMarksBySubject] = useState(() => {
    const map = {};
    existingResult?.marks?.forEach((m) => { map[m.subject?._id || m.subject] = m.marksObtained; });
    return map;
  });

  const token = getAccessToken();
  const reportUrl = `${API_URL}${examService.reportCardUrl(exam._id, student._id)}`;

  return (
    <tr>
      <td>{student.firstName} {student.lastName}</td>
      {exam.subjects.map((s) => {
        const subjectId = s.subject?._id || s.subject;
        return (
          <td key={subjectId}>
            <input
              type="number"
              className="input w-20 py-1"
              value={marksBySubject[subjectId] ?? ''}
              onChange={(e) => setMarksBySubject({ ...marksBySubject, [subjectId]: e.target.value })}
            />
          </td>
        );
      })}
      <td>{existingResult ? `${existingResult.totalObtained}/${existingResult.totalFullMarks}` : '—'}</td>
      <td>{existingResult?.grade || '—'}</td>
      <td>{existingResult?.rank || '—'}</td>
      <td className="flex gap-2">
        <button className="btn-outline px-2 py-1 text-xs" onClick={() => onSave(marksBySubject)}>Save</button>
        {existingResult && (
          <a
            className="btn-outline px-2 py-1 text-xs"
            href={reportUrl}
            onClick={(e) => {
              // Report-card PDF requires the Authorization header, which a
              // plain <a> can't send — fetch as blob and open instead.
              e.preventDefault();
              fetch(reportUrl, { headers: { Authorization: `Bearer ${token}` } })
                .then((r) => r.blob())
                .then((blob) => window.open(window.URL.createObjectURL(blob)));
            }}
          >
            PDF
          </a>
        )}
      </td>
    </tr>
  );
}
