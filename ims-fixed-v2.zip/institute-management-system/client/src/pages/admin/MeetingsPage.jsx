import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoCalendarOutline, IoCloseCircleOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import Modal from '../../components/ui/Modal';
import EmptyState from '../../components/ui/EmptyState';
import { TextField, SelectField } from '../../components/forms/FormFields';
import { meetingService } from '../../services/engagementServices';
import { teacherService } from '../../services/resourceServices';
import { useAuth } from '../../context/AuthContext';

// Used by teachers/admins (create + manage slots) and by parents/students
// (book an open slot) — the same page adapts based on role.
export default function MeetingsPage() {
  const { user } = useAuth();
  const canCreate = ['teacher', 'admin', 'principal'].includes(user?.role);
  const canBook = ['parent', 'student'].includes(user?.role);

  const [slots, setSlots] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({ teacher: '', startTime: '', endTime: '' });

  const load = useCallback(async () => {
    const params = canCreate ? {} : { status: 'open' };
    const { data } = await meetingService.list(params);
    setSlots(data.data);
  }, [canCreate]);

  useEffect(() => {
    load();
    if (canCreate) teacherService.list({ limit: 100 }).then(({ data }) => setTeachers(data.data));
  }, [load, canCreate]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await meetingService.create(form);
      toast.success('Meeting slot opened.');
      setModalOpen(false);
      setForm({ teacher: '', startTime: '', endTime: '' });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create slot.');
    }
  };

  const handleBook = async (id) => {
    try {
      await meetingService.book(id, {});
      toast.success('Meeting booked.');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to book slot.');
    }
  };

  const handleCancel = async (id) => {
    await meetingService.cancel(id);
    toast.success('Slot cancelled.');
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Parent-Teacher Meetings</h1>
          <p className="text-sm text-ink-400">{canCreate ? 'Open time slots for parents to book.' : 'Book an available meeting slot with a teacher.'}</p>
        </div>
        {canCreate && <button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> Open Slot</button>}
      </div>

      {slots.length === 0 ? (
        <EmptyState title="No slots available" />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {slots.map((s) => (
            <div key={s._id} className="card p-4">
              <div className="mb-2 flex items-center gap-2">
                <IoCalendarOutline className="text-brass-500" />
                <p className="text-sm font-medium text-ink-700">{s.teacher?.firstName} {s.teacher?.lastName}</p>
              </div>
              <p className="text-xs text-ink-400">{new Date(s.startTime).toLocaleString()} – {new Date(s.endTime).toLocaleTimeString()}</p>
              <p className="mt-1 text-xs">
                <span className={`rounded-full px-2 py-0.5 ${s.status === 'open' ? 'bg-brass-50 text-brass-700' : s.status === 'booked' ? 'bg-ink-100 text-ink-500' : 'bg-red-50 text-red-600'}`}>{s.status}</span>
              </p>
              {canBook && s.status === 'open' && (
                <button className="btn-brass mt-3 w-full" onClick={() => handleBook(s._id)}>Book This Slot</button>
              )}
              {canCreate && s.status !== 'cancelled' && (
                <button className="btn-outline mt-3 w-full text-red-600" onClick={() => handleCancel(s._id)}><IoCloseCircleOutline /> Cancel</button>
              )}
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Open Meeting Slot">
        <form onSubmit={handleCreate} className="space-y-4">
          <SelectField label="Teacher" required value={form.teacher} onChange={(e) => setForm({ ...form, teacher: e.target.value })}
            options={teachers.map((t) => ({ value: t._id, label: `${t.firstName} ${t.lastName || ''}` }))} />
          <TextField label="Start Time" type="datetime-local" required value={form.startTime} onChange={(e) => setForm({ ...form, startTime: e.target.value })} />
          <TextField label="End Time" type="datetime-local" required value={form.endTime} onChange={(e) => setForm({ ...form, endTime: e.target.value })} />
          <div className="flex justify-end gap-3"><button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button><button className="btn-brass">Open Slot</button></div>
        </form>
      </Modal>
    </div>
  );
}
