import { useEffect, useState } from 'react';
import api from '../../services/api';
import { attendanceService, examService, feeService, settingsService } from '../../services/resourceServices';
import { openPdf } from '../../utils/openPdf';
import ResultCard from '../../components/results/ResultCard';
import EmptyState from '../../components/ui/EmptyState';
import FullPageLoader from '../../components/ui/FullPageLoader';
import StatCard from '../../components/ui/StatCard';

// Shared helper: parents may have more than one child, so every parent page
// loads the linked children first and defaults to the first one.
function useFirstChild() {
  const [child, setChild] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/students', { params: { limit: 50 } })
      .then(({ data }) => setChild(data.data[0] || null))
      .finally(() => setLoading(false));
  }, []);

  return { child, loading };
}

export function ParentAttendancePage() {
  const { child, loading } = useFirstChild();
  const [records, setRecords] = useState(null);
  const [summary, setSummary] = useState(null);

  useEffect(() => {
    if (!child) return;
    attendanceService.getForStudent(child._id).then(({ data }) => {
      setRecords(data.data.records);
      setSummary(data.data.summary);
    });
  }, [child]);

  if (loading) return <FullPageLoader />;
  if (!child) return <EmptyState title="No linked children found" />;
  if (!records) return <FullPageLoader />;

  return (
    <div className="space-y-6">
      <h1 className="font-display text-2xl text-ink-800">{child.firstName}'s Attendance</h1>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard label="Attendance Rate" value={`${summary.percentage}%`} accent />
        <StatCard label="Days Present" value={summary.present} />
        <StatCard label="Total Recorded Days" value={summary.total} />
      </div>
      <div className="card overflow-hidden">
        <table className="table-base">
          <thead><tr><th>Date</th><th>Status</th></tr></thead>
          <tbody>
            {records.map((r) => (
              <tr key={r._id}><td>{new Date(r.date).toLocaleDateString()}</td><td className="capitalize">{r.status}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function ParentResultsPage() {
  const { child, loading } = useFirstChild();
  const [exams, setExams] = useState(null);
  const [results, setResults] = useState({});
  const [gradingScale, setGradingScale] = useState([]);

  useEffect(() => {
    settingsService.get().then(({ data }) => setGradingScale(data.data.gradingScale || []));
  }, []);

  useEffect(() => {
    if (!child) return;
    examService.list({ class: child.class._id }).then(async ({ data }) => {
      const published = data.data.filter((e) => e.resultPublished);
      setExams(published);
      const map = {};
      await Promise.all(published.map(async (exam) => {
        const { data: r } = await examService.getResults(exam._id);
        map[exam._id] = r.data.find((res) => res.student._id === child._id);
      }));
      setResults(map);
    });
  }, [child]);

  const downloadPdf = (examId) => {
    openPdf(examService.reportCardUrl(examId, child._id));
  };

  if (loading) return <FullPageLoader />;
  if (!child) return <EmptyState title="No linked children found" />;
  if (!exams) return <FullPageLoader />;

  return (
    <div className="space-y-6">
      <h1 className="font-display text-2xl text-ink-800">{child.firstName}'s Results</h1>
      {exams.length === 0 ? (
        <EmptyState title="No published results yet" />
      ) : (
        <div className="space-y-6">
          {exams.map((exam) => (
            <ResultCard
              key={exam._id}
              exam={exam}
              result={results[exam._id]}
              student={child}
              gradingScale={gradingScale}
              onDownload={results[exam._id] ? () => downloadPdf(exam._id) : undefined}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function ParentFeesPage() {
  const { child, loading } = useFirstChild();
  const [fees, setFees] = useState(null);

  useEffect(() => {
    if (!child) return;
    feeService.list({ student: child._id }).then(({ data }) => setFees(data.data));
  }, [child]);

  if (loading) return <FullPageLoader />;
  if (!child) return <EmptyState title="No linked children found" />;
  if (!fees) return <FullPageLoader />;

  return (
    <div className="space-y-6">
      <h1 className="font-display text-2xl text-ink-800">{child.firstName}'s Fees</h1>
      <div className="card overflow-hidden">
        <table className="table-base">
          <thead><tr><th>Title</th><th>Amount</th><th>Paid</th><th>Due</th><th>Status</th></tr></thead>
          <tbody>
            {fees.length === 0 ? (
              <tr><td colSpan={5} className="py-8 text-center text-ink-400">No fee invoices yet.</td></tr>
            ) : fees.map((f) => (
              <tr key={f._id}><td>{f.title}</td><td>{f.amount}</td><td>{f.amountPaid}</td><td>{f.amountDue}</td><td className="capitalize">{f.status}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
