import { useEffect, useState } from 'react';
import { feeService, dashboardService } from '../../services/resourceServices';
import { getAccessToken } from '../../services/api';
import EmptyState from '../../components/ui/EmptyState';
import FullPageLoader from '../../components/ui/FullPageLoader';

const API_URL = import.meta.env.VITE_API_URL || '/api';

export default function StudentFeesPage() {
  const [fees, setFees] = useState(null);
  const [payments, setPayments] = useState([]);

  useEffect(() => {
    const load = async () => {
      const { data: dash } = await dashboardService.student();
      const student = dash.data.student;
      if (!student) { setFees([]); return; }
      const [feesRes, paymentsRes] = await Promise.all([
        feeService.list({ student: student._id }),
        feeService.listPayments({ student: student._id }),
      ]);
      setFees(feesRes.data.data);
      setPayments(paymentsRes.data.data);
    };
    load();
  }, []);

  const downloadReceipt = async (paymentId) => {
    const token = getAccessToken();
    const res = await fetch(`${API_URL}${feeService.receiptUrl(paymentId)}`, { headers: { Authorization: `Bearer ${token}` } });
    const blob = await res.blob();
    window.open(window.URL.createObjectURL(blob));
  };

  if (!fees) return <FullPageLoader />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">My Fees</h1>
        <p className="text-sm text-ink-400">Fee invoices, dues, and payment history.</p>
      </div>

      <div className="card overflow-hidden">
        <table className="table-base">
          <thead><tr><th>Title</th><th>Amount</th><th>Paid</th><th>Due</th><th>Status</th></tr></thead>
          <tbody>
            {fees.length === 0 ? (
              <tr><td colSpan={5} className="py-8 text-center text-ink-400">No fee invoices yet.</td></tr>
            ) : fees.map((f) => (
              <tr key={f._id}>
                <td>{f.title}</td>
                <td>{f.amount}</td>
                <td>{f.amountPaid}</td>
                <td>{f.amountDue}</td>
                <td className="capitalize">{f.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div>
        <h3 className="mb-3 font-display text-base text-ink-700">Payment History</h3>
        {payments.length === 0 ? (
          <EmptyState title="No payments recorded yet" />
        ) : (
          <div className="space-y-2">
            {payments.map((p) => (
              <div key={p._id} className="card flex items-center justify-between p-4 text-sm">
                <div>
                  <p className="font-medium text-ink-700">{p.fee?.title}</p>
                  <p className="text-ink-400">{new Date(p.paidAt).toLocaleDateString()} · {p.method}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-medium">{p.amount}</span>
                  <button className="btn-outline px-3 py-1 text-xs" onClick={() => downloadReceipt(p._id)}>Receipt</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
