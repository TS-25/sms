import { useEffect, useState } from 'react';
import { examService, dashboardService, settingsService } from '../../services/resourceServices';
import { openPdf } from '../../utils/openPdf';
import ResultCard from '../../components/results/ResultCard';
import EmptyState from '../../components/ui/EmptyState';
import FullPageLoader from '../../components/ui/FullPageLoader';

export default function StudentResultsPage() {
  const [exams, setExams] = useState(null);
  const [studentId, setStudentId] = useState(null);
  const [studentInfo, setStudentInfo] = useState(null);
  const [results, setResults] = useState({});
  const [gradingScale, setGradingScale] = useState([]);

  useEffect(() => {
    const load = async () => {
      const [{ data: dash }, { data: settings }] = await Promise.all([
        dashboardService.student(),
        settingsService.get(),
      ]);
      setGradingScale(settings.data.gradingScale || []);

      const student = dash.data.student;
      if (!student) { setExams([]); return; }
      setStudentId(student._id);
      setStudentInfo(student);

      const { data: examList } = await examService.list({ class: student.class._id });
      const published = examList.data.filter((e) => e.resultPublished);
      setExams(published);

      const resultsMap = {};
      await Promise.all(published.map(async (exam) => {
        const { data: r } = await examService.getResults(exam._id);
        resultsMap[exam._id] = r.data.find((res) => res.student._id === student._id);
      }));
      setResults(resultsMap);
    };
    load();
  }, []);

  const downloadPdf = (examId) => {
    openPdf(examService.reportCardUrl(examId, studentId));
  };

  if (!exams) return <FullPageLoader />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">My Results</h1>
        <p className="text-sm text-ink-400">Published exam results and downloadable report cards.</p>
      </div>

      {exams.length === 0 ? (
        <EmptyState title="No published results yet" description="Results will appear here once your school publishes them." />
      ) : (
        <div className="space-y-6">
          {exams.map((exam) => (
            <ResultCard
              key={exam._id}
              exam={exam}
              result={results[exam._id]}
              student={studentInfo}
              gradingScale={gradingScale}
              onDownload={results[exam._id] ? () => downloadPdf(exam._id) : undefined}
            />
          ))}
        </div>
      )}
    </div>
  );
}
