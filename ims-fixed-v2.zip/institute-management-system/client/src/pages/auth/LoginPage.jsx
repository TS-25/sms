import { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { IoSchoolOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';
import { roleHomePath } from '../../utils/roleHomePath';
import { settingsService } from '../../services/resourceServices';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [branding, setBranding] = useState({ schoolName: 'School', logoUrl: '' });
  const [needsTotp, setNeedsTotp] = useState(false);
  const [totpCode, setTotpCode] = useState('');

  useEffect(() => {
    settingsService.getPublic()
      .then(({ data }) => setBranding(data.data))
      .catch(() => {
        // Non-critical — keep the generic fallback name if this fails
        // (e.g. API briefly unreachable before login).
      });
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const result = await login(form.email, form.password, needsTotp ? totpCode : undefined);
      if (result.twoFactorRequired) {
        setNeedsTotp(true);
        setLoading(false);
        return;
      }
      const from = location.state?.from?.pathname;
      navigate(from || roleHomePath(result.role), { replace: true });
    } catch (err) {
      if (err.response) {
        // The server responded with an actual error (e.g. 401 wrong
        // password, 403 deactivated account) — show its message.
        toast.error(err.response.data?.message || 'Login failed. Please check your credentials.');
      } else if (err.request) {
        // The request was sent but never got a response — the API is
        // unreachable (down, crashed, wrong URL, or blocked by CORS).
        // This is NOT a wrong-password situation, so don't say "check your
        // credentials" here — it sends people down the wrong debugging path.
        toast.error("Can't reach the server. Check that the API is running and VITE_API_URL is correct.");
      } else {
        toast.error('Something went wrong. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-ink-800 px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center text-cream">
          {branding.logoUrl ? (
            <img src={branding.logoUrl} alt="" className="h-10 w-10 rounded object-cover" />
          ) : (
            <IoSchoolOutline className="text-brass-400" size={36} />
          )}
          <h1 className="mt-3 font-display text-2xl">{branding.schoolName}</h1>
          <p className="text-sm text-ink-300">Institute Management System</p>
        </div>

        <form onSubmit={handleSubmit} className="card p-6">
          <h2 className="mb-1 font-display text-xl text-ink-800">Sign in</h2>
          <p className="mb-6 text-sm text-ink-400">
            {needsTotp ? 'Enter the 6-digit code from your authenticator app.' : 'Enter your credentials to access your dashboard.'}
          </p>

          {!needsTotp ? (
            <>
              <div className="mb-4">
                <label className="label" htmlFor="email">Email</label>
                <input
                  id="email"
                  type="email"
                  required
                  className="input"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="you@school.com"
                />
              </div>

              <div className="mb-2">
                <label className="label" htmlFor="password">Password</label>
                <input
                  id="password"
                  type="password"
                  required
                  className="input"
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  placeholder="••••••••"
                />
              </div>

              <div className="mb-6 text-right">
                <Link to="/forgot-password" className="text-xs text-brass-600 hover:underline">
                  Forgot password?
                </Link>
              </div>
            </>
          ) : (
            <div className="mb-6">
              <label className="label" htmlFor="totp">Authentication Code</label>
              <input
                id="totp"
                type="text"
                required
                autoFocus
                className="input"
                value={totpCode}
                onChange={(e) => setTotpCode(e.target.value)}
                placeholder="123456"
              />
              <button type="button" className="mt-2 text-xs text-brass-600 hover:underline" onClick={() => { setNeedsTotp(false); setTotpCode(''); }}>
                Back to password
              </button>
            </div>
          )}

          <button type="submit" className="btn-primary w-full" disabled={loading}>
            {loading ? 'Signing in…' : needsTotp ? 'Verify' : 'Sign in'}
          </button>
        </form>
      </div>
    </div>
  );
}
