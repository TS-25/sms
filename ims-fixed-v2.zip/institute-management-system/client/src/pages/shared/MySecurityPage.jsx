import { useEffect, useState } from 'react';
import { IoShieldCheckmarkOutline, IoDesktopOutline, IoTrashOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import api from '../../services/api';
import Modal from '../../components/ui/Modal';
import { TextField } from '../../components/forms/FormFields';
import { useAuth } from '../../context/AuthContext';

const securityApi = {
  setup2FA: () => api.post('/auth/2fa/setup'),
  verify2FA: (totpCode) => api.post('/auth/2fa/verify', { totpCode }),
  disable2FA: (password) => api.post('/auth/2fa/disable', { password }),
  sessions: () => api.get('/sessions'),
  revokeSession: (id) => api.delete(`/sessions/${id}`),
  revokeAllOther: () => api.delete('/sessions'),
};

export default function MySecurityPage() {
  const { user, setUser } = useAuth();
  const [sessions, setSessions] = useState([]);
  const [setupData, setSetupData] = useState(null);
  const [setupModalOpen, setSetupModalOpen] = useState(false);
  const [totpCode, setTotpCode] = useState('');
  const [recoveryCodes, setRecoveryCodes] = useState(null);
  const [disableModalOpen, setDisableModalOpen] = useState(false);
  const [disablePassword, setDisablePassword] = useState('');

  const loadSessions = () => securityApi.sessions().then(({ data }) => setSessions(data.data));

  useEffect(() => { loadSessions(); }, []);

  const handleStartSetup = async () => {
    const { data } = await securityApi.setup2FA();
    setSetupData(data.data);
    setSetupModalOpen(true);
  };

  const handleVerify = async (e) => {
    e.preventDefault();
    try {
      const { data } = await securityApi.verify2FA(totpCode);
      setRecoveryCodes(data.data.recoveryCodes);
      setUser({ ...user, twoFactorEnabled: true });
      toast.success('Two-factor authentication enabled.');
      setTotpCode('');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Invalid code.');
    }
  };

  const handleDisable = async (e) => {
    e.preventDefault();
    try {
      await securityApi.disable2FA(disablePassword);
      setUser({ ...user, twoFactorEnabled: false });
      toast.success('Two-factor authentication disabled.');
      setDisableModalOpen(false);
      setDisablePassword('');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Incorrect password.');
    }
  };

  const handleRevoke = async (id) => {
    await securityApi.revokeSession(id);
    toast.success('Session revoked.');
    loadSessions();
  };

  const handleRevokeAllOther = async () => {
    await securityApi.revokeAllOther();
    toast.success('All other sessions have been logged out.');
    loadSessions();
  };

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Security</h1>
        <p className="text-sm text-ink-400">Two-factor authentication and active sessions for your account.</p>
      </div>

      <div className="card p-6">
        <div className="mb-1 flex items-center gap-2">
          <IoShieldCheckmarkOutline className="text-brass-500" />
          <h2 className="font-display text-lg text-ink-800">Two-Factor Authentication</h2>
        </div>
        <p className="mb-4 text-sm text-ink-400">
          {user?.twoFactorEnabled ? 'Enabled — you\'ll be asked for a code from your authenticator app at login.' : 'Add an extra layer of security using an authenticator app (Google Authenticator, Authy, etc).'}
        </p>
        {user?.twoFactorEnabled ? (
          <button className="btn-outline text-red-600" onClick={() => setDisableModalOpen(true)}>Disable 2FA</button>
        ) : (
          <button className="btn-brass" onClick={handleStartSetup}>Enable 2FA</button>
        )}
      </div>

      <div className="card p-6">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <IoDesktopOutline className="text-brass-500" />
            <h2 className="font-display text-lg text-ink-800">Active Sessions</h2>
          </div>
          <button className="btn-outline text-xs" onClick={handleRevokeAllOther}>Log out other devices</button>
        </div>
        <div className="space-y-2">
          {sessions.map((s) => (
            <div key={s._id} className="flex items-center justify-between rounded-md border border-ink-100 px-4 py-3">
              <div>
                <p className="text-sm font-medium text-ink-700">{s.device} · {s.browser} {s.isCurrent && <span className="text-brass-600">(this device)</span>}</p>
                <p className="text-xs text-ink-400">Last active {new Date(s.lastActiveAt).toLocaleString()} · {s.ip}</p>
              </div>
              {!s.isCurrent && (
                <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => handleRevoke(s._id)}><IoTrashOutline /></button>
              )}
            </div>
          ))}
        </div>
      </div>

      <Modal isOpen={setupModalOpen} onClose={() => { setSetupModalOpen(false); setRecoveryCodes(null); }} title="Set Up Two-Factor Authentication">
        {!recoveryCodes ? (
          <div className="space-y-4">
            <p className="text-sm text-ink-500">Scan this into your authenticator app, or enter the secret manually:</p>
            <div className="rounded-md bg-ink-50 p-3 text-center">
              <p className="break-all font-mono text-sm">{setupData?.secret}</p>
            </div>
            <form onSubmit={handleVerify} className="space-y-3">
              <TextField label="Enter the 6-digit code from your app" required value={totpCode} onChange={(e) => setTotpCode(e.target.value)} />
              <button className="btn-brass w-full">Verify & Enable</button>
            </form>
          </div>
        ) : (
          <div className="space-y-4">
            <p className="text-sm text-ink-600">Save these recovery codes somewhere safe — each can be used once if you lose access to your authenticator app.</p>
            <div className="grid grid-cols-2 gap-2 rounded-md bg-ink-50 p-3 font-mono text-sm">
              {recoveryCodes.map((c) => <span key={c}>{c}</span>)}
            </div>
            <button className="btn-brass w-full" onClick={() => { setSetupModalOpen(false); setRecoveryCodes(null); }}>Done</button>
          </div>
        )}
      </Modal>

      <Modal isOpen={disableModalOpen} onClose={() => setDisableModalOpen(false)} title="Disable Two-Factor Authentication">
        <form onSubmit={handleDisable} className="space-y-4">
          <TextField label="Confirm your password" type="password" required value={disablePassword} onChange={(e) => setDisablePassword(e.target.value)} />
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setDisableModalOpen(false)}>Cancel</button>
            <button className="btn-danger">Disable 2FA</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
