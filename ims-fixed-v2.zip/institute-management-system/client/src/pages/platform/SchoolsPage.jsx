import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoBusinessOutline, IoCheckmarkCircle, IoCloseCircle, IoSettingsOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import EmptyState from '../../components/ui/EmptyState';
import StatCard from '../../components/ui/StatCard';
import { TextField } from '../../components/forms/FormFields';
import { platformService } from '../../services/resourceServices';

const MODULE_LABELS = {
  library: 'Library',
  transport: 'Transport',
  hostel: 'Hostel',
  onlineExams: 'Online Exams',
  onlinePayments: 'Online Payments',
  chat: 'Internal Chat',
  publicWebsite: 'Public Website',
};

const emptyForm = {
  name: '', slug: '', address: '', phone: '', email: '', website: '',
  adminName: '', adminEmail: '', adminPassword: '',
};

export default function SchoolsPage() {
  const [schools, setSchools] = useState(null);
  const [stats, setStats] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [modulesTarget, setModulesTarget] = useState(null);
  const [statusTarget, setStatusTarget] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    const [schoolsRes, statsRes] = await Promise.all([platformService.schools.list(), platformService.stats()]);
    setSchools(schoolsRes.data.data);
    setStats(statsRes.data.data);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await platformService.schools.create(form);
      toast.success(`${form.name} created.`);
      setModalOpen(false);
      setForm(emptyForm);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create institute.');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleStatus = async () => {
    try {
      await platformService.schools.setStatus(statusTarget._id, !statusTarget.isActive);
      toast.success(`${statusTarget.name} ${statusTarget.isActive ? 'deactivated' : 'activated'}.`);
      setStatusTarget(null);
      load();
    } catch (err) {
      toast.error('Failed to update institute status.');
    }
  };

  const handleToggleModule = async (moduleName, value) => {
    try {
      const { data } = await platformService.schools.updateModules(modulesTarget._id, { [moduleName]: value });
      setModulesTarget(data.data);
      load();
    } catch (err) {
      toast.error('Failed to update module.');
    }
  };

  if (!schools) return <div className="text-ink-400">Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Platform — Institutes</h1>
          <p className="text-sm text-ink-400">Manage every institute (tenant) on this installation.</p>
        </div>
        <button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> New Institute</button>
      </div>

      {stats && (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <StatCard label="Total Institutes" value={stats.totalSchools} />
          <StatCard label="Active Institutes" value={stats.activeSchools} accent />
          <StatCard label="Inactive Institutes" value={stats.inactiveSchools} />
          <StatCard label="Total Users (all institutes)" value={stats.totalUsers} />
        </div>
      )}

      {schools.length === 0 ? (
        <EmptyState
          title="No institutes yet"
          description="Create your first institute to get started."
          action={<button className="btn-brass" onClick={() => setModalOpen(true)}><IoBusinessOutline /> Create an institute</button>}
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {schools.map((s) => (
            <div key={s._id} className="card p-5">
              <div className="mb-2 flex items-start justify-between gap-2">
                <div>
                  <p className="font-display text-lg text-ink-800">{s.name}</p>
                  <p className="text-xs text-ink-400">/{s.slug} · {s.plan} plan · {s.userCount} user(s)</p>
                </div>
                <span className={`shrink-0 rounded-full px-2.5 py-1 text-xs ${s.isActive ? 'bg-brass-50 text-brass-700' : 'bg-red-50 text-red-600'}`}>
                  {s.isActive ? 'Active' : 'Inactive'}
                </span>
              </div>
              {s.address && <p className="text-sm text-ink-500">{s.address}</p>}
              <div className="mt-4 flex gap-2">
                <button className="btn-outline flex-1 px-2 py-1.5 text-xs" onClick={() => setModulesTarget(s)}>
                  <IoSettingsOutline /> Modules
                </button>
                <button
                  className={`btn-outline flex-1 px-2 py-1.5 text-xs ${s.isActive ? 'text-red-600' : 'text-green-700'}`}
                  onClick={() => setStatusTarget(s)}
                >
                  {s.isActive ? <IoCloseCircle /> : <IoCheckmarkCircle />}
                  {s.isActive ? 'Deactivate' : 'Activate'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Create New Institute" size="lg">
        <form onSubmit={handleCreate} className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <TextField label="Institute Name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <TextField label="Slug (URL-safe, e.g. greenwood)" required value={form.slug}
              onChange={(e) => setForm({ ...form, slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '-') })} />
          </div>
          <TextField label="Address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <TextField label="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            <TextField label="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>

          <div className="border-t border-ink-100 pt-4">
            <p className="mb-3 text-sm font-medium text-ink-600">First Admin Account for this Institute</p>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <TextField label="Admin Name" required value={form.adminName} onChange={(e) => setForm({ ...form, adminName: e.target.value })} />
              <TextField label="Admin Email" type="email" required value={form.adminEmail} onChange={(e) => setForm({ ...form, adminEmail: e.target.value })} />
            </div>
            <div className="mt-4">
              <TextField label="Admin Password" type="password" required minLength={6} value={form.adminPassword} onChange={(e) => setForm({ ...form, adminPassword: e.target.value })} />
            </div>
          </div>

          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass" disabled={saving}>{saving ? 'Creating…' : 'Create Institute'}</button>
          </div>
        </form>
      </Modal>

      {modulesTarget && (
        <Modal isOpen onClose={() => setModulesTarget(null)} title={`${modulesTarget.name} — Modules`}>
          <p className="mb-4 text-sm text-ink-400">
            Disabled modules disappear from this institute's menu and are blocked on the backend too.
          </p>
          <div className="space-y-2">
            {Object.entries(MODULE_LABELS).map(([key, label]) => (
              <label key={key} className="flex items-center justify-between rounded-md border border-ink-100 px-4 py-3">
                <span className="text-sm text-ink-700">{label}</span>
                <input
                  type="checkbox"
                  checked={modulesTarget.enabledModules?.[key] ?? true}
                  onChange={(e) => handleToggleModule(key, e.target.checked)}
                  className="h-4 w-4"
                />
              </label>
            ))}
          </div>
          <div className="mt-4 flex justify-end">
            <button className="btn-outline" onClick={() => setModulesTarget(null)}>Done</button>
          </div>
        </Modal>
      )}

      <ConfirmDialog
        isOpen={!!statusTarget}
        onClose={() => setStatusTarget(null)}
        onConfirm={handleToggleStatus}
        title={statusTarget?.isActive ? 'Deactivate institute?' : 'Activate institute?'}
        message={
          statusTarget?.isActive
            ? `Everyone at ${statusTarget?.name} will be locked out until it's reactivated.`
            : `${statusTarget?.name} will regain access immediately.`
        }
        danger={!!statusTarget?.isActive}
      />
    </div>
  );
}
