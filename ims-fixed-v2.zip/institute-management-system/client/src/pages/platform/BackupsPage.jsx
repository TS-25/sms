import { useEffect, useState } from 'react';
import { IoCloudUploadOutline, IoDownloadOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import api from '../../services/api';
import EmptyState from '../../components/ui/EmptyState';
import { openPdf } from '../../utils/openPdf';

const backupService = {
  list: () => api.get('/platform/backups'),
  trigger: () => api.post('/platform/backups'),
  downloadUrl: (id) => `/platform/backups/${id}/download`,
};

export default function BackupsPage() {
  const [backups, setBackups] = useState(null);
  const [running, setRunning] = useState(false);

  const load = () => backupService.list().then(({ data }) => setBackups(data.data));

  useEffect(() => { load(); }, []);

  const handleTrigger = async () => {
    setRunning(true);
    try {
      await backupService.trigger();
      toast.success('Backup completed.');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Backup failed. Check that mongodump is installed on the server.');
    } finally {
      setRunning(false);
    }
  };

  const handleDownload = (id) => {
    openPdf(backupService.downloadUrl(id)).catch(() => toast.error('Failed to download backup.'));
  };

  if (!backups) return <div className="text-ink-400">Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Database Backups</h1>
          <p className="text-sm text-ink-400">Trigger and download full-instance backups. Requires MongoDB Database Tools on the server.</p>
        </div>
        <button className="btn-brass" onClick={handleTrigger} disabled={running}>
          <IoCloudUploadOutline /> {running ? 'Running…' : 'Run Backup Now'}
        </button>
      </div>

      {backups.length === 0 ? (
        <EmptyState title="No backups yet" description="Run your first backup above." />
      ) : (
        <div className="card overflow-hidden">
          <table className="table-base">
            <thead><tr><th>Date</th><th>Status</th><th>Size</th><th className="text-right">Actions</th></tr></thead>
            <tbody>
              {backups.map((b) => (
                <tr key={b._id}>
                  <td>{new Date(b.createdAt).toLocaleString()}</td>
                  <td className="capitalize">{b.status}</td>
                  <td>{b.fileSizeBytes ? `${(b.fileSizeBytes / 1024 / 1024).toFixed(1)} MB` : '—'}</td>
                  <td className="text-right">
                    {b.status === 'completed' && (
                      <button className="btn-outline px-2 py-1 text-xs" onClick={() => handleDownload(b._id)}><IoDownloadOutline /> Download</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
