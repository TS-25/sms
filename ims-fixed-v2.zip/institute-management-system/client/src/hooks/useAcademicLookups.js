import { useCallback, useEffect, useState } from 'react';
import { academicService } from '../services/resourceServices';

export function useAcademicLookups() {
  const [sessions, setSessions] = useState([]);
  const [classes, setClasses] = useState([]);
  const [sections, setSections] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [s, c, sec, subj] = await Promise.all([
        academicService.sessions.list(),
        academicService.classes.list(),
        academicService.sections.list(),
        academicService.subjects.list(),
      ]);
      setSessions(s.data.data);
      setClasses(c.data.data);
      setSections(sec.data.data);
      setSubjects(subj.data.data);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    let active = true;
    load().catch(() => {
      if (active) setLoading(false);
    });
    return () => { active = false; };
  }, [load]);

  const sectionsForClass = useCallback(
    (classId) => sections.filter((s) => s.class?._id === classId || s.class === classId),
    [sections]
  );

  return { sessions, classes, sections, subjects, sectionsForClass, loading, refresh: load };
}
