// Determines which dashboard route a user should land on after login,
// based on their role. Keeps this logic in one place.
export function roleHomePath(role) {
  switch (role) {
    case 'super_admin':
      // Platform-level role — manages schools/tenants, not any single
      // school's day-to-day data. See SchoolsPage.jsx.
      return '/platform';
    case 'admin':
    case 'principal':
    case 'accountant':
    case 'receptionist':
      return '/admin';
    case 'teacher':
      return '/teacher';
    case 'student':
      return '/student';
    case 'parent':
      return '/parent';
    default:
      return '/staff';
  }
}
