# API Documentation

Base URL: `{API_URL}` (e.g. `http://localhost:5000/api` in development)

All authenticated requests must include:
```
Authorization: Bearer <accessToken>
```

The refresh token is stored in an httpOnly cookie and is never exposed to
JavaScript. Access tokens expire quickly (default 15 minutes); the frontend
automatically calls `/auth/refresh` when it receives a 401.

All responses follow the shape:
```json
{ "success": true, "data": { ... } }
```
or on error:
```json
{ "success": false, "message": "Human readable error", "details": [ ... ] }
```

---

## Auth

| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/auth/login` | Public | `{ email, password }` → `{ user, accessToken }` |
| POST | `/auth/refresh` | Public (cookie) | Returns a new access token |
| POST | `/auth/logout` | Public | Clears refresh cookie |
| GET | `/auth/me` | Authenticated | Current user profile |
| POST | `/auth/change-password` | Authenticated | `{ currentPassword, newPassword }` |
| POST | `/auth/forgot-password` | Public | `{ email }` — sends reset email |
| POST | `/auth/reset-password/:token` | Public | `{ password }` |

## Users (Super Admin / Admin)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/users?role=&search=&page=&limit=` | List users |
| POST | `/users` | Create user `{ name, email, password, role, phone }` |
| PUT | `/users/:id` | Update user |
| DELETE | `/users/:id` | Delete user (Super Admin only) |

## Students

| Method | Endpoint | Description |
|---|---|---|
| GET | `/students?search=&class=&section=&status=&page=&limit=` | List students |
| GET | `/students/:id` | Full profile (attendance, results, fees) |
| POST | `/students` | Create student + linked login account |
| PUT | `/students/:id` | Update student |
| DELETE | `/students/:id` | Delete student + linked account |
| GET | `/students/export/csv` | Export all students as CSV |
| POST | `/students/import/csv` | Bulk import (`multipart/form-data`, field `file`) |

## Teachers

Same CRUD shape as Students under `/teachers`.

## Academics

| Resource | Base path |
|---|---|
| Sessions | `/academics/sessions` |
| Classes | `/academics/classes` |
| Sections | `/academics/sections` |
| Subjects | `/academics/subjects` |

Each supports `GET` (list), `POST` (create), `PUT /:id` (update), `DELETE /:id`.

## Attendance

| Method | Endpoint | Description |
|---|---|---|
| POST | `/attendance/mark` | `{ class, section, date, records: [{student, status, remarks}] }` |
| GET | `/attendance?class=&section=&date=` | Attendance for a class/section/day |
| GET | `/attendance/student/:studentId?from=&to=` | History + attendance % |
| GET | `/attendance/export/csv?class=&section=&date=` | CSV export |

## Exams & Results

| Method | Endpoint | Description |
|---|---|---|
| GET/POST | `/exams` | List / create exams |
| PUT/DELETE | `/exams/:id` | Update / delete exam |
| POST | `/exams/:examId/results` | Upsert a student's marks |
| GET | `/exams/:examId/results` | Ranked results list |
| PATCH | `/exams/:examId/publish` | Publish results |
| PATCH | `/exams/:examId/lock` | Lock results (no further edits) |
| GET | `/exams/:examId/results/:studentId/report-card` | PDF report card |

## Fees & Payments

| Method | Endpoint | Description |
|---|---|---|
| GET/POST | `/fees` | List / create fee invoices |
| PUT/DELETE | `/fees/:id` | Update / delete |
| GET/POST | `/payments` | List / record payments |
| GET | `/payments/:id/receipt` | PDF receipt |

## Expenses

Standard CRUD under `/expenses` (Finance roles only).

## Notices, Notifications, Assignments

- `/notices` — CRUD; auto-generates in-app notifications for the target audience.
- `/notifications` — `GET /`, `PATCH /:id/read`, `PATCH /read-all`.
- `/assignments` — CRUD + `POST /:id/submit`.

## Timetable

| Method | Endpoint | Description |
|---|---|---|
| GET | `/timetables?class=&section=` | Weekly schedule for a class/section |
| GET | `/timetables/teacher/:teacherId` | All periods assigned to a teacher |
| POST | `/timetables/:class/:section/periods` | Add a period (checks teacher/room conflicts, 409 on clash) |
| PUT | `/timetables/:class/:section/periods/:periodId` | Update a period |
| DELETE | `/timetables/:class/:section/periods/:periodId` | Remove a period |

## Library

| Method | Endpoint | Description |
|---|---|---|
| GET/POST | `/library/books` | List / add books |
| PUT/DELETE | `/library/books/:id` | Update / delete a book |
| POST | `/library/issue` | Issue a book `{ book, borrower, borrowerModel, dueDate, fineRatePerDay }` |
| PATCH | `/library/return/:transactionId` | Return a book (auto-calculates overdue fine) |
| GET | `/library/transactions?borrower=&status=` | Issue/return history |

## Transport

| Method | Endpoint | Description |
|---|---|---|
| GET/POST | `/transport/vehicles` | List / add vehicles |
| PUT/DELETE | `/transport/vehicles/:id` | Update / delete a vehicle |
| GET/POST | `/transport/routes` | List / add routes (with stops) |
| PUT/DELETE | `/transport/routes/:id` | Update / delete a route |
| GET | `/transport/assignments` | List student transport assignments |
| POST | `/transport/assign` | Assign a student to a vehicle/route/stop |
| DELETE | `/transport/assignments/:id` | Remove an assignment |

## Hostel

| Method | Endpoint | Description |
|---|---|---|
| GET/POST | `/hostels` | List / create hostel buildings |
| PUT/DELETE | `/hostels/:id` | Update / delete a building |
| POST | `/hostels/:id/rooms` | Add a room (with beds) to a building |
| PATCH | `/hostels/:id/rooms/:roomId/beds/:bedId/allocate` | Allocate a bed to a student |
| PATCH | `/hostels/:id/rooms/:roomId/beds/:bedId/checkout` | Free up a bed |

## Staff

Standard CRUD under `/staff` (Admin-like roles) — mirrors the Teacher module for non-teaching employees.

## Leave Management

| Method | Endpoint | Description |
|---|---|---|
| GET | `/leaves?applicant=&status=` | List leave requests |
| POST | `/leaves` | Apply for leave `{ applicant, applicantModel, leaveType, startDate, endDate, reason }` |
| PATCH | `/leaves/:id/review` | Approve/reject `{ status, reviewNote }` (Admin-like only) |
| DELETE | `/leaves/:id` | Withdraw/delete a request |

## Events & Calendar

Standard CRUD under `/events?from=&to=&type=`. Types: `event`, `holiday`, `exam`, `meeting`, `parent_teacher_meeting`, `activity`.

## Document Management

| Method | Endpoint | Description |
|---|---|---|
| GET | `/documents?category=&relatedKind=&relatedId=` | List documents |
| POST | `/documents` | Upload (`multipart/form-data`: `file`, `title`, `category`, `relatedKind`, `relatedId`) |
| DELETE | `/documents/:id` | Delete |

## ID Cards

| Method | Endpoint | Description |
|---|---|---|
| GET | `/id-cards/student/:studentId` | PDF ID card for a student |
| GET | `/id-cards/teacher/:teacherId` | PDF ID card for a teacher |

## Certificates

| Method | Endpoint | Description |
|---|---|---|
| GET | `/certificates?student=` | List issued certificates |
| POST | `/certificates` | Issue `{ student, type, title, body }` — use `{{studentName}}` as a placeholder in `body` |
| DELETE | `/certificates/:id` | Delete |
| GET | `/certificates/:id/pdf` | Download printable PDF |

## Dashboard

| Endpoint | Role |
|---|---|
| `/dashboard/admin` | Admin-like roles |
| `/dashboard/teacher` | Teacher |
| `/dashboard/student` | Student, Parent |

## Settings & Audit Logs

- `GET/PUT /settings` — school-wide configuration (singleton document).
- `GET /audit-logs?entity=&user=&page=&limit=` — Super Admin/Admin only.

## Uploads

`POST /uploads` — `multipart/form-data`, field `file`. Returns `{ url }`.

---

## Error Responses

| Status | Meaning |
|---|---|
| 400 | Validation error / bad request |
| 401 | Missing/invalid/expired token |
| 403 | Authenticated but not authorized for this action |
| 404 | Resource not found |
| 409 | Conflict (duplicate email/admission number/etc.) |
| 500 | Unexpected server error |

## Permissions Summary

| Role | Notable access |
|---|---|
| super_admin | Full access, including user deletion |
| admin / principal | Full access except deleting user accounts |
| accountant | Fees, payments, expenses, admin dashboard |
| teacher | Attendance, exams/results (own), assignments, notices (create) |
| receptionist | Student records (create/read/update), staff dashboard |
| student | Own profile, attendance, published results, fees, assignments, notices |
| parent | Same as student, scoped to linked children |
| staff / librarian | Generic staff dashboard (extend per module) |
