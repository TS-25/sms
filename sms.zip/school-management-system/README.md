# Greenwood — School Management System

A full-stack MERN School Management System: React (Vite + Tailwind) frontend,
Node/Express/MongoDB backend, JWT auth, role-based access control, PDF
report cards & receipts, CSV import/export, and a modular architecture
designed to be extended module by module.

> **Full feature set:** every module from the original specification is
> implemented end-to-end — auth & RBAC, students, teachers, staff,
> classes/sections/subjects, timetable (with conflict detection),
> attendance, exams & results, fees & payments, expenses, library
> (issue/return with fines), transport (vehicles/routes/assignments),
> hostel (buildings/rooms/beds/allocation), leave management, events &
> calendar, document management, ID cards, certificates, notices,
> notifications, assignments, dashboards, settings, and audit logs.

---

## 1. Tech Stack

**Frontend:** React 18, Vite, Tailwind CSS, React Router, Axios, Chart.js
**Backend:** Node.js, Express, MongoDB, Mongoose, JWT, bcrypt
**Other:** pdfkit (PDF generation), csv-parse/json2csv (import/export),
nodemailer (email, with console fallback), multer (uploads, local or
Cloudinary-ready)

---

## 2. Project Structure

```
school-management-system/
├── client/                  # React frontend (Vite)
│   ├── src/
│   │   ├── pages/            # admin/teacher/student/parent/auth pages
│   │   ├── components/       # layout, ui, forms
│   │   ├── context/           # AuthContext
│   │   ├── services/          # axios API clients
│   │   └── hooks/
│   ├── Dockerfile
│   └── package.json
├── server/                  # Express backend
│   ├── src/
│   │   ├── controllers/
│   │   ├── models/
│   │   ├── routes/
│   │   ├── middleware/
│   │   ├── services/         # email, pdf, csv, storage
│   │   ├── utils/            # seed script, helpers
│   │   └── app.js / server.js
│   ├── Dockerfile
│   └── package.json
├── docker-compose.yml
├── API_DOCUMENTATION.md
├── .env.example
└── README.md
```

---

## 3. Quickest Start — One Command with Docker

If you have [Docker Desktop](https://www.docker.com/products/docker-desktop/) installed, you can skip everything below and just run:

```bash
chmod +x setup.sh   # only needed once, if the execute bit didn't survive the zip
./setup.sh
```

This single script will:
1. Check Docker is installed and running
2. Generate secure random JWT secrets on first run (saved to `.env`)
3. Build and start MongoDB, the API, and the frontend
4. Wait for each service to report healthy
5. Seed the database with demo accounts (safe to re-run)
6. Print the URLs and login credentials

When it finishes, open **http://localhost:5173** and sign in with any of
the printed demo accounts.

Other commands:
```bash
./setup.sh --down     # stop all containers (keeps your data)
./setup.sh --reset    # wipe the database and start completely fresh
docker compose logs -f          # follow logs from every service
docker compose logs -f server   # follow just the API server's logs
```

> **Windows users:** run this from Git Bash, WSL, or any bash-compatible
> terminal (PowerShell/CMD alone won't run `.sh` files). Docker Desktop for
> Windows includes WSL2 integration, which works well for this.

If you'd rather run things manually (without Docker), or want to
understand what the script does under the hood, continue to the sections
below.

---

## 4. Local Development (without Docker)

### Prerequisites
- Node.js 18+
- MongoDB (local install or MongoDB Atlas)
- npm

### Setup

```bash
# From the project root
npm run install:all       # installs both client and server dependencies

# Configure environment variables
cp .env.example server/.env      # then edit server/.env with real values
cp client/.env.example client/.env
```

Edit `server/.env` — at minimum set `MONGODB_URI`, `JWT_SECRET`, and
`JWT_REFRESH_SECRET` to real values.

### Seed the database

```bash
npm run seed --prefix server
```

This creates a Super Admin, Admin, Teacher, Student, Parent, and
Accountant account, plus a sample class/section/subject/session. Login
credentials are printed to the console — **change them after first login.**

### Run in development

```bash
npm run dev     # runs client (5173) and server (5000) concurrently
```

Or separately:
```bash
npm run dev:server
npm run dev:client
```

Visit `http://localhost:5173` and sign in with a seeded account.

---

## 5. Environment Variables

See `.env.example` (root) for the full server list and `client/.env.example`
for the frontend. Key variables:

| Variable | Description |
|---|---|
| `MONGODB_URI` | MongoDB connection string |
| `JWT_SECRET` / `JWT_REFRESH_SECRET` | Long random strings — **never reuse defaults in production** |
| `CLIENT_URL` | Frontend origin(s), comma-separated — drives CORS |
| `STORAGE_PROVIDER` | `local` (default) or `cloudinary` |
| `CLOUDINARY_*` | Only needed if `STORAGE_PROVIDER=cloudinary` |
| `EMAIL_*` | Optional — without these, emails are logged to the server console instead of sent |
| `VITE_API_URL` (client) | Full URL to the backend API, e.g. `https://api.yourschool.com/api` |

Never commit a populated `.env` file. Only `.env.example` files belong in
version control.

---

## 6. Production Build

```bash
# Frontend
cd client && npm run build      # outputs to client/dist

# Backend
cd server && npm start
```

The backend serves purely as an API (CORS-enabled); the frontend build is a
static SPA that can be hosted anywhere (Vercel, Netlify, Nginx, same VPS).

---

## 7. Deployment

### 7.1 MongoDB Atlas (recommended for managed hosting)
1. Create a free cluster at https://www.mongodb.com/atlas.
2. Add a database user and allow access from `0.0.0.0/0` (or your hosting
   provider's IP ranges).
3. Copy the connection string into `MONGODB_URI`.

### 7.2 Render (backend)
1. New → Web Service → connect your GitHub repo, root directory `server`.
2. Build command: `npm install`
3. Start command: `npm start`
4. Add all environment variables from `.env.example` in the Render dashboard.
5. Once deployed, note the URL (e.g. `https://your-api.onrender.com`).

### 7.3 Railway (backend)
1. New Project → Deploy from GitHub → select repo, root directory `server`.
2. Railway auto-detects Node; set the start command to `npm start` if needed.
3. Add environment variables in the Railway dashboard.
4. Optionally add a MongoDB plugin, or use Atlas.

### 7.4 Vercel / Netlify (frontend)
1. New Project → import repo, root directory `client`.
2. Build command: `npm run build` — Output directory: `dist`.
3. Set environment variable `VITE_API_URL` to your deployed backend's
   `/api` URL (e.g. `https://your-api.onrender.com/api`).
4. Deploy. Both platforms handle SPA routing automatically; if you see
   404s on refresh, add a rewrite rule sending all paths to `/index.html`.

### 7.5 VPS (via Docker — easiest)
```bash
git clone <your-repo-url>
cd school-management-system
./setup.sh
```
`setup.sh` generates secrets and starts everything on `localhost` by
default. For a real domain, edit the `.env` file it creates and set
`CLIENT_URL` and `VITE_API_URL` to your public URLs (e.g.
`https://yourschool.com` and `https://api.yourschool.com/api`) **before**
running `./setup.sh`, or edit `.env` and run `docker compose up -d --build`
again afterward to rebuild with the new values. Put Nginx or Caddy in
front for TLS termination.

### 7.6 VPS (without Docker)
```bash
# Backend
cd server
npm install --production
pm2 start src/server.js --name sms-api    # or use systemd

# Frontend
cd ../client
npm install
npm run build
# Serve client/dist with Nginx, e.g.:
#   root /var/www/sms/client/dist;
#   try_files $uri /index.html;
```

---

## 8. Docker (Manual / Advanced)

```bash
docker compose up -d --build
```
This starts MongoDB, the API (port 5000), and the frontend served via
Nginx (port 5173). Override defaults with a `.env` file at the project
root (`JWT_SECRET`, `JWT_REFRESH_SECRET`, `CLIENT_URL`, `VITE_API_URL`).

Docker is entirely optional — everything also runs with plain `npm` commands.

---

## 9. Default Login Credentials (after seeding)

| Role | Email | Password |
|---|---|---|
| Super Admin | `superadmin@school.com` | `SuperAdmin@123` |
| Admin | `admin@school.com` | `Admin@123` |
| Teacher | `teacher@school.com` | `Teacher@123` |
| Student | `student@school.com` | `Student@123` |
| Parent | `parent@school.com` | `Parent@123` |
| Accountant | `accountant@school.com` | `Accountant@123` |

**Change every password immediately after first login in any real
deployment.** You can also override the Super Admin credentials before
seeding via `SEED_SUPERADMIN_EMAIL` / `SEED_SUPERADMIN_PASSWORD` in
`server/.env`.

---

## 10. API Documentation

See [`API_DOCUMENTATION.md`](./API_DOCUMENTATION.md) for the full endpoint
reference, request/response shapes, and permission matrix.

---

## 11. Extending the System

Every module follows the same four-layer pattern:
1. **Model** (`server/src/models/X.js`) — Mongoose schema
2. **Controller** (`server/src/controllers/xController.js`) — business logic
3. **Routes** (`server/src/routes/xRoutes.js`) — wires controller to HTTP + RBAC
4. **Frontend** (`client/src/pages/.../XPage.jsx` + `resourceServices.js` entry)

To add Library, Transport, or Hostel management, copy the `Fee`/`Payment`
module as a template — same shape (a "definition" model + a "transaction"
model), same CRUD + list endpoints, same `DataTable` + `Modal` UI pattern
already used across Students, Teachers, Fees, and Expenses.

---

## 12. Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| `setup.sh: Permission denied` | Run `chmod +x setup.sh` first, or invoke it as `bash setup.sh` |
| `setup.sh` hangs on "Waiting for API server" | Run `docker compose logs server` in another terminal to see the actual startup error (often a bad `MONGODB_URI` or a port already in use) |
| Port 5173 or 5000 already in use | Stop whatever else is using that port, or edit the `ports:` mappings in `docker-compose.yml` (e.g. `'5174:80'`) and use the new port in the browser |
| `MongoDB connection error` on boot | Check `MONGODB_URI`; if using Atlas, confirm IP allowlist and credentials |
| Frontend shows CORS errors | `CLIENT_URL` on the server must exactly match the frontend origin (protocol + domain, no trailing slash) |
| Login succeeds but you're logged out again on refresh | The refresh-token cookie isn't being saved. Confirm `CLIENT_URL` on the server exactly matches the URL you're typing into the browser (`localhost` vs `127.0.0.1` matters less now — see below — but the port must match), and that you're not mixing `http://` and `https://` between frontend and backend |
| 401 loops / constant logout | Confirm `JWT_SECRET`/`JWT_REFRESH_SECRET` are set and consistent across restarts; cookies require `credentials: true` on both client and server, which is already configured |
| File uploads fail in production | On most PaaS hosts (Render/Railway) local disk storage is ephemeral — set `STORAGE_PROVIDER=cloudinary` and provide Cloudinary credentials for persistent uploads |
| PDF downloads show as blank browser tab | Some browsers block `window.open` on delayed blob URLs — the app already fetches synchronously inside the click handler; check the browser's pop-up blocker |
| CSV import skips all rows | Ensure CSV headers exactly match: `admissionNumber, firstName, lastName, email, class, section, academicSession, ...` where `class`/`section`/`academicSession` are ObjectIds copied from `/academics/classes` etc. |
| `npm run seed` says user already exists | Safe — the seed script is idempotent and skips existing records |
| Vite build fails with missing env var | Ensure `client/.env` exists with `VITE_API_URL` before running `npm run build` (Vite inlines env vars at build time) |

---

## 13. Security Notes

- Passwords are hashed with bcrypt; plaintext passwords are never stored or logged.
- Access tokens are short-lived; refresh tokens are httpOnly cookies, not accessible to JS.
- Helmet, CORS allowlisting, rate limiting, and MongoDB query sanitization are enabled by default.
- Audit logs record create/update/delete actions with the acting user and IP.
- Change all seeded passwords and JWT secrets before going to production.
