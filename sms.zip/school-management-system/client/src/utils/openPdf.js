import { getAccessToken } from '../services/api';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Many endpoints (report cards, receipts, ID cards, certificates) stream a
// PDF and require the Authorization header, which a plain <a href> can't
// send. This fetches the PDF as a blob and opens it in a new tab.
export async function openPdf(path) {
  const token = getAccessToken();
  const res = await fetch(`${API_URL}${path}`, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error('Failed to generate PDF.');
  const blob = await res.blob();
  window.open(window.URL.createObjectURL(blob));
}
