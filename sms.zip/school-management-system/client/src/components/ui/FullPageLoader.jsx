export default function FullPageLoader() {
  return (
    <div className="flex h-screen w-full items-center justify-center bg-cream">
      <div className="flex flex-col items-center gap-3">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-ink-200 border-t-brass-400" />
        <p className="text-sm text-ink-400">Loading…</p>
      </div>
    </div>
  );
}
