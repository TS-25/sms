import { IoSearchOutline } from 'react-icons/io5';

// A minimal, reusable table shell used across all admin CRUD screens.
// `columns` is [{ header, accessor: (row) => node }], `actions` renders
// per-row action buttons (edit/delete/view).
export default function DataTable({
  columns,
  rows,
  loading,
  search,
  onSearchChange,
  searchPlaceholder = 'Search…',
  actions,
  emptyMessage = 'No records found.',
  pagination,
  onPageChange,
}) {
  return (
    <div className="card overflow-hidden">
      {onSearchChange && (
        <div className="border-b border-ink-100 p-4">
          <div className="relative max-w-xs">
            <IoSearchOutline className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-ink-300" />
            <input
              className="input pl-9"
              placeholder={searchPlaceholder}
              value={search}
              onChange={(e) => onSearchChange(e.target.value)}
            />
          </div>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="table-base">
          <thead>
            <tr>
              {columns.map((col) => (
                <th key={col.header}>{col.header}</th>
              ))}
              {actions && <th className="text-right">Actions</th>}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={columns.length + (actions ? 1 : 0)} className="py-8 text-center text-ink-400">
                  Loading…
                </td>
              </tr>
            ) : rows.length === 0 ? (
              <tr>
                <td colSpan={columns.length + (actions ? 1 : 0)} className="py-10 text-center text-ink-400">
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              rows.map((row, i) => (
                <tr key={row._id || i} className="hover:bg-ink-50/40">
                  {columns.map((col) => (
                    <td key={col.header}>{col.accessor(row)}</td>
                  ))}
                  {actions && <td className="text-right">{actions(row)}</td>}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {pagination && pagination.pages > 1 && (
        <div className="flex items-center justify-between border-t border-ink-100 px-4 py-3 text-sm text-ink-500">
          <span>
            Page {pagination.page} of {pagination.pages} ({pagination.total} total)
          </span>
          <div className="flex gap-2">
            <button
              className="btn-outline px-3 py-1"
              disabled={pagination.page <= 1}
              onClick={() => onPageChange(pagination.page - 1)}
            >
              Previous
            </button>
            <button
              className="btn-outline px-3 py-1"
              disabled={pagination.page >= pagination.pages}
              onClick={() => onPageChange(pagination.page + 1)}
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
