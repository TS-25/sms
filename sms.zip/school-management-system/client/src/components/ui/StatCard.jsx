export default function StatCard({ label, value, hint, accent = false }) {
  return (
    <div className="card p-5">
      <p className="text-sm text-ink-400">{label}</p>
      <p className={`mt-2 font-display text-3xl ${accent ? 'text-brass-500' : 'text-ink-800'}`}>
        {value}
      </p>
      {hint && <p className="mt-1 text-xs text-ink-400">{hint}</p>}
    </div>
  );
}
