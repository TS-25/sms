export function TextField({ label, ...props }) {
  return (
    <div>
      <label className="label">{label}</label>
      <input className="input" {...props} />
    </div>
  );
}

export function SelectField({ label, options, ...props }) {
  return (
    <div>
      <label className="label">{label}</label>
      <select className="input" {...props}>
        <option value="">Select…</option>
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>
    </div>
  );
}

export function TextAreaField({ label, ...props }) {
  return (
    <div>
      <label className="label">{label}</label>
      <textarea className="input" rows={3} {...props} />
    </div>
  );
}
