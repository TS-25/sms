import { useEffect, useState } from 'react';
import { academicService } from '../services/resourceServices';

// Loads sessions/classes/subjects once and exposes filtered sections for a
// given class — used by every form/page that needs these dropdowns
// (students, teachers, attendance, exams, subjects...).
export function useAcademicLookups() {
  const [sessions, setSessions] = useState([]);
  const [classes, setClasses] = useState([]);
  const [sections, setSections] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [s, c, sec, subj] = await Promise.all([
          academicService.sessions.list(),
          academicService.classes.list(),
          academicService.sections.list(),
          academicService.subjects.list(),
        ]);
        setSessions(s.data.data);
        setClasses(c.data.data);
        setSections(sec.data.data);
        setSubjects(subj.data.data);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const sectionsForClass = (classId) => sections.filter((s) => s.class?._id === classId || s.class === classId);

  return { sessions, classes, sections, subjects, sectionsForClass, loading };
}
