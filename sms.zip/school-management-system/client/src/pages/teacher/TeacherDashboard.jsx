import { useEffect, useState } from 'react';
import { dashboardService } from '../../services/resourceServices';
import StatCard from '../../components/ui/StatCard';
import EmptyState from '../../components/ui/EmptyState';
import FullPageLoader from '../../components/ui/FullPageLoader';

export default function TeacherDashboard() {
  const [data, setData] = useState(null);

  useEffect(() => {
    dashboardService.teacher().then(({ data }) => setData(data.data));
  }, []);

  if (!data) return <FullPageLoader />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Welcome back</h1>
        <p className="text-sm text-ink-400">Here's what's happening with your classes.</p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard label="Assigned Classes" value={data.classesCount} />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="card p-5">
          <h3 className="mb-3 font-display text-base text-ink-700">Your Upcoming Assignments</h3>
          {data.assignments.length === 0 ? (
            <EmptyState title="No assignments yet" description="Assignments you create will appear here." />
          ) : (
            <ul className="space-y-2 text-sm">
              {data.assignments.map((a) => (
                <li key={a._id} className="flex justify-between border-b border-ink-50 pb-2">
                  <span>{a.title}</span>
                  <span className="text-ink-400">{new Date(a.deadline).toLocaleDateString()}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="card p-5">
          <h3 className="mb-3 font-display text-base text-ink-700">Recent Notices</h3>
          {data.notices.length === 0 ? (
            <EmptyState title="No notices yet" />
          ) : (
            <ul className="space-y-2 text-sm">
              {data.notices.map((n) => (
                <li key={n._id} className="border-b border-ink-50 pb-2">{n.title}</li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
