import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoTrashOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import EmptyState from '../../components/ui/EmptyState';
import { TextField, SelectField, TextAreaField } from '../../components/forms/FormFields';
import { assignmentService } from '../../services/resourceServices';
import { useAcademicLookups } from '../../hooks/useAcademicLookups';

export default function TeacherAssignmentsPage() {
  const { classes, sectionsForClass, subjects } = useAcademicLookups();
  const [assignments, setAssignments] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ title: '', description: '', class: '', section: '', subject: '', deadline: '' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await assignmentService.list();
      setAssignments(data.data);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await assignmentService.create(form);
      toast.success('Assignment posted.');
      setModalOpen(false);
      setForm({ title: '', description: '', class: '', section: '', subject: '', deadline: '' });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to post assignment.');
    }
  };

  const handleDelete = async () => {
    await assignmentService.remove(deleteTarget._id);
    toast.success('Assignment deleted.');
    setDeleteTarget(null);
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Assignments</h1>
          <p className="text-sm text-ink-400">Post and manage homework for your classes.</p>
        </div>
        <button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> New Assignment</button>
      </div>

      {loading ? (
        <p className="text-ink-400">Loading…</p>
      ) : assignments.length === 0 ? (
        <EmptyState title="No assignments yet" description="Assignments you create will appear here." />
      ) : (
        <div className="space-y-3">
          {assignments.map((a) => (
            <div key={a._id} className="card flex items-start justify-between p-5">
              <div>
                <h3 className="font-display text-base text-ink-800">{a.title}</h3>
                <p className="mt-1 text-sm text-ink-500">{a.description}</p>
                <p className="mt-2 text-xs text-ink-300">
                  {a.class?.name} {a.section?.name && `/ ${a.section.name}`} · Due {new Date(a.deadline).toLocaleDateString()} · {a.submissions.length} submission(s)
                </p>
              </div>
              <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(a)}>
                <IoTrashOutline />
              </button>
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="New Assignment" size="lg">
        <form onSubmit={handleCreate} className="space-y-4">
          <TextField label="Title" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <TextAreaField label="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <div className="grid grid-cols-2 gap-4">
            <SelectField label="Class" required value={form.class} onChange={(e) => setForm({ ...form, class: e.target.value, section: '' })}
              options={classes.map((c) => ({ value: c._id, label: c.name }))} />
            <SelectField label="Section" value={form.section} onChange={(e) => setForm({ ...form, section: e.target.value })}
              options={sectionsForClass(form.class).map((s) => ({ value: s._id, label: s.name }))} />
          </div>
          <SelectField label="Subject" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })}
            options={subjects.filter((s) => !form.class || s.class?._id === form.class).map((s) => ({ value: s._id, label: s.name }))} />
          <TextField label="Deadline" type="date" required value={form.deadline} onChange={(e) => setForm({ ...form, deadline: e.target.value })} />
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass">Post Assignment</button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete assignment?" message="This cannot be undone." />
    </div>
  );
}
