import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoCloudUploadOutline, IoCloudDownloadOutline, IoTrashOutline, IoPencilOutline, IoIdCardOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import DataTable from '../../components/ui/DataTable';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import { TextField, SelectField } from '../../components/forms/FormFields';
import { studentService, idCardService } from '../../services/resourceServices';
import { useAcademicLookups } from '../../hooks/useAcademicLookups';
import { openPdf } from '../../utils/openPdf';

const emptyForm = {
  firstName: '', lastName: '', email: '', admissionNumber: '', rollNumber: '',
  gender: '', phone: '', class: '', section: '', academicSession: '',
  guardianName: '', guardianPhone: '',
};

export default function StudentsPage() {
  const { classes, sectionsForClass, sessions } = useAcademicLookups();
  const [students, setStudents] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [saving, setSaving] = useState(false);
  const fileInputRef = useState(null)[0];

  const loadStudents = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await studentService.list({ search, page, limit: 10 });
      setStudents(data.data);
      setPagination(data.pagination);
    } catch (err) {
      toast.error('Failed to load students.');
    } finally {
      setLoading(false);
    }
  }, [search, page]);

  useEffect(() => {
    loadStudents();
  }, [loadStudents]);

  const openCreate = () => {
    setEditingId(null);
    setForm(emptyForm);
    setModalOpen(true);
  };

  const openEdit = (student) => {
    setEditingId(student._id);
    setForm({
      firstName: student.firstName || '',
      lastName: student.lastName || '',
      email: student.email || '',
      admissionNumber: student.admissionNumber,
      rollNumber: student.rollNumber || '',
      gender: student.gender || '',
      phone: student.phone || '',
      class: student.class?._id || '',
      section: student.section?._id || '',
      academicSession: student.academicSession?._id || '',
      guardianName: student.guardianName || '',
      guardianPhone: student.guardianPhone || '',
    });
    setModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editingId) {
        await studentService.update(editingId, form);
        toast.success('Student updated.');
      } else {
        await studentService.create(form);
        toast.success('Student created.');
      }
      setModalOpen(false);
      loadStudents();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save student.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    try {
      await studentService.remove(deleteTarget._id);
      toast.success('Student deleted.');
      setDeleteTarget(null);
      loadStudents();
    } catch (err) {
      toast.error('Failed to delete student.');
    }
  };

  const handleExport = async () => {
    const { data } = await studentService.exportCsv();
    const url = window.URL.createObjectURL(new Blob([data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'students.csv');
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  const handleImport = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const { data } = await studentService.importCsv(file);
      toast.success(`Imported ${data.data.created} student(s). Skipped ${data.data.skipped}.`);
      loadStudents();
    } catch (err) {
      toast.error('Import failed.');
    } finally {
      e.target.value = '';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Students</h1>
          <p className="text-sm text-ink-400">Manage admissions, profiles, and class assignments.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <label className="btn-outline cursor-pointer">
            <IoCloudUploadOutline /> Import CSV
            <input type="file" accept=".csv" className="hidden" onChange={handleImport} />
          </label>
          <button className="btn-outline" onClick={handleExport}>
            <IoCloudDownloadOutline /> Export CSV
          </button>
          <button className="btn-brass" onClick={openCreate}>
            <IoAddOutline /> Add Student
          </button>
        </div>
      </div>

      <DataTable
        loading={loading}
        rows={students}
        search={search}
        onSearchChange={(v) => { setSearch(v); setPage(1); }}
        searchPlaceholder="Search by name or admission number…"
        pagination={pagination}
        onPageChange={setPage}
        columns={[
          { header: 'Admission No.', accessor: (r) => r.admissionNumber },
          { header: 'Name', accessor: (r) => `${r.firstName} ${r.lastName || ''}` },
          { header: 'Class/Section', accessor: (r) => `${r.class?.name || '—'} / ${r.section?.name || '—'}` },
          { header: 'Phone', accessor: (r) => r.phone || '—' },
          {
            header: 'Status',
            accessor: (r) => (
              <span className={`rounded-full px-2 py-0.5 text-xs ${r.status === 'active' ? 'bg-brass-50 text-brass-700' : 'bg-ink-100 text-ink-500'}`}>
                {r.status}
              </span>
            ),
          },
        ]}
        actions={(row) => (
          <div className="flex justify-end gap-2">
            <button className="p-1.5 text-ink-400 hover:text-ink-700" onClick={() => openPdf(idCardService.studentCardUrl(row._id)).catch(() => toast.error('Failed to generate ID card.'))} aria-label="ID Card">
              <IoIdCardOutline />
            </button>
            <button className="p-1.5 text-ink-400 hover:text-ink-700" onClick={() => openEdit(row)} aria-label="Edit">
              <IoPencilOutline />
            </button>
            <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(row)} aria-label="Delete">
              <IoTrashOutline />
            </button>
          </div>
        )}
      />

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editingId ? 'Edit Student' : 'Add Student'} size="lg">
        <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <TextField label="First Name" required value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} />
          <TextField label="Last Name" value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })} />
          <TextField label="Email" type="email" required disabled={!!editingId} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <TextField label="Admission Number" required disabled={!!editingId} value={form.admissionNumber} onChange={(e) => setForm({ ...form, admissionNumber: e.target.value })} />
          <TextField label="Roll Number" value={form.rollNumber} onChange={(e) => setForm({ ...form, rollNumber: e.target.value })} />
          <SelectField label="Gender" value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })}
            options={[{ value: 'male', label: 'Male' }, { value: 'female', label: 'Female' }, { value: 'other', label: 'Other' }]} />
          <TextField label="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          <SelectField label="Academic Session" required value={form.academicSession} onChange={(e) => setForm({ ...form, academicSession: e.target.value })}
            options={sessions.map((s) => ({ value: s._id, label: s.name }))} />
          <SelectField label="Class" required value={form.class} onChange={(e) => setForm({ ...form, class: e.target.value, section: '' })}
            options={classes.map((c) => ({ value: c._id, label: c.name }))} />
          <SelectField label="Section" required value={form.section} onChange={(e) => setForm({ ...form, section: e.target.value })}
            options={sectionsForClass(form.class).map((s) => ({ value: s._id, label: s.name }))} />
          <TextField label="Guardian Name" value={form.guardianName} onChange={(e) => setForm({ ...form, guardianName: e.target.value })} />
          <TextField label="Guardian Phone" value={form.guardianPhone} onChange={(e) => setForm({ ...form, guardianPhone: e.target.value })} />

          <div className="col-span-full mt-2 flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button type="submit" className="btn-brass" disabled={saving}>{saving ? 'Saving…' : 'Save Student'}</button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete student?"
        message={`This will permanently remove ${deleteTarget?.firstName}'s record and login account.`}
      />
    </div>
  );
}
