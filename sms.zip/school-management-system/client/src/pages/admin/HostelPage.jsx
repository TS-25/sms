import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoTrashOutline, IoBedOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import { TextField, SelectField } from '../../components/forms/FormFields';
import { hostelService, studentService } from '../../services/resourceServices';

export default function HostelPage() {
  const [hostels, setHostels] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [roomModal, setRoomModal] = useState(null); // hostel being edited
  const [allocateTarget, setAllocateTarget] = useState(null); // { hostelId, roomId, bedId }
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ name: '', type: 'mixed', warden: '', wardenPhone: '', monthlyFee: 0 });
  const [roomForm, setRoomForm] = useState({ roomNumber: '', capacity: 4 });
  const [studentQuery, setStudentQuery] = useState('');
  const [studentOptions, setStudentOptions] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState('');

  const load = useCallback(async () => {
    const { data } = await hostelService.list();
    setHostels(data.data);
  }, []);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (studentQuery.length < 2) { setStudentOptions([]); return; }
    const t = setTimeout(async () => {
      const { data } = await studentService.list({ search: studentQuery, limit: 10 });
      setStudentOptions(data.data);
    }, 300);
    return () => clearTimeout(t);
  }, [studentQuery]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await hostelService.create(form);
      toast.success('Hostel building created.');
      setModalOpen(false);
      setForm({ name: '', type: 'mixed', warden: '', wardenPhone: '', monthlyFee: 0 });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create hostel.');
    }
  };

  const handleDelete = async () => {
    await hostelService.remove(deleteTarget._id);
    toast.success('Hostel deleted.');
    setDeleteTarget(null);
    load();
  };

  const handleAddRoom = async (e) => {
    e.preventDefault();
    const beds = Array.from({ length: Number(roomForm.capacity) }, (_, i) => ({ bedNumber: `${roomForm.roomNumber}-${i + 1}` }));
    try {
      await hostelService.addRoom(roomModal._id, { ...roomForm, beds });
      toast.success('Room added.');
      setRoomForm({ roomNumber: '', capacity: 4 });
      const { data } = await hostelService.list();
      setHostels(data.data);
      setRoomModal(data.data.find((h) => h._id === roomModal._id));
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to add room.');
    }
  };

  const handleAllocate = async (e) => {
    e.preventDefault();
    const { hostelId, roomId, bedId } = allocateTarget;
    try {
      await hostelService.allocateBed(hostelId, roomId, bedId, { student: selectedStudent });
      toast.success('Bed allocated.');
      setAllocateTarget(null);
      setSelectedStudent('');
      setStudentQuery('');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to allocate bed.');
    }
  };

  const handleCheckout = async (hostelId, roomId, bedId) => {
    await hostelService.checkoutBed(hostelId, roomId, bedId);
    toast.success('Bed checked out.');
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Hostel</h1>
          <p className="text-sm text-ink-400">Manage buildings, rooms, beds, and student allocation.</p>
        </div>
        <button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> Add Building</button>
      </div>

      {hostels.length === 0 ? (
        <div className="card p-8 text-center text-ink-400">No hostel buildings added yet.</div>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {hostels.map((h) => {
            const totalBeds = h.rooms.reduce((sum, r) => sum + r.beds.length, 0);
            const occupied = h.rooms.reduce((sum, r) => sum + r.beds.filter((b) => b.isOccupied).length, 0);
            return (
              <div key={h._id} className="card p-5">
                <div className="mb-2 flex items-start justify-between">
                  <div>
                    <h3 className="font-display text-base text-ink-800">{h.name}</h3>
                    <p className="text-xs text-ink-400 capitalize">{h.type} · {occupied}/{totalBeds} beds occupied</p>
                  </div>
                  <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(h)}><IoTrashOutline /></button>
                </div>
                <button className="btn-outline w-full" onClick={() => setRoomModal(h)}><IoBedOutline /> Manage Rooms</button>
              </div>
            );
          })}
        </div>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Add Hostel Building">
        <form onSubmit={handleCreate} className="space-y-4">
          <TextField label="Building Name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <SelectField label="Type" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}
            options={[{ value: 'boys', label: 'Boys' }, { value: 'girls', label: 'Girls' }, { value: 'mixed', label: 'Mixed' }]} />
          <TextField label="Warden Name" value={form.warden} onChange={(e) => setForm({ ...form, warden: e.target.value })} />
          <TextField label="Warden Phone" value={form.wardenPhone} onChange={(e) => setForm({ ...form, wardenPhone: e.target.value })} />
          <TextField label="Monthly Fee" type="number" value={form.monthlyFee} onChange={(e) => setForm({ ...form, monthlyFee: e.target.value })} />
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass">Create</button>
          </div>
        </form>
      </Modal>

      {roomModal && (
        <Modal isOpen onClose={() => setRoomModal(null)} title={`${roomModal.name} — Rooms & Beds`} size="xl">
          <form onSubmit={handleAddRoom} className="mb-6 flex items-end gap-3">
            <TextField label="Room Number" required value={roomForm.roomNumber} onChange={(e) => setRoomForm({ ...roomForm, roomNumber: e.target.value })} />
            <TextField label="Capacity (beds)" type="number" min={1} value={roomForm.capacity} onChange={(e) => setRoomForm({ ...roomForm, capacity: e.target.value })} />
            <button className="btn-brass">Add Room</button>
          </form>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {roomModal.rooms.map((room) => (
              <div key={room._id} className="rounded-md border border-ink-100 p-4">
                <p className="mb-2 font-medium text-ink-700">Room {room.roomNumber}</p>
                <div className="grid grid-cols-2 gap-2">
                  {room.beds.map((bed) => (
                    <div key={bed._id} className={`rounded-md p-2 text-xs ${bed.isOccupied ? 'bg-brass-50' : 'bg-ink-50'}`}>
                      <p className="font-medium">{bed.bedNumber}</p>
                      {bed.isOccupied ? (
                        <>
                          <p className="text-ink-500">{bed.student?.firstName} {bed.student?.lastName}</p>
                          <button className="mt-1 text-red-600 hover:underline" onClick={() => handleCheckout(roomModal._id, room._id, bed._id)}>
                            Check out
                          </button>
                        </>
                      ) : (
                        <button className="mt-1 text-brass-600 hover:underline" onClick={() => setAllocateTarget({ hostelId: roomModal._id, roomId: room._id, bedId: bed._id })}>
                          Allocate
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Modal>
      )}

      {allocateTarget && (
        <Modal isOpen onClose={() => setAllocateTarget(null)} title="Allocate Bed">
          <form onSubmit={handleAllocate} className="space-y-4">
            <div>
              <label className="label">Student</label>
              <input className="input" placeholder="Search by name…" value={studentQuery} onChange={(e) => setStudentQuery(e.target.value)} />
              {studentOptions.length > 0 && (
                <div className="mt-1 max-h-40 overflow-y-auto rounded-md border border-ink-100 bg-white shadow-sm">
                  {studentOptions.map((s) => (
                    <button type="button" key={s._id} className="block w-full px-3 py-2 text-left text-sm hover:bg-ink-50"
                      onClick={() => { setSelectedStudent(s._id); setStudentQuery(`${s.firstName} ${s.lastName || ''}`); setStudentOptions([]); }}>
                      {s.firstName} {s.lastName} — {s.admissionNumber}
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div className="flex justify-end gap-3">
              <button type="button" className="btn-outline" onClick={() => setAllocateTarget(null)}>Cancel</button>
              <button className="btn-brass" disabled={!selectedStudent}>Allocate</button>
            </div>
          </form>
        </Modal>
      )}

      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete hostel building?" message="This cannot be undone." />
    </div>
  );
}
