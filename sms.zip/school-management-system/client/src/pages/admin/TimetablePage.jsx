import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoTrashOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import Modal from '../../components/ui/Modal';
import { TextField, SelectField } from '../../components/forms/FormFields';
import { timetableService } from '../../services/resourceServices';
import { useAcademicLookups } from '../../hooks/useAcademicLookups';
import { useAuth } from '../../context/AuthContext';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export default function TimetablePage() {
  const { user } = useAuth();
  const canManage = ['super_admin', 'admin', 'principal'].includes(user?.role);
  const { classes, sectionsForClass, subjects } = useAcademicLookups();
  const [classId, setClassId] = useState('');
  const [sectionId, setSectionId] = useState('');
  const [timetable, setTimetable] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({ day: 'Monday', startTime: '09:00', endTime: '09:45', subject: '', room: '' });

  const load = useCallback(async () => {
    if (!classId || !sectionId) return;
    const { data } = await timetableService.get({ class: classId, section: sectionId });
    setTimetable(data.data);
  }, [classId, sectionId]);

  useEffect(() => { load(); }, [load]);

  const handleAdd = async (e) => {
    e.preventDefault();
    try {
      await timetableService.addPeriod(classId, sectionId, form);
      toast.success('Period added.');
      setModalOpen(false);
      setForm({ day: 'Monday', startTime: '09:00', endTime: '09:45', subject: '', room: '' });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to add period — check for conflicts.');
    }
  };

  const handleRemove = async (periodId) => {
    await timetableService.removePeriod(classId, sectionId, periodId);
    toast.success('Period removed.');
    load();
  };

  const periodsByDay = (day) =>
    (timetable?.periods || [])
      .filter((p) => p.day === day)
      .sort((a, b) => a.startTime.localeCompare(b.startTime));

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Timetable</h1>
          <p className="text-sm text-ink-400">Weekly class schedule by period.</p>
        </div>
        {canManage && classId && sectionId && (
          <button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> Add Period</button>
        )}
      </div>

      <div className="card grid grid-cols-1 gap-4 p-5 sm:grid-cols-2">
        <SelectField label="Class" value={classId} onChange={(e) => { setClassId(e.target.value); setSectionId(''); }}
          options={classes.map((c) => ({ value: c._id, label: c.name }))} />
        <SelectField label="Section" value={sectionId} onChange={(e) => setSectionId(e.target.value)}
          options={sectionsForClass(classId).map((s) => ({ value: s._id, label: s.name }))} />
      </div>

      {classId && sectionId && (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3 xl:grid-cols-6">
          {DAYS.map((day) => (
            <div key={day} className="card p-4">
              <h3 className="mb-3 font-display text-sm text-ink-700">{day}</h3>
              <div className="space-y-2">
                {periodsByDay(day).length === 0 ? (
                  <p className="text-xs text-ink-300">No periods.</p>
                ) : periodsByDay(day).map((p) => (
                  <div key={p._id} className="rounded-md bg-ink-50 p-2 text-xs">
                    <div className="flex items-start justify-between">
                      <span className="font-medium text-ink-700">{p.startTime}–{p.endTime}</span>
                      {canManage && (
                        <button onClick={() => handleRemove(p._id)} className="text-ink-300 hover:text-red-600">
                          <IoTrashOutline size={12} />
                        </button>
                      )}
                    </div>
                    <p className="text-ink-500">{p.subject?.name || '—'}</p>
                    {p.room && <p className="text-ink-400">Room {p.room}</p>}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Add Period">
        <form onSubmit={handleAdd} className="space-y-4">
          <SelectField label="Day" value={form.day} onChange={(e) => setForm({ ...form, day: e.target.value })}
            options={DAYS.map((d) => ({ value: d, label: d }))} />
          <div className="grid grid-cols-2 gap-4">
            <TextField label="Start Time" type="time" required value={form.startTime} onChange={(e) => setForm({ ...form, startTime: e.target.value })} />
            <TextField label="End Time" type="time" required value={form.endTime} onChange={(e) => setForm({ ...form, endTime: e.target.value })} />
          </div>
          <SelectField label="Subject" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })}
            options={subjects.filter((s) => !classId || s.class?._id === classId).map((s) => ({ value: s._id, label: s.name }))} />
          <TextField label="Room" value={form.room} onChange={(e) => setForm({ ...form, room: e.target.value })} />
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass">Add Period</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
