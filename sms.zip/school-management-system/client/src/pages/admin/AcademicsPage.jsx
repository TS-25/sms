import { useState } from 'react';
import { IoAddOutline, IoTrashOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import { TextField, SelectField } from '../../components/forms/FormFields';
import { academicService } from '../../services/resourceServices';
import { useAcademicLookups } from '../../hooks/useAcademicLookups';

const TABS = ['Sessions', 'Classes', 'Sections', 'Subjects'];

export default function AcademicsPage() {
  const [tab, setTab] = useState('Sessions');
  const { sessions, classes, sections, subjects, loading } = useAcademicLookups();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Classes & Subjects</h1>
        <p className="text-sm text-ink-400">Configure academic sessions, classes, sections, and subjects.</p>
      </div>

      <div className="flex gap-1 border-b border-ink-100">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 text-sm font-medium ${tab === t ? 'border-b-2 border-brass-400 text-ink-800' : 'text-ink-400 hover:text-ink-600'}`}
          >
            {t}
          </button>
        ))}
      </div>

      {loading ? (
        <p className="text-ink-400">Loading…</p>
      ) : (
        <>
          {tab === 'Sessions' && <SessionsTab data={sessions} />}
          {tab === 'Classes' && <ClassesTab data={classes} sessions={sessions} />}
          {tab === 'Sections' && <SectionsTab data={sections} classes={classes} />}
          {tab === 'Subjects' && <SubjectsTab data={subjects} classes={classes} />}
        </>
      )}
    </div>
  );
}

// Note: each tab below calls window.location.reload() after a successful
// create/delete so all tabs (and the shared lookups hook) stay in sync
// without duplicating state management logic across four small forms.
function SimpleListCard({ title, columns, rows, onAdd, onDelete }) {
  return (
    <div className="card">
      <div className="flex items-center justify-between border-b border-ink-100 p-4">
        <h3 className="font-display text-base text-ink-700">{title}</h3>
        <button className="btn-brass" onClick={onAdd}><IoAddOutline /> Add</button>
      </div>
      <table className="table-base">
        <thead>
          <tr>{columns.map((c) => <th key={c.header}>{c.header}</th>)}<th className="text-right">Actions</th></tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr><td colSpan={columns.length + 1} className="py-8 text-center text-ink-400">No records yet.</td></tr>
          ) : rows.map((r) => (
            <tr key={r._id}>
              {columns.map((c) => <td key={c.header}>{c.accessor(r)}</td>)}
              <td className="text-right">
                <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => onDelete(r)}>
                  <IoTrashOutline />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function SessionsTab({ data }) {
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ name: '', startDate: '', endDate: '', isCurrent: false });

  const submit = async (e) => {
    e.preventDefault();
    try {
      await academicService.sessions.create(form);
      toast.success('Academic session created.');
      window.location.reload();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create session.');
    }
  };

  const remove = async () => {
    await academicService.sessions.remove(deleteTarget._id);
    toast.success('Session deleted.');
    window.location.reload();
  };

  return (
    <>
      <SimpleListCard
        title="Academic Sessions"
        columns={[
          { header: 'Name', accessor: (r) => r.name },
          { header: 'Start', accessor: (r) => new Date(r.startDate).toLocaleDateString() },
          { header: 'End', accessor: (r) => new Date(r.endDate).toLocaleDateString() },
          { header: 'Current', accessor: (r) => (r.isCurrent ? 'Yes' : '—') },
        ]}
        rows={data}
        onAdd={() => setModalOpen(true)}
        onDelete={setDeleteTarget}
      />
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="New Academic Session">
        <form onSubmit={submit} className="space-y-4">
          <TextField label="Name (e.g. 2026-2027)" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <TextField label="Start Date" type="date" required value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
          <TextField label="End Date" type="date" required value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} />
          <label className="flex items-center gap-2 text-sm text-ink-600">
            <input type="checkbox" checked={form.isCurrent} onChange={(e) => setForm({ ...form, isCurrent: e.target.checked })} />
            Set as current session
          </label>
          <div className="flex justify-end gap-3"><button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button><button className="btn-brass">Create</button></div>
        </form>
      </Modal>
      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={remove} title="Delete session?" message="This cannot be undone." />
    </>
  );
}

function ClassesTab({ data, sessions }) {
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ name: '', academicSession: '' });

  const submit = async (e) => {
    e.preventDefault();
    try {
      await academicService.classes.create(form);
      toast.success('Class created.');
      window.location.reload();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create class.');
    }
  };

  const remove = async () => {
    await academicService.classes.remove(deleteTarget._id);
    toast.success('Class deleted.');
    window.location.reload();
  };

  return (
    <>
      <SimpleListCard
        title="Classes"
        columns={[
          { header: 'Name', accessor: (r) => r.name },
          { header: 'Session', accessor: (r) => r.academicSession?.name || '—' },
        ]}
        rows={data}
        onAdd={() => setModalOpen(true)}
        onDelete={setDeleteTarget}
      />
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="New Class">
        <form onSubmit={submit} className="space-y-4">
          <TextField label="Name (e.g. Class 7)" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <SelectField label="Academic Session" required value={form.academicSession} onChange={(e) => setForm({ ...form, academicSession: e.target.value })}
            options={sessions.map((s) => ({ value: s._id, label: s.name }))} />
          <div className="flex justify-end gap-3"><button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button><button className="btn-brass">Create</button></div>
        </form>
      </Modal>
      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={remove} title="Delete class?" message="Sections and subjects under this class will remain but be orphaned." />
    </>
  );
}

function SectionsTab({ data, classes }) {
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ name: '', class: '', capacity: 40 });

  const submit = async (e) => {
    e.preventDefault();
    try {
      await academicService.sections.create(form);
      toast.success('Section created.');
      window.location.reload();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create section.');
    }
  };

  const remove = async () => {
    await academicService.sections.remove(deleteTarget._id);
    toast.success('Section deleted.');
    window.location.reload();
  };

  return (
    <>
      <SimpleListCard
        title="Sections"
        columns={[
          { header: 'Name', accessor: (r) => r.name },
          { header: 'Class', accessor: (r) => r.class?.name || '—' },
          { header: 'Capacity', accessor: (r) => r.capacity },
        ]}
        rows={data}
        onAdd={() => setModalOpen(true)}
        onDelete={setDeleteTarget}
      />
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="New Section">
        <form onSubmit={submit} className="space-y-4">
          <SelectField label="Class" required value={form.class} onChange={(e) => setForm({ ...form, class: e.target.value })}
            options={classes.map((c) => ({ value: c._id, label: c.name }))} />
          <TextField label="Section Name (e.g. A)" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <TextField label="Capacity" type="number" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: e.target.value })} />
          <div className="flex justify-end gap-3"><button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button><button className="btn-brass">Create</button></div>
        </form>
      </Modal>
      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={remove} title="Delete section?" message="This cannot be undone." />
    </>
  );
}

function SubjectsTab({ data, classes }) {
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ name: '', code: '', class: '', fullMarks: 100, passMarks: 33 });

  const submit = async (e) => {
    e.preventDefault();
    try {
      await academicService.subjects.create(form);
      toast.success('Subject created.');
      window.location.reload();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create subject.');
    }
  };

  const remove = async () => {
    await academicService.subjects.remove(deleteTarget._id);
    toast.success('Subject deleted.');
    window.location.reload();
  };

  return (
    <>
      <SimpleListCard
        title="Subjects"
        columns={[
          { header: 'Name', accessor: (r) => r.name },
          { header: 'Code', accessor: (r) => r.code },
          { header: 'Class', accessor: (r) => r.class?.name || '—' },
          { header: 'Full/Pass Marks', accessor: (r) => `${r.fullMarks} / ${r.passMarks}` },
        ]}
        rows={data}
        onAdd={() => setModalOpen(true)}
        onDelete={setDeleteTarget}
      />
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="New Subject">
        <form onSubmit={submit} className="space-y-4">
          <TextField label="Name (e.g. Mathematics)" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <TextField label="Code (e.g. MATH7)" required value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} />
          <SelectField label="Class" value={form.class} onChange={(e) => setForm({ ...form, class: e.target.value })}
            options={classes.map((c) => ({ value: c._id, label: c.name }))} />
          <div className="grid grid-cols-2 gap-4">
            <TextField label="Full Marks" type="number" value={form.fullMarks} onChange={(e) => setForm({ ...form, fullMarks: e.target.value })} />
            <TextField label="Pass Marks" type="number" value={form.passMarks} onChange={(e) => setForm({ ...form, passMarks: e.target.value })} />
          </div>
          <div className="flex justify-end gap-3"><button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button><button className="btn-brass">Create</button></div>
        </form>
      </Modal>
      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={remove} title="Delete subject?" message="This cannot be undone." />
    </>
  );
}
