import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoTrashOutline, IoPencilOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import DataTable from '../../components/ui/DataTable';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import { TextField } from '../../components/forms/FormFields';
import { staffService } from '../../services/resourceServices';

const emptyForm = { firstName: '', lastName: '', email: '', employeeId: '', department: '', designation: '', phone: '', salary: '' };

export default function StaffPage() {
  const [staff, setStaff] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState(emptyForm);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await staffService.list({ search, page, limit: 10 });
      setStaff(data.data);
      setPagination(data.pagination);
    } finally {
      setLoading(false);
    }
  }, [search, page]);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => { setEditingId(null); setForm(emptyForm); setModalOpen(true); };
  const openEdit = (s) => {
    setEditingId(s._id);
    setForm({ firstName: s.firstName, lastName: s.lastName || '', email: s.email || '', employeeId: s.employeeId, department: s.department || '', designation: s.designation || '', phone: s.phone || '', salary: s.salary || '' });
    setModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        await staffService.update(editingId, form);
        toast.success('Staff member updated.');
      } else {
        await staffService.create(form);
        toast.success('Staff member added.');
      }
      setModalOpen(false);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save staff member.');
    }
  };

  const handleDelete = async () => {
    await staffService.remove(deleteTarget._id);
    toast.success('Staff member deleted.');
    setDeleteTarget(null);
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Staff</h1>
          <p className="text-sm text-ink-400">Manage non-teaching staff records.</p>
        </div>
        <button className="btn-brass" onClick={openCreate}><IoAddOutline /> Add Staff</button>
      </div>

      <DataTable
        loading={loading}
        rows={staff}
        search={search}
        onSearchChange={(v) => { setSearch(v); setPage(1); }}
        pagination={pagination}
        onPageChange={setPage}
        columns={[
          { header: 'Employee ID', accessor: (r) => r.employeeId },
          { header: 'Name', accessor: (r) => `${r.firstName} ${r.lastName || ''}` },
          { header: 'Department', accessor: (r) => r.department || '—' },
          { header: 'Designation', accessor: (r) => r.designation || '—' },
          { header: 'Phone', accessor: (r) => r.phone || '—' },
        ]}
        actions={(row) => (
          <div className="flex justify-end gap-2">
            <button className="p-1.5 text-ink-400 hover:text-ink-700" onClick={() => openEdit(row)}><IoPencilOutline /></button>
            <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(row)}><IoTrashOutline /></button>
          </div>
        )}
      />

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editingId ? 'Edit Staff' : 'Add Staff'} size="lg">
        <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <TextField label="First Name" required value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} />
          <TextField label="Last Name" value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })} />
          <TextField label="Email" type="email" required disabled={!!editingId} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <TextField label="Employee ID" required disabled={!!editingId} value={form.employeeId} onChange={(e) => setForm({ ...form, employeeId: e.target.value })} />
          <TextField label="Department" value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} />
          <TextField label="Designation" value={form.designation} onChange={(e) => setForm({ ...form, designation: e.target.value })} />
          <TextField label="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          <TextField label="Salary" type="number" value={form.salary} onChange={(e) => setForm({ ...form, salary: e.target.value })} />
          <div className="col-span-full flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass">Save Staff</button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete staff member?" message="This will permanently remove their record and login account." />
    </div>
  );
}
