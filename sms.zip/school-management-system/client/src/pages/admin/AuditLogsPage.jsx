import { useEffect, useState, useCallback } from 'react';
import DataTable from '../../components/ui/DataTable';
import { auditLogService } from '../../services/resourceServices';

export default function AuditLogsPage() {
  const [logs, setLogs] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await auditLogService.list({ page, limit: 25 });
      setLogs(data.data);
      setPagination(data.pagination);
    } finally {
      setLoading(false);
    }
  }, [page]);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Audit Logs</h1>
        <p className="text-sm text-ink-400">A record of significant actions taken across the system.</p>
      </div>

      <DataTable
        loading={loading}
        rows={logs}
        pagination={pagination}
        onPageChange={setPage}
        columns={[
          { header: 'Time', accessor: (r) => new Date(r.createdAt).toLocaleString() },
          { header: 'User', accessor: (r) => r.userLabel || '—' },
          { header: 'Action', accessor: (r) => r.action },
          { header: 'Entity', accessor: (r) => r.entity },
          { header: 'IP', accessor: (r) => r.ip || '—' },
        ]}
      />
    </div>
  );
}
