import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoCheckmarkOutline, IoCloseOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import DataTable from '../../components/ui/DataTable';
import Modal from '../../components/ui/Modal';
import { TextField, SelectField, TextAreaField } from '../../components/forms/FormFields';
import { leaveService } from '../../services/resourceServices';
import { useAuth } from '../../context/AuthContext';

const LEAVE_TYPES = ['sick', 'casual', 'earned', 'maternity', 'paternity', 'other'];

export default function LeavePage() {
  const { user } = useAuth();
  const canReview = ['super_admin', 'admin', 'principal'].includes(user?.role);
  const [leaves, setLeaves] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({ leaveType: 'casual', startDate: '', endDate: '', reason: '' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      // Non-reviewer roles only see their own leave requests.
      const params = canReview ? { page, limit: 10 } : { applicant: user._id, page, limit: 10 };
      const { data } = await leaveService.list(params);
      setLeaves(data.data);
      setPagination(data.pagination);
    } finally {
      setLoading(false);
    }
  }, [page, canReview, user]);

  useEffect(() => { load(); }, [load]);

  const handleApply = async (e) => {
    e.preventDefault();
    try {
      await leaveService.apply({ ...form, applicant: user._id, applicantModel: 'User' });
      toast.success('Leave request submitted.');
      setModalOpen(false);
      setForm({ leaveType: 'casual', startDate: '', endDate: '', reason: '' });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to submit leave request.');
    }
  };

  const handleReview = async (id, status) => {
    try {
      await leaveService.review(id, { status });
      toast.success(`Leave ${status}.`);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update leave request.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Leave Management</h1>
          <p className="text-sm text-ink-400">{canReview ? 'Review leave requests from staff and teachers.' : 'Apply for leave and track approval status.'}</p>
        </div>
        {!canReview && (
          <button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> Apply for Leave</button>
        )}
      </div>

      <DataTable
        loading={loading}
        rows={leaves}
        pagination={pagination}
        onPageChange={setPage}
        columns={[
          { header: 'Type', accessor: (r) => r.leaveType },
          { header: 'From', accessor: (r) => new Date(r.startDate).toLocaleDateString() },
          { header: 'To', accessor: (r) => new Date(r.endDate).toLocaleDateString() },
          { header: 'Reason', accessor: (r) => r.reason },
          {
            header: 'Status',
            accessor: (r) => (
              <span className={`rounded-full px-2 py-0.5 text-xs capitalize ${
                r.status === 'approved' ? 'bg-brass-50 text-brass-700' : r.status === 'rejected' ? 'bg-red-50 text-red-600' : 'bg-ink-100 text-ink-500'
              }`}>{r.status}</span>
            ),
          },
        ]}
        actions={canReview ? (row) => (
          row.status === 'pending' && (
            <div className="flex justify-end gap-2">
              <button className="p-1.5 text-brass-600 hover:bg-brass-50 rounded" onClick={() => handleReview(row._id, 'approved')}><IoCheckmarkOutline /></button>
              <button className="p-1.5 text-red-600 hover:bg-red-50 rounded" onClick={() => handleReview(row._id, 'rejected')}><IoCloseOutline /></button>
            </div>
          )
        ) : undefined}
      />

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Apply for Leave">
        <form onSubmit={handleApply} className="space-y-4">
          <SelectField label="Leave Type" value={form.leaveType} onChange={(e) => setForm({ ...form, leaveType: e.target.value })}
            options={LEAVE_TYPES.map((t) => ({ value: t, label: t[0].toUpperCase() + t.slice(1) }))} />
          <div className="grid grid-cols-2 gap-4">
            <TextField label="Start Date" type="date" required value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
            <TextField label="End Date" type="date" required value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} />
          </div>
          <TextAreaField label="Reason" required value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} />
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass">Submit Request</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
