import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { IoCloudDownloadOutline } from 'react-icons/io5';
import { SelectField, TextField } from '../../components/forms/FormFields';
import { attendanceService, studentService } from '../../services/resourceServices';
import { useAcademicLookups } from '../../hooks/useAcademicLookups';

const STATUS_OPTIONS = ['present', 'absent', 'late', 'leave'];

export default function AttendancePage() {
  const { classes, sectionsForClass } = useAcademicLookups();
  const [classId, setClassId] = useState('');
  const [sectionId, setSectionId] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [students, setStudents] = useState([]);
  const [statuses, setStatuses] = useState({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!classId || !sectionId) return;
    const load = async () => {
      setLoading(true);
      try {
        const { data } = await studentService.list({ class: classId, section: sectionId, limit: 100 });
        setStudents(data.data);
        const existing = await attendanceService.getByDate({ class: classId, section: sectionId, date });
        const map = {};
        existing.data.data.forEach((a) => { map[a.student._id] = a.status; });
        setStatuses(map);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [classId, sectionId, date]);

  const handleSave = async () => {
    const records = students.map((s) => ({ student: s._id, status: statuses[s._id] || 'present' }));
    setSaving(true);
    try {
      await attendanceService.mark({ class: classId, section: sectionId, date, records });
      toast.success('Attendance saved.');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save attendance.');
    } finally {
      setSaving(false);
    }
  };

  const handleExport = async () => {
    const { data } = await attendanceService.exportCsv({ class: classId, section: sectionId, date });
    const url = window.URL.createObjectURL(new Blob([data]));
    const link = document.createElement('a');
    link.href = url;
    link.download = `attendance-${date}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Attendance</h1>
        <p className="text-sm text-ink-400">Mark daily attendance for a class and section.</p>
      </div>

      <div className="card grid grid-cols-1 gap-4 p-5 sm:grid-cols-4">
        <SelectField label="Class" value={classId} onChange={(e) => { setClassId(e.target.value); setSectionId(''); }}
          options={classes.map((c) => ({ value: c._id, label: c.name }))} />
        <SelectField label="Section" value={sectionId} onChange={(e) => setSectionId(e.target.value)}
          options={sectionsForClass(classId).map((s) => ({ value: s._id, label: s.name }))} />
        <TextField label="Date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        <div className="flex items-end">
          <button className="btn-outline w-full" onClick={handleExport} disabled={!classId || !sectionId}>
            <IoCloudDownloadOutline /> Export CSV
          </button>
        </div>
      </div>

      {classId && sectionId && (
        <div className="card overflow-hidden">
          <table className="table-base">
            <thead>
              <tr>
                <th>Admission No.</th>
                <th>Name</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={3} className="py-8 text-center text-ink-400">Loading…</td></tr>
              ) : students.length === 0 ? (
                <tr><td colSpan={3} className="py-8 text-center text-ink-400">No students in this section.</td></tr>
              ) : (
                students.map((s) => (
                  <tr key={s._id}>
                    <td>{s.admissionNumber}</td>
                    <td>{s.firstName} {s.lastName}</td>
                    <td>
                      <div className="flex gap-1">
                        {STATUS_OPTIONS.map((opt) => (
                          <button
                            key={opt}
                            type="button"
                            onClick={() => setStatuses({ ...statuses, [s._id]: opt })}
                            className={`rounded-md px-2 py-1 text-xs capitalize ${
                              (statuses[s._id] || 'present') === opt
                                ? 'bg-brass-400 text-ink-900'
                                : 'bg-ink-50 text-ink-500 hover:bg-ink-100'
                            }`}
                          >
                            {opt}
                          </button>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
          {students.length > 0 && (
            <div className="flex justify-end border-t border-ink-100 p-4">
              <button className="btn-brass" onClick={handleSave} disabled={saving}>
                {saving ? 'Saving…' : 'Save Attendance'}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
