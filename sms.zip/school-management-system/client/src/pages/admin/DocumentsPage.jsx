import { useEffect, useState, useCallback } from 'react';
import { IoCloudUploadOutline, IoTrashOutline, IoDocumentOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import EmptyState from '../../components/ui/EmptyState';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import { SelectField } from '../../components/forms/FormFields';
import { documentService } from '../../services/resourceServices';

const CATEGORIES = ['student', 'teacher', 'staff', 'school', 'certificate', 'other'];

export default function DocumentsPage() {
  const [documents, setDocuments] = useState([]);
  const [category, setCategory] = useState('');
  const [loading, setLoading] = useState(true);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadCategory, setUploadCategory] = useState('other');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await documentService.list(category ? { category } : {});
      setDocuments(data.data);
    } finally {
      setLoading(false);
    }
  }, [category]);

  useEffect(() => { load(); }, [load]);

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    try {
      await documentService.upload(file, { title: file.name, category: uploadCategory });
      toast.success('Document uploaded.');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Upload failed.');
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const handleDelete = async () => {
    await documentService.remove(deleteTarget._id);
    toast.success('Document deleted.');
    setDeleteTarget(null);
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Documents</h1>
          <p className="text-sm text-ink-400">Upload and manage certificates, records, and school documents.</p>
        </div>
        <div className="flex gap-2">
          <SelectField label="" value={uploadCategory} onChange={(e) => setUploadCategory(e.target.value)}
            options={CATEGORIES.map((c) => ({ value: c, label: c[0].toUpperCase() + c.slice(1) }))} />
          <label className="btn-brass cursor-pointer self-end">
            <IoCloudUploadOutline /> {uploading ? 'Uploading…' : 'Upload'}
            <input type="file" className="hidden" onChange={handleUpload} disabled={uploading} />
          </label>
        </div>
      </div>

      <div className="max-w-xs">
        <SelectField label="Filter by category" value={category} onChange={(e) => setCategory(e.target.value)}
          options={CATEGORIES.map((c) => ({ value: c, label: c[0].toUpperCase() + c.slice(1) }))} />
      </div>

      {loading ? (
        <p className="text-ink-400">Loading…</p>
      ) : documents.length === 0 ? (
        <EmptyState title="No documents yet" description="Uploaded documents will appear here." />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {documents.map((doc) => (
            <div key={doc._id} className="card flex items-start justify-between p-4">
              <a href={doc.fileUrl} target="_blank" rel="noreferrer" className="flex items-start gap-3">
                <IoDocumentOutline className="mt-0.5 shrink-0 text-brass-500" size={20} />
                <div>
                  <p className="text-sm font-medium text-ink-700">{doc.title}</p>
                  <p className="text-xs text-ink-400 capitalize">{doc.category} · {new Date(doc.createdAt).toLocaleDateString()}</p>
                </div>
              </a>
              <button className="p-1 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(doc)}>
                <IoTrashOutline size={16} />
              </button>
            </div>
          ))}
        </div>
      )}

      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete document?" message="This cannot be undone." />
    </div>
  );
}
