import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoTrashOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import DataTable from '../../components/ui/DataTable';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import { TextField, SelectField } from '../../components/forms/FormFields';
import { expenseService } from '../../services/resourceServices';
import StatCard from '../../components/ui/StatCard';

const CATEGORIES = ['Utilities', 'Maintenance', 'Salaries', 'Supplies', 'Transport', 'Events', 'Other'];

export default function ExpensesPage() {
  const [expenses, setExpenses] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ category: '', description: '', amount: '', date: new Date().toISOString().slice(0, 10), paymentMethod: 'cash' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await expenseService.list({ page, limit: 10 });
      setExpenses(data.data);
      setPagination(data.pagination);
    } finally {
      setLoading(false);
    }
  }, [page]);

  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await expenseService.create(form);
      toast.success('Expense recorded.');
      setModalOpen(false);
      setForm({ category: '', description: '', amount: '', date: new Date().toISOString().slice(0, 10), paymentMethod: 'cash' });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to record expense.');
    }
  };

  const handleDelete = async () => {
    await expenseService.remove(deleteTarget._id);
    toast.success('Expense deleted.');
    setDeleteTarget(null);
    load();
  };

  const total = expenses.reduce((sum, e) => sum + e.amount, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Expenses</h1>
          <p className="text-sm text-ink-400">Track school operating costs.</p>
        </div>
        <button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> Add Expense</button>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard label="Total (this page)" value={total.toLocaleString()} />
      </div>

      <DataTable
        loading={loading}
        rows={expenses}
        pagination={pagination}
        onPageChange={setPage}
        columns={[
          { header: 'Date', accessor: (r) => new Date(r.date).toLocaleDateString() },
          { header: 'Category', accessor: (r) => r.category },
          { header: 'Description', accessor: (r) => r.description || '—' },
          { header: 'Amount', accessor: (r) => r.amount },
          { header: 'Method', accessor: (r) => r.paymentMethod },
        ]}
        actions={(row) => (
          <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(row)}>
            <IoTrashOutline />
          </button>
        )}
      />

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Add Expense">
        <form onSubmit={handleCreate} className="space-y-4">
          <SelectField label="Category" required value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}
            options={CATEGORIES.map((c) => ({ value: c, label: c }))} />
          <TextField label="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <TextField label="Amount" type="number" required value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
          <TextField label="Date" type="date" required value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
          <SelectField label="Payment Method" value={form.paymentMethod} onChange={(e) => setForm({ ...form, paymentMethod: e.target.value })}
            options={['cash', 'card', 'bank_transfer', 'cheque'].map((m) => ({ value: m, label: m }))} />
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass">Save Expense</button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete expense?" message="This cannot be undone." />
    </div>
  );
}
