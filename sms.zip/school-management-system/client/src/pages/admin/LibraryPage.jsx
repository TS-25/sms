import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoTrashOutline, IoPencilOutline, IoArrowUndoOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import DataTable from '../../components/ui/DataTable';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import { TextField, SelectField } from '../../components/forms/FormFields';
import { libraryService, studentService, teacherService } from '../../services/resourceServices';

const emptyBookForm = { title: '', author: '', isbn: '', category: '', publisher: '', quantity: 1, shelfLocation: '' };

export default function LibraryPage() {
  const [tab, setTab] = useState('Books');

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Library</h1>
        <p className="text-sm text-ink-400">Manage books, issue and return records.</p>
      </div>

      <div className="flex gap-1 border-b border-ink-100">
        {['Books', 'Issue / Return'].map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 text-sm font-medium ${tab === t ? 'border-b-2 border-brass-400 text-ink-800' : 'text-ink-400 hover:text-ink-600'}`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === 'Books' ? <BooksTab /> : <TransactionsTab />}
    </div>
  );
}

function BooksTab() {
  const [books, setBooks] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState(emptyBookForm);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await libraryService.books.list({ search, page, limit: 10 });
      setBooks(data.data);
      setPagination(data.pagination);
    } finally {
      setLoading(false);
    }
  }, [search, page]);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => { setEditingId(null); setForm(emptyBookForm); setModalOpen(true); };
  const openEdit = (b) => {
    setEditingId(b._id);
    setForm({ title: b.title, author: b.author || '', isbn: b.isbn || '', category: b.category || '', publisher: b.publisher || '', quantity: b.quantity, shelfLocation: b.shelfLocation || '' });
    setModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        await libraryService.books.update(editingId, form);
        toast.success('Book updated.');
      } else {
        await libraryService.books.create(form);
        toast.success('Book added.');
      }
      setModalOpen(false);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save book.');
    }
  };

  const handleDelete = async () => {
    await libraryService.books.remove(deleteTarget._id);
    toast.success('Book deleted.');
    setDeleteTarget(null);
    load();
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <button className="btn-brass" onClick={openCreate}><IoAddOutline /> Add Book</button>
      </div>

      <DataTable
        loading={loading}
        rows={books}
        search={search}
        onSearchChange={(v) => { setSearch(v); setPage(1); }}
        searchPlaceholder="Search by title, author, or ISBN…"
        pagination={pagination}
        onPageChange={setPage}
        columns={[
          { header: 'Title', accessor: (r) => r.title },
          { header: 'Author', accessor: (r) => r.author || '—' },
          { header: 'ISBN', accessor: (r) => r.isbn || '—' },
          { header: 'Available', accessor: (r) => `${r.availableQuantity} / ${r.quantity}` },
        ]}
        actions={(row) => (
          <div className="flex justify-end gap-2">
            <button className="p-1.5 text-ink-400 hover:text-ink-700" onClick={() => openEdit(row)}><IoPencilOutline /></button>
            <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(row)}><IoTrashOutline /></button>
          </div>
        )}
      />

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editingId ? 'Edit Book' : 'Add Book'} size="lg">
        <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <TextField label="Title" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <TextField label="Author" value={form.author} onChange={(e) => setForm({ ...form, author: e.target.value })} />
          <TextField label="ISBN" value={form.isbn} onChange={(e) => setForm({ ...form, isbn: e.target.value })} />
          <TextField label="Category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />
          <TextField label="Publisher" value={form.publisher} onChange={(e) => setForm({ ...form, publisher: e.target.value })} />
          <TextField label="Quantity" type="number" min={0} value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} />
          <TextField label="Shelf Location" value={form.shelfLocation} onChange={(e) => setForm({ ...form, shelfLocation: e.target.value })} />
          <div className="col-span-full flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass">Save Book</button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete book?" message="This cannot be undone." />
    </div>
  );
}

function TransactionsTab() {
  const [transactions, setTransactions] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [issueOpen, setIssueOpen] = useState(false);
  const [books, setBooks] = useState([]);
  const [borrowerQuery, setBorrowerQuery] = useState('');
  const [borrowerOptions, setBorrowerOptions] = useState([]);
  const [form, setForm] = useState({ book: '', borrower: '', borrowerModel: 'Student', dueDate: '', fineRatePerDay: 1 });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await libraryService.transactions({ page, limit: 10 });
      setTransactions(data.data);
      setPagination(data.pagination);
    } finally {
      setLoading(false);
    }
  }, [page]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    libraryService.books.list({ limit: 100 }).then(({ data }) => setBooks(data.data.filter((b) => b.availableQuantity > 0)));
  }, [issueOpen]);

  useEffect(() => {
    if (borrowerQuery.length < 2) { setBorrowerOptions([]); return; }
    const t = setTimeout(async () => {
      const svc = form.borrowerModel === 'Student' ? studentService : teacherService;
      const { data } = await svc.list({ search: borrowerQuery, limit: 10 });
      setBorrowerOptions(data.data);
    }, 300);
    return () => clearTimeout(t);
  }, [borrowerQuery, form.borrowerModel]);

  const handleIssue = async (e) => {
    e.preventDefault();
    try {
      await libraryService.issue(form);
      toast.success('Book issued.');
      setIssueOpen(false);
      setForm({ book: '', borrower: '', borrowerModel: 'Student', dueDate: '', fineRatePerDay: 1 });
      setBorrowerQuery('');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to issue book.');
    }
  };

  const handleReturn = async (transactionId) => {
    try {
      const { data } = await libraryService.return(transactionId);
      toast.success(data.data.fineAmount > 0 ? `Returned. Fine: ${data.data.fineAmount}` : 'Returned — no fine.');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to process return.');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <button className="btn-brass" onClick={() => setIssueOpen(true)}><IoAddOutline /> Issue Book</button>
      </div>

      <DataTable
        loading={loading}
        rows={transactions}
        pagination={pagination}
        onPageChange={setPage}
        columns={[
          { header: 'Book', accessor: (r) => r.book?.title },
          { header: 'Borrower Type', accessor: (r) => r.borrowerModel },
          { header: 'Issue Date', accessor: (r) => new Date(r.issueDate).toLocaleDateString() },
          { header: 'Due Date', accessor: (r) => new Date(r.dueDate).toLocaleDateString() },
          {
            header: 'Status',
            accessor: (r) => (
              <span className={`rounded-full px-2 py-0.5 text-xs capitalize ${r.status === 'returned' ? 'bg-brass-50 text-brass-700' : 'bg-amber-50 text-amber-700'}`}>
                {r.status}
              </span>
            ),
          },
          { header: 'Fine', accessor: (r) => r.fineAmount || '—' },
        ]}
        actions={(row) => (
          row.status !== 'returned' && (
            <button className="btn-outline px-3 py-1 text-xs" onClick={() => handleReturn(row._id)}>
              <IoArrowUndoOutline /> Return
            </button>
          )
        )}
      />

      <Modal isOpen={issueOpen} onClose={() => setIssueOpen(false)} title="Issue Book" size="lg">
        <form onSubmit={handleIssue} className="space-y-4">
          <SelectField label="Book" required value={form.book} onChange={(e) => setForm({ ...form, book: e.target.value })}
            options={books.map((b) => ({ value: b._id, label: `${b.title} (${b.availableQuantity} available)` }))} />
          <SelectField label="Borrower Type" value={form.borrowerModel} onChange={(e) => { setForm({ ...form, borrowerModel: e.target.value, borrower: '' }); setBorrowerQuery(''); }}
            options={[{ value: 'Student', label: 'Student' }, { value: 'Teacher', label: 'Teacher' }]} />
          <div>
            <label className="label">Borrower</label>
            <input className="input" placeholder="Search by name…" value={borrowerQuery} onChange={(e) => setBorrowerQuery(e.target.value)} />
            {borrowerOptions.length > 0 && (
              <div className="mt-1 max-h-40 overflow-y-auto rounded-md border border-ink-100 bg-white shadow-sm">
                {borrowerOptions.map((b) => (
                  <button
                    type="button"
                    key={b._id}
                    className="block w-full px-3 py-2 text-left text-sm hover:bg-ink-50"
                    onClick={() => { setForm({ ...form, borrower: b._id }); setBorrowerQuery(`${b.firstName} ${b.lastName || ''}`); setBorrowerOptions([]); }}
                  >
                    {b.firstName} {b.lastName}
                  </button>
                ))}
              </div>
            )}
          </div>
          <TextField label="Due Date" type="date" required value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} />
          <TextField label="Fine Rate / Day" type="number" value={form.fineRatePerDay} onChange={(e) => setForm({ ...form, fineRatePerDay: e.target.value })} />
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setIssueOpen(false)}>Cancel</button>
            <button className="btn-brass" disabled={!form.borrower}>Issue Book</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
