import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoCashOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import DataTable from '../../components/ui/DataTable';
import Modal from '../../components/ui/Modal';
import { TextField, SelectField } from '../../components/forms/FormFields';
import { feeService, studentService } from '../../services/resourceServices';
import { getAccessToken } from '../../services/api';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const CATEGORY_OPTIONS = ['tuition', 'admission', 'exam', 'library', 'transport', 'hostel', 'other'].map((c) => ({
  value: c, label: c[0].toUpperCase() + c.slice(1),
}));

export default function FeesPage() {
  const [fees, setFees] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [payOpen, setPayOpen] = useState(null);
  const [studentQuery, setStudentQuery] = useState('');
  const [studentOptions, setStudentOptions] = useState([]);
  const [form, setForm] = useState({ student: '', category: 'tuition', title: '', amount: '', discount: 0, dueDate: '' });
  const [payForm, setPayForm] = useState({ amount: '', method: 'cash', notes: '' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await feeService.list({ page, limit: 10 });
      setFees(data.data);
      setPagination(data.pagination);
    } finally {
      setLoading(false);
    }
  }, [page]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (studentQuery.length < 2) { setStudentOptions([]); return; }
    const t = setTimeout(async () => {
      const { data } = await studentService.list({ search: studentQuery, limit: 10 });
      setStudentOptions(data.data);
    }, 300);
    return () => clearTimeout(t);
  }, [studentQuery]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await feeService.create(form);
      toast.success('Fee invoice created.');
      setCreateOpen(false);
      setForm({ student: '', category: 'tuition', title: '', amount: '', discount: 0, dueDate: '' });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create fee.');
    }
  };

  const handlePayment = async (e) => {
    e.preventDefault();
    try {
      await feeService.recordPayment({ fee: payOpen._id, ...payForm });
      toast.success('Payment recorded.');
      setPayOpen(null);
      setPayForm({ amount: '', method: 'cash', notes: '' });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to record payment.');
    }
  };

  const downloadReceipt = async (paymentId) => {
    const token = getAccessToken();
    const url = `${API_URL}${feeService.receiptUrl(paymentId)}`;
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    const blob = await res.blob();
    window.open(window.URL.createObjectURL(blob));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Fees</h1>
          <p className="text-sm text-ink-400">Manage invoices, collect payments, and issue receipts.</p>
        </div>
        <button className="btn-brass" onClick={() => setCreateOpen(true)}><IoAddOutline /> New Invoice</button>
      </div>

      <DataTable
        loading={loading}
        rows={fees}
        pagination={pagination}
        onPageChange={setPage}
        columns={[
          { header: 'Student', accessor: (r) => `${r.student?.firstName} ${r.student?.lastName || ''}` },
          { header: 'Title', accessor: (r) => r.title },
          { header: 'Category', accessor: (r) => r.category },
          { header: 'Amount', accessor: (r) => r.amount },
          { header: 'Paid', accessor: (r) => r.amountPaid },
          { header: 'Due', accessor: (r) => r.amountDue },
          {
            header: 'Status',
            accessor: (r) => (
              <span className={`rounded-full px-2 py-0.5 text-xs capitalize ${
                r.status === 'paid' ? 'bg-brass-50 text-brass-700' : r.status === 'partial' ? 'bg-amber-50 text-amber-700' : 'bg-red-50 text-red-600'
              }`}>{r.status}</span>
            ),
          },
        ]}
        actions={(row) => (
          row.status !== 'paid' && (
            <button className="btn-outline px-3 py-1 text-xs" onClick={() => setPayOpen(row)}>
              <IoCashOutline /> Record Payment
            </button>
          )
        )}
      />

      <Modal isOpen={createOpen} onClose={() => setCreateOpen(false)} title="New Fee Invoice" size="lg">
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="label">Student</label>
            <input className="input" placeholder="Search by name or admission number…" value={studentQuery} onChange={(e) => setStudentQuery(e.target.value)} />
            {studentOptions.length > 0 && (
              <div className="mt-1 max-h-40 overflow-y-auto rounded-md border border-ink-100 bg-white shadow-sm">
                {studentOptions.map((s) => (
                  <button
                    type="button"
                    key={s._id}
                    className="block w-full px-3 py-2 text-left text-sm hover:bg-ink-50"
                    onClick={() => { setForm({ ...form, student: s._id }); setStudentQuery(`${s.firstName} ${s.lastName || ''} (${s.admissionNumber})`); setStudentOptions([]); }}
                  >
                    {s.firstName} {s.lastName} — {s.admissionNumber}
                  </button>
                ))}
              </div>
            )}
          </div>
          <SelectField label="Category" required value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} options={CATEGORY_OPTIONS} />
          <TextField label="Title (e.g. Term 1 Tuition)" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <div className="grid grid-cols-2 gap-4">
            <TextField label="Amount" type="number" required value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
            <TextField label="Discount" type="number" value={form.discount} onChange={(e) => setForm({ ...form, discount: e.target.value })} />
          </div>
          <TextField label="Due Date" type="date" required value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} />
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setCreateOpen(false)}>Cancel</button>
            <button className="btn-brass" disabled={!form.student}>Create Invoice</button>
          </div>
        </form>
      </Modal>

      {payOpen && (
        <Modal isOpen onClose={() => setPayOpen(null)} title={`Record Payment — ${payOpen.title}`}>
          <form onSubmit={handlePayment} className="space-y-4">
            <p className="text-sm text-ink-500">Amount due: <strong>{payOpen.amountDue}</strong></p>
            <TextField label="Amount" type="number" required max={payOpen.amountDue} value={payForm.amount} onChange={(e) => setPayForm({ ...payForm, amount: e.target.value })} />
            <SelectField label="Method" value={payForm.method} onChange={(e) => setPayForm({ ...payForm, method: e.target.value })}
              options={['cash', 'card', 'bank_transfer', 'online', 'cheque'].map((m) => ({ value: m, label: m }))} />
            <TextField label="Notes" value={payForm.notes} onChange={(e) => setPayForm({ ...payForm, notes: e.target.value })} />
            <div className="flex justify-end gap-3">
              <button type="button" className="btn-outline" onClick={() => setPayOpen(null)}>Cancel</button>
              <button className="btn-brass">Record Payment</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
