import { useEffect, useState } from 'react';
import { Bar, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement, ArcElement, Tooltip, Legend,
} from 'chart.js';
import { dashboardService, settingsService } from '../../services/resourceServices';
import StatCard from '../../components/ui/StatCard';
import FullPageLoader from '../../components/ui/FullPageLoader';

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Tooltip, Legend);

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [currency, setCurrency] = useState('USD');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [statsRes, settingsRes] = await Promise.all([
          dashboardService.admin(),
          settingsService.get(),
        ]);
        setStats(statsRes.data.data);
        setCurrency(settingsRes.data.data.currency || 'USD');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  if (loading) return <FullPageLoader />;
  if (!stats) return null;

  const { totals, todayAttendance, finance, recentAdmissions, upcomingExams, upcomingNotices } = stats;

  const attendanceData = {
    labels: ['Present', 'Absent', 'Late', 'Leave'],
    datasets: [
      {
        data: [todayAttendance.present, todayAttendance.absent, todayAttendance.late, todayAttendance.leave],
        backgroundColor: ['#C99529', '#454C3E', '#DDAE4D', '#9DA394'],
        borderWidth: 0,
      },
    ],
  };

  const financeData = {
    labels: ['This Month'],
    datasets: [
      { label: 'Collected', data: [finance.monthlyCollection], backgroundColor: '#C99529' },
      { label: 'Expenses', data: [finance.monthlyExpense], backgroundColor: '#454C3E' },
    ],
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Overview</h1>
        <p className="text-sm text-ink-400">A snapshot of today's school activity.</p>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Total Students" value={totals.totalStudents} />
        <StatCard label="Total Teachers" value={totals.totalTeachers} />
        <StatCard label="Total Staff" value={totals.totalStaff} />
        <StatCard label="Total Classes" value={totals.totalClasses} />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <StatCard
          label="Fee Collected (This Month)"
          value={`${currency} ${finance.monthlyCollection.toLocaleString()}`}
          accent
        />
        <StatCard label="Pending Fees" value={`${currency} ${finance.pendingFees.toLocaleString()}`} />
        <StatCard
          label="Net Balance (This Month)"
          value={`${currency} ${finance.netBalance.toLocaleString()}`}
        />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="card p-5">
          <h3 className="mb-4 font-display text-lg text-ink-700">Today's Attendance</h3>
          <div className="mx-auto max-w-xs">
            <Doughnut data={attendanceData} options={{ plugins: { legend: { position: 'bottom' } } }} />
          </div>
        </div>
        <div className="card p-5">
          <h3 className="mb-4 font-display text-lg text-ink-700">Collections vs Expenses</h3>
          <Bar data={financeData} options={{ plugins: { legend: { position: 'bottom' } } }} />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="card p-5">
          <h3 className="mb-3 font-display text-base text-ink-700">Recent Admissions</h3>
          <ul className="space-y-2 text-sm">
            {recentAdmissions.length === 0 && <li className="text-ink-400">No recent admissions.</li>}
            {recentAdmissions.map((s) => (
              <li key={s._id} className="flex justify-between border-b border-ink-50 pb-2">
                <span>{s.firstName} {s.lastName}</span>
                <span className="text-ink-400">{s.admissionNumber}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="card p-5">
          <h3 className="mb-3 font-display text-base text-ink-700">Upcoming Exams</h3>
          <ul className="space-y-2 text-sm">
            {upcomingExams.length === 0 && <li className="text-ink-400">No upcoming exams.</li>}
            {upcomingExams.map((e) => (
              <li key={e._id} className="border-b border-ink-50 pb-2">{e.name}</li>
            ))}
          </ul>
        </div>
        <div className="card p-5">
          <h3 className="mb-3 font-display text-base text-ink-700">Recent Notices</h3>
          <ul className="space-y-2 text-sm">
            {upcomingNotices.length === 0 && <li className="text-ink-400">No notices yet.</li>}
            {upcomingNotices.map((n) => (
              <li key={n._id} className="flex justify-between border-b border-ink-50 pb-2">
                <span>{n.title}</span>
                <span className="text-ink-400">{new Date(n.publishDate).toLocaleDateString()}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
