import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoTrashOutline, IoCalendarOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import EmptyState from '../../components/ui/EmptyState';
import { TextField, SelectField, TextAreaField } from '../../components/forms/FormFields';
import { eventService } from '../../services/resourceServices';
import { useAuth } from '../../context/AuthContext';

const EVENT_TYPES = ['event', 'holiday', 'exam', 'meeting', 'parent_teacher_meeting', 'activity'];
const TYPE_LABELS = {
  event: 'Event', holiday: 'Holiday', exam: 'Exam', meeting: 'Meeting',
  parent_teacher_meeting: 'Parent-Teacher Meeting', activity: 'Activity',
};
const TYPE_COLORS = {
  event: 'bg-brass-50 text-brass-700',
  holiday: 'bg-red-50 text-red-600',
  exam: 'bg-amber-50 text-amber-700',
  meeting: 'bg-ink-100 text-ink-600',
  parent_teacher_meeting: 'bg-blue-50 text-blue-700',
  activity: 'bg-green-50 text-green-700',
};

export default function EventsPage() {
  const { user } = useAuth();
  const canManage = ['super_admin', 'admin', 'principal', 'teacher'].includes(user?.role);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ title: '', description: '', type: 'event', startDate: '', endDate: '', location: '', allDay: true });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await eventService.list();
      setEvents(data.data);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await eventService.create(form);
      toast.success('Event added to calendar.');
      setModalOpen(false);
      setForm({ title: '', description: '', type: 'event', startDate: '', endDate: '', location: '', allDay: true });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to add event.');
    }
  };

  const handleDelete = async () => {
    await eventService.remove(deleteTarget._id);
    toast.success('Event deleted.');
    setDeleteTarget(null);
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Events & Calendar</h1>
          <p className="text-sm text-ink-400">Holidays, exams, meetings, and school activities.</p>
        </div>
        {canManage && (
          <button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> Add Event</button>
        )}
      </div>

      {loading ? (
        <p className="text-ink-400">Loading…</p>
      ) : events.length === 0 ? (
        <EmptyState title="No events scheduled" description="Upcoming events and holidays will appear here." />
      ) : (
        <div className="space-y-3">
          {events.map((ev) => (
            <div key={ev._id} className="card flex items-start justify-between gap-4 p-5">
              <div className="flex gap-3">
                <IoCalendarOutline className="mt-1 shrink-0 text-brass-500" size={20} />
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-display text-base text-ink-800">{ev.title}</h3>
                    <span className={`rounded-full px-2 py-0.5 text-xs ${TYPE_COLORS[ev.type]}`}>{TYPE_LABELS[ev.type]}</span>
                  </div>
                  {ev.description && <p className="mt-1 text-sm text-ink-500">{ev.description}</p>}
                  <p className="mt-2 text-xs text-ink-300">
                    {new Date(ev.startDate).toLocaleDateString()}
                    {ev.endDate && ` — ${new Date(ev.endDate).toLocaleDateString()}`}
                    {ev.location && ` · ${ev.location}`}
                  </p>
                </div>
              </div>
              {canManage && (
                <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(ev)}>
                  <IoTrashOutline />
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Add Event" size="lg">
        <form onSubmit={handleCreate} className="space-y-4">
          <TextField label="Title" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <TextAreaField label="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <SelectField label="Type" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}
            options={EVENT_TYPES.map((t) => ({ value: t, label: TYPE_LABELS[t] }))} />
          <div className="grid grid-cols-2 gap-4">
            <TextField label="Start Date" type="date" required value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
            <TextField label="End Date (optional)" type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} />
          </div>
          <TextField label="Location" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} />
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass">Add to Calendar</button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete event?" message="This cannot be undone." />
    </div>
  );
}
