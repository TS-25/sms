import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoTrashOutline, IoDownloadOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import EmptyState from '../../components/ui/EmptyState';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import { TextField, SelectField, TextAreaField } from '../../components/forms/FormFields';
import { certificateService, studentService } from '../../services/resourceServices';
import { openPdf } from '../../utils/openPdf';

const CERT_TYPES = ['character', 'transfer', 'participation', 'achievement', 'bonafide', 'other'];

const TEMPLATE_BODY = {
  character: 'This is to certify that {{studentName}} has been a student of good moral character during their time at this school, and has consistently demonstrated discipline, integrity, and respect for others.',
  transfer: 'This is to certify that {{studentName}} has been a bona fide student of this school and is being transferred at the request of their guardian. All dues have been cleared.',
  bonafide: 'This is to certify that {{studentName}} is a bona fide student of this school, currently enrolled in the current academic session.',
  participation: 'This certificate is proudly presented to {{studentName}} for their enthusiastic participation in the school activity.',
  achievement: 'This certificate is proudly presented to {{studentName}} in recognition of their outstanding achievement.',
  other: '',
};

export default function CertificatesPage() {
  const [certificates, setCertificates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [studentQuery, setStudentQuery] = useState('');
  const [studentOptions, setStudentOptions] = useState([]);
  const [form, setForm] = useState({ student: '', type: 'bonafide', title: '', body: TEMPLATE_BODY.bonafide });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await certificateService.list();
      setCertificates(data.data);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (studentQuery.length < 2) { setStudentOptions([]); return; }
    const t = setTimeout(async () => {
      const { data } = await studentService.list({ search: studentQuery, limit: 10 });
      setStudentOptions(data.data);
    }, 300);
    return () => clearTimeout(t);
  }, [studentQuery]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await certificateService.create(form);
      toast.success('Certificate issued.');
      setModalOpen(false);
      setForm({ student: '', type: 'bonafide', title: '', body: TEMPLATE_BODY.bonafide });
      setStudentQuery('');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to issue certificate.');
    }
  };

  const handleDelete = async () => {
    await certificateService.remove(deleteTarget._id);
    toast.success('Certificate deleted.');
    setDeleteTarget(null);
    load();
  };

  const handleDownload = (id) => {
    openPdf(certificateService.pdfUrl(id)).catch(() => toast.error('Failed to generate PDF.'));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Certificates</h1>
          <p className="text-sm text-ink-400">Issue and download student certificates.</p>
        </div>
        <button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> Issue Certificate</button>
      </div>

      {loading ? (
        <p className="text-ink-400">Loading…</p>
      ) : certificates.length === 0 ? (
        <EmptyState title="No certificates issued yet" />
      ) : (
        <div className="card overflow-hidden">
          <table className="table-base">
            <thead><tr><th>Student</th><th>Type</th><th>Title</th><th>Cert. No.</th><th>Date</th><th className="text-right">Actions</th></tr></thead>
            <tbody>
              {certificates.map((c) => (
                <tr key={c._id}>
                  <td>{c.student?.firstName} {c.student?.lastName}</td>
                  <td className="capitalize">{c.type}</td>
                  <td>{c.title}</td>
                  <td>{c.certificateNumber}</td>
                  <td>{new Date(c.issueDate).toLocaleDateString()}</td>
                  <td className="flex justify-end gap-2">
                    <button className="p-1.5 text-ink-400 hover:text-ink-700" onClick={() => handleDownload(c._id)}><IoDownloadOutline /></button>
                    <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(c)}><IoTrashOutline /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Issue Certificate" size="lg">
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="label">Student</label>
            <input className="input" placeholder="Search by name or admission number…" value={studentQuery} onChange={(e) => setStudentQuery(e.target.value)} />
            {studentOptions.length > 0 && (
              <div className="mt-1 max-h-40 overflow-y-auto rounded-md border border-ink-100 bg-white shadow-sm">
                {studentOptions.map((s) => (
                  <button type="button" key={s._id} className="block w-full px-3 py-2 text-left text-sm hover:bg-ink-50"
                    onClick={() => { setForm({ ...form, student: s._id }); setStudentQuery(`${s.firstName} ${s.lastName || ''}`); setStudentOptions([]); }}>
                    {s.firstName} {s.lastName} — {s.admissionNumber}
                  </button>
                ))}
              </div>
            )}
          </div>
          <SelectField label="Type" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value, body: TEMPLATE_BODY[e.target.value] || '' })}
            options={CERT_TYPES.map((t) => ({ value: t, label: t[0].toUpperCase() + t.slice(1) }))} />
          <TextField label="Title (e.g. Character Certificate)" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <TextAreaField label="Body (use {{studentName}} as placeholder)" required rows={5} value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} />
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass" disabled={!form.student}>Issue Certificate</button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete certificate?" message="This cannot be undone." />
    </div>
  );
}
