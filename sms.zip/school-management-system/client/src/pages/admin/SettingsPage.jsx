import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { TextField, SelectField } from '../../components/forms/FormFields';
import { settingsService } from '../../services/resourceServices';
import FullPageLoader from '../../components/ui/FullPageLoader';

export default function SettingsPage() {
  const [form, setForm] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    settingsService.get().then(({ data }) => setForm(data.data));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await settingsService.update(form);
      toast.success('Settings saved.');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save settings.');
    } finally {
      setSaving(false);
    }
  };

  if (!form) return <FullPageLoader />;

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">School Settings</h1>
        <p className="text-sm text-ink-400">Configure your school's identity and system preferences.</p>
      </div>

      <form onSubmit={handleSubmit} className="card grid grid-cols-1 gap-4 p-6 sm:grid-cols-2">
        <TextField label="School Name" value={form.schoolName || ''} onChange={(e) => setForm({ ...form, schoolName: e.target.value })} />
        <TextField label="Logo URL" value={form.logoUrl || ''} onChange={(e) => setForm({ ...form, logoUrl: e.target.value })} />
        <TextField label="Address" value={form.address || ''} onChange={(e) => setForm({ ...form, address: e.target.value })} />
        <TextField label="Phone" value={form.phone || ''} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        <TextField label="Email" type="email" value={form.email || ''} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <TextField label="Website" value={form.website || ''} onChange={(e) => setForm({ ...form, website: e.target.value })} />
        <TextField label="Currency (e.g. USD)" value={form.currency || ''} onChange={(e) => setForm({ ...form, currency: e.target.value })} />
        <SelectField label="Date Format" value={form.dateFormat || ''} onChange={(e) => setForm({ ...form, dateFormat: e.target.value })}
          options={[{ value: 'DD/MM/YYYY', label: 'DD/MM/YYYY' }, { value: 'MM/DD/YYYY', label: 'MM/DD/YYYY' }, { value: 'YYYY-MM-DD', label: 'YYYY-MM-DD' }]} />
        <TextField label="Timezone" value={form.timezone || ''} onChange={(e) => setForm({ ...form, timezone: e.target.value })} />

        <div className="col-span-full flex justify-end">
          <button className="btn-brass" disabled={saving}>{saving ? 'Saving…' : 'Save Settings'}</button>
        </div>
      </form>
    </div>
  );
}
