import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoTrashOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import { TextField, SelectField } from '../../components/forms/FormFields';
import { transportService, studentService } from '../../services/resourceServices';

export default function TransportPage() {
  const [tab, setTab] = useState('Vehicles');

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Transport</h1>
        <p className="text-sm text-ink-400">Manage vehicles, routes, and student transport assignments.</p>
      </div>

      <div className="flex gap-1 border-b border-ink-100">
        {['Vehicles', 'Routes', 'Assignments'].map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 text-sm font-medium ${tab === t ? 'border-b-2 border-brass-400 text-ink-800' : 'text-ink-400 hover:text-ink-600'}`}>
            {t}
          </button>
        ))}
      </div>

      {tab === 'Vehicles' && <VehiclesTab />}
      {tab === 'Routes' && <RoutesTab />}
      {tab === 'Assignments' && <AssignmentsTab />}
    </div>
  );
}

function VehiclesTab() {
  const [vehicles, setVehicles] = useState([]);
  const [routes, setRoutes] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ vehicleNumber: '', model: '', capacity: 40, driverName: '', driverPhone: '', route: '' });

  const load = useCallback(async () => {
    const [v, r] = await Promise.all([transportService.vehicles.list(), transportService.routes.list()]);
    setVehicles(v.data.data);
    setRoutes(r.data.data);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await transportService.vehicles.create(form);
      toast.success('Vehicle added.');
      setModalOpen(false);
      setForm({ vehicleNumber: '', model: '', capacity: 40, driverName: '', driverPhone: '', route: '' });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to add vehicle.');
    }
  };

  const handleDelete = async () => {
    await transportService.vehicles.remove(deleteTarget._id);
    toast.success('Vehicle deleted.');
    setDeleteTarget(null);
    load();
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> Add Vehicle</button>
      </div>
      <div className="card overflow-hidden">
        <table className="table-base">
          <thead><tr><th>Vehicle No.</th><th>Model</th><th>Driver</th><th>Route</th><th>Status</th><th className="text-right">Actions</th></tr></thead>
          <tbody>
            {vehicles.length === 0 ? (
              <tr><td colSpan={6} className="py-8 text-center text-ink-400">No vehicles yet.</td></tr>
            ) : vehicles.map((v) => (
              <tr key={v._id}>
                <td>{v.vehicleNumber}</td>
                <td>{v.model || '—'}</td>
                <td>{v.driverName || '—'}</td>
                <td>{v.route?.name || '—'}</td>
                <td className="capitalize">{v.status}</td>
                <td className="text-right">
                  <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(v)}><IoTrashOutline /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Add Vehicle" size="lg">
        <form onSubmit={handleCreate} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <TextField label="Vehicle Number" required value={form.vehicleNumber} onChange={(e) => setForm({ ...form, vehicleNumber: e.target.value })} />
          <TextField label="Model" value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} />
          <TextField label="Capacity" type="number" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: e.target.value })} />
          <SelectField label="Route" value={form.route} onChange={(e) => setForm({ ...form, route: e.target.value })}
            options={routes.map((r) => ({ value: r._id, label: r.name }))} />
          <TextField label="Driver Name" value={form.driverName} onChange={(e) => setForm({ ...form, driverName: e.target.value })} />
          <TextField label="Driver Phone" value={form.driverPhone} onChange={(e) => setForm({ ...form, driverPhone: e.target.value })} />
          <div className="col-span-full flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass">Save Vehicle</button>
          </div>
        </form>
      </Modal>
      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete vehicle?" message="This cannot be undone." />
    </div>
  );
}

function RoutesTab() {
  const [routes, setRoutes] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ name: '', stops: [{ name: '', pickupTime: '', dropTime: '', fare: 0 }] });

  const load = useCallback(async () => {
    const { data } = await transportService.routes.list();
    setRoutes(data.data);
  }, []);

  useEffect(() => { load(); }, [load]);

  const updateStop = (idx, field, value) => {
    const stops = [...form.stops];
    stops[idx] = { ...stops[idx], [field]: value };
    setForm({ ...form, stops });
  };

  const addStop = () => setForm({ ...form, stops: [...form.stops, { name: '', pickupTime: '', dropTime: '', fare: 0 }] });
  const removeStop = (idx) => setForm({ ...form, stops: form.stops.filter((_, i) => i !== idx) });

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await transportService.routes.create(form);
      toast.success('Route created.');
      setModalOpen(false);
      setForm({ name: '', stops: [{ name: '', pickupTime: '', dropTime: '', fare: 0 }] });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create route.');
    }
  };

  const handleDelete = async () => {
    await transportService.routes.remove(deleteTarget._id);
    toast.success('Route deleted.');
    setDeleteTarget(null);
    load();
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> Add Route</button>
      </div>

      {routes.length === 0 ? (
        <div className="card p-8 text-center text-ink-400">No routes created yet.</div>
      ) : (
        <div className="space-y-3">
          {routes.map((r) => (
            <div key={r._id} className="card p-5">
              <div className="mb-2 flex items-center justify-between">
                <h3 className="font-display text-base text-ink-800">{r.name}</h3>
                <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(r)}><IoTrashOutline /></button>
              </div>
              <div className="flex flex-wrap gap-2">
                {r.stops.map((s) => (
                  <span key={s._id} className="rounded-md bg-ink-50 px-2 py-1 text-xs text-ink-600">
                    {s.name} · {s.pickupTime || '—'} · Fare {s.fare}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Add Route" size="lg">
        <form onSubmit={handleCreate} className="space-y-4">
          <TextField label="Route Name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <div>
            <p className="label">Stops</p>
            <div className="space-y-3">
              {form.stops.map((stop, idx) => (
                <div key={idx} className="grid grid-cols-2 gap-2 rounded-md border border-ink-100 p-3 sm:grid-cols-5">
                  <TextField label="Stop Name" value={stop.name} onChange={(e) => updateStop(idx, 'name', e.target.value)} />
                  <TextField label="Pickup" type="time" value={stop.pickupTime} onChange={(e) => updateStop(idx, 'pickupTime', e.target.value)} />
                  <TextField label="Drop" type="time" value={stop.dropTime} onChange={(e) => updateStop(idx, 'dropTime', e.target.value)} />
                  <TextField label="Fare" type="number" value={stop.fare} onChange={(e) => updateStop(idx, 'fare', e.target.value)} />
                  <div className="flex items-end">
                    <button type="button" className="btn-outline w-full" onClick={() => removeStop(idx)}>Remove</button>
                  </div>
                </div>
              ))}
            </div>
            <button type="button" className="btn-outline mt-2" onClick={addStop}>+ Add Stop</button>
          </div>
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass">Save Route</button>
          </div>
        </form>
      </Modal>
      <ConfirmDialog isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete route?" message="This cannot be undone." />
    </div>
  );
}

function AssignmentsTab() {
  const [assignments, setAssignments] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [routes, setRoutes] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [studentQuery, setStudentQuery] = useState('');
  const [studentOptions, setStudentOptions] = useState([]);
  const [form, setForm] = useState({ student: '', vehicle: '', route: '', stopId: '', monthlyFee: 0 });

  const load = useCallback(async () => {
    const [a, v, r] = await Promise.all([
      transportService.assignments.list(),
      transportService.vehicles.list(),
      transportService.routes.list(),
    ]);
    setAssignments(a.data.data);
    setVehicles(v.data.data);
    setRoutes(r.data.data);
  }, []);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (studentQuery.length < 2) { setStudentOptions([]); return; }
    const t = setTimeout(async () => {
      const { data } = await studentService.list({ search: studentQuery, limit: 10 });
      setStudentOptions(data.data);
    }, 300);
    return () => clearTimeout(t);
  }, [studentQuery]);

  const selectedRoute = routes.find((r) => r._id === form.route);

  const handleAssign = async (e) => {
    e.preventDefault();
    try {
      await transportService.assignments.assign(form);
      toast.success('Student assigned to transport.');
      setModalOpen(false);
      setForm({ student: '', vehicle: '', route: '', stopId: '', monthlyFee: 0 });
      setStudentQuery('');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to assign student.');
    }
  };

  const handleRemove = async (id) => {
    await transportService.assignments.remove(id);
    toast.success('Assignment removed.');
    load();
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <button className="btn-brass" onClick={() => setModalOpen(true)}><IoAddOutline /> Assign Student</button>
      </div>
      <div className="card overflow-hidden">
        <table className="table-base">
          <thead><tr><th>Student</th><th>Vehicle</th><th>Route</th><th>Monthly Fee</th><th className="text-right">Actions</th></tr></thead>
          <tbody>
            {assignments.length === 0 ? (
              <tr><td colSpan={5} className="py-8 text-center text-ink-400">No assignments yet.</td></tr>
            ) : assignments.map((a) => (
              <tr key={a._id}>
                <td>{a.student?.firstName} {a.student?.lastName}</td>
                <td>{a.vehicle?.vehicleNumber}</td>
                <td>{a.route?.name}</td>
                <td>{a.monthlyFee}</td>
                <td className="text-right">
                  <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => handleRemove(a._id)}><IoTrashOutline /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Assign Student to Transport" size="lg">
        <form onSubmit={handleAssign} className="space-y-4">
          <div>
            <label className="label">Student</label>
            <input className="input" placeholder="Search by name or admission number…" value={studentQuery} onChange={(e) => setStudentQuery(e.target.value)} />
            {studentOptions.length > 0 && (
              <div className="mt-1 max-h-40 overflow-y-auto rounded-md border border-ink-100 bg-white shadow-sm">
                {studentOptions.map((s) => (
                  <button type="button" key={s._id} className="block w-full px-3 py-2 text-left text-sm hover:bg-ink-50"
                    onClick={() => { setForm({ ...form, student: s._id }); setStudentQuery(`${s.firstName} ${s.lastName || ''}`); setStudentOptions([]); }}>
                    {s.firstName} {s.lastName} — {s.admissionNumber}
                  </button>
                ))}
              </div>
            )}
          </div>
          <SelectField label="Vehicle" required value={form.vehicle} onChange={(e) => setForm({ ...form, vehicle: e.target.value })}
            options={vehicles.map((v) => ({ value: v._id, label: v.vehicleNumber }))} />
          <SelectField label="Route" required value={form.route} onChange={(e) => setForm({ ...form, route: e.target.value, stopId: '' })}
            options={routes.map((r) => ({ value: r._id, label: r.name }))} />
          <SelectField label="Stop" required value={form.stopId} onChange={(e) => {
              const stop = selectedRoute?.stops.find((s) => s._id === e.target.value);
              setForm({ ...form, stopId: e.target.value, monthlyFee: stop?.fare || 0 });
            }}
            options={(selectedRoute?.stops || []).map((s) => ({ value: s._id, label: s.name }))} />
          <TextField label="Monthly Fee" type="number" value={form.monthlyFee} onChange={(e) => setForm({ ...form, monthlyFee: e.target.value })} />
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button className="btn-brass" disabled={!form.student}>Assign</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
