import { useEffect, useState, useCallback } from 'react';
import { IoAddOutline, IoTrashOutline, IoPencilOutline, IoIdCardOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import DataTable from '../../components/ui/DataTable';
import Modal from '../../components/ui/Modal';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import { TextField } from '../../components/forms/FormFields';
import { teacherService, idCardService } from '../../services/resourceServices';
import { openPdf } from '../../utils/openPdf';

const emptyForm = {
  firstName: '', lastName: '', email: '', employeeId: '', qualification: '',
  designation: '', phone: '', salary: '',
};

export default function TeachersPage() {
  const [teachers, setTeachers] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await teacherService.list({ search, page, limit: 10 });
      setTeachers(data.data);
      setPagination(data.pagination);
    } finally {
      setLoading(false);
    }
  }, [search, page]);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => { setEditingId(null); setForm(emptyForm); setModalOpen(true); };
  const openEdit = (t) => {
    setEditingId(t._id);
    setForm({
      firstName: t.firstName, lastName: t.lastName || '', email: t.email || '',
      employeeId: t.employeeId, qualification: t.qualification || '',
      designation: t.designation || '', phone: t.phone || '', salary: t.salary || '',
    });
    setModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editingId) {
        await teacherService.update(editingId, form);
        toast.success('Teacher updated.');
      } else {
        await teacherService.create(form);
        toast.success('Teacher created.');
      }
      setModalOpen(false);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save teacher.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    try {
      await teacherService.remove(deleteTarget._id);
      toast.success('Teacher deleted.');
      setDeleteTarget(null);
      load();
    } catch {
      toast.error('Failed to delete teacher.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl text-ink-800">Teachers</h1>
          <p className="text-sm text-ink-400">Manage teaching staff and their assignments.</p>
        </div>
        <button className="btn-brass" onClick={openCreate}><IoAddOutline /> Add Teacher</button>
      </div>

      <DataTable
        loading={loading}
        rows={teachers}
        search={search}
        onSearchChange={(v) => { setSearch(v); setPage(1); }}
        searchPlaceholder="Search by name or employee ID…"
        pagination={pagination}
        onPageChange={setPage}
        columns={[
          { header: 'Employee ID', accessor: (r) => r.employeeId },
          { header: 'Name', accessor: (r) => `${r.firstName} ${r.lastName || ''}` },
          { header: 'Designation', accessor: (r) => r.designation },
          { header: 'Phone', accessor: (r) => r.phone || '—' },
          {
            header: 'Status',
            accessor: (r) => (
              <span className={`rounded-full px-2 py-0.5 text-xs ${r.status === 'active' ? 'bg-brass-50 text-brass-700' : 'bg-ink-100 text-ink-500'}`}>
                {r.status}
              </span>
            ),
          },
        ]}
        actions={(row) => (
          <div className="flex justify-end gap-2">
            <button className="p-1.5 text-ink-400 hover:text-ink-700" onClick={() => openPdf(idCardService.teacherCardUrl(row._id)).catch(() => toast.error('Failed to generate ID card.'))} aria-label="ID Card">
              <IoIdCardOutline />
            </button>
            <button className="p-1.5 text-ink-400 hover:text-ink-700" onClick={() => openEdit(row)}><IoPencilOutline /></button>
            <button className="p-1.5 text-ink-400 hover:text-red-600" onClick={() => setDeleteTarget(row)}><IoTrashOutline /></button>
          </div>
        )}
      />

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editingId ? 'Edit Teacher' : 'Add Teacher'} size="lg">
        <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <TextField label="First Name" required value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} />
          <TextField label="Last Name" value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })} />
          <TextField label="Email" type="email" required disabled={!!editingId} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <TextField label="Employee ID" required disabled={!!editingId} value={form.employeeId} onChange={(e) => setForm({ ...form, employeeId: e.target.value })} />
          <TextField label="Qualification" value={form.qualification} onChange={(e) => setForm({ ...form, qualification: e.target.value })} />
          <TextField label="Designation" value={form.designation} onChange={(e) => setForm({ ...form, designation: e.target.value })} />
          <TextField label="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          <TextField label="Salary" type="number" value={form.salary} onChange={(e) => setForm({ ...form, salary: e.target.value })} />

          <div className="col-span-full mt-2 flex justify-end gap-3">
            <button type="button" className="btn-outline" onClick={() => setModalOpen(false)}>Cancel</button>
            <button type="submit" className="btn-brass" disabled={saving}>{saving ? 'Saving…' : 'Save Teacher'}</button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete teacher?"
        message={`This will permanently remove ${deleteTarget?.firstName}'s record and login account.`}
      />
    </div>
  );
}
