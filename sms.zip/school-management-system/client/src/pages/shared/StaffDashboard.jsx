import { useAuth } from '../../context/AuthContext';
import { ROLE_LABELS } from '../../components/layout/navConfig';

export default function StaffDashboard() {
  const { user } = useAuth();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Welcome, {user?.name}</h1>
        <p className="text-sm text-ink-400">{ROLE_LABELS[user?.role]} Dashboard</p>
      </div>
      <div className="card p-8 text-center text-ink-400">
        Your role-specific modules (library, transport, reception) can be extended here
        following the same controller/route/page pattern used for students and fees.
      </div>
    </div>
  );
}
