import { Link } from 'react-router-dom';

export function UnauthorizedPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-cream px-4 text-center">
      <h1 className="font-display text-3xl text-ink-800">Access denied</h1>
      <p className="mt-2 max-w-sm text-sm text-ink-500">
        Your account role doesn't have permission to view this page.
      </p>
      <Link to="/" className="btn-primary mt-6">Go to dashboard</Link>
    </div>
  );
}

export function NotFoundPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-cream px-4 text-center">
      <h1 className="font-display text-3xl text-ink-800">Page not found</h1>
      <p className="mt-2 max-w-sm text-sm text-ink-500">
        The page you're looking for doesn't exist or may have moved.
      </p>
      <Link to="/" className="btn-primary mt-6">Go to dashboard</Link>
    </div>
  );
}
