import { useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { IoSchoolOutline } from 'react-icons/io5';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';
import { roleHomePath } from '../../utils/roleHomePath';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const user = await login(form.email, form.password);
      const from = location.state?.from?.pathname;
      navigate(from || roleHomePath(user.role), { replace: true });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-ink-800 px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center text-cream">
          <IoSchoolOutline className="text-brass-400" size={36} />
          <h1 className="mt-3 font-display text-2xl">Greenwood</h1>
          <p className="text-sm text-ink-300">School Management System</p>
        </div>

        <form onSubmit={handleSubmit} className="card p-6">
          <h2 className="mb-1 font-display text-xl text-ink-800">Sign in</h2>
          <p className="mb-6 text-sm text-ink-400">Enter your credentials to access your dashboard.</p>

          <div className="mb-4">
            <label className="label" htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              required
              className="input"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="you@school.com"
            />
          </div>

          <div className="mb-2">
            <label className="label" htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              required
              className="input"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              placeholder="••••••••"
            />
          </div>

          <div className="mb-6 text-right">
            <Link to="/forgot-password" className="text-xs text-brass-600 hover:underline">
              Forgot password?
            </Link>
          </div>

          <button type="submit" className="btn-primary w-full" disabled={loading}>
            {loading ? 'Signing in…' : 'Sign in'}
          </button>
        </form>
      </div>
    </div>
  );
}
