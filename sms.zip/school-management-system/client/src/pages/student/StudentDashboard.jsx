import { useEffect, useState } from 'react';
import { dashboardService } from '../../services/resourceServices';
import StatCard from '../../components/ui/StatCard';
import EmptyState from '../../components/ui/EmptyState';
import FullPageLoader from '../../components/ui/FullPageLoader';

export default function StudentDashboard() {
  const [data, setData] = useState(null);

  useEffect(() => {
    dashboardService.student().then(({ data }) => setData(data.data));
  }, []);

  if (!data) return <FullPageLoader />;
  if (!data.student) {
    return <EmptyState title="No profile found" description="Contact your school administrator if this seems wrong." />;
  }

  const { student, attendancePercentage, pendingFees, notices } = data;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Hi, {student.firstName}</h1>
        <p className="text-sm text-ink-400">{student.class?.name} / {student.section?.name} · Admission No. {student.admissionNumber}</p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard label="Attendance" value={`${attendancePercentage}%`} accent />
        <StatCard label="Pending Fee Invoices" value={pendingFees.length} />
        <StatCard label="Class" value={`${student.class?.name} - ${student.section?.name}`} />
      </div>

      <div className="card p-5">
        <h3 className="mb-3 font-display text-base text-ink-700">Recent Notices</h3>
        {notices.length === 0 ? (
          <EmptyState title="No notices yet" />
        ) : (
          <ul className="space-y-2 text-sm">
            {notices.map((n) => (
              <li key={n._id} className="flex justify-between border-b border-ink-50 pb-2">
                <span>{n.title}</span>
                <span className="text-ink-400">{new Date(n.publishDate).toLocaleDateString()}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
