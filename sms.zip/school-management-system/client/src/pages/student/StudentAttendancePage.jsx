import { useEffect, useState } from 'react';
import { attendanceService, dashboardService } from '../../services/resourceServices';
import StatCard from '../../components/ui/StatCard';
import FullPageLoader from '../../components/ui/FullPageLoader';

export default function StudentAttendancePage() {
  const [records, setRecords] = useState(null);
  const [summary, setSummary] = useState(null);

  useEffect(() => {
    const load = async () => {
      const { data: dash } = await dashboardService.student();
      if (!dash.data.student) return;
      const { data } = await attendanceService.getForStudent(dash.data.student._id);
      setRecords(data.data.records);
      setSummary(data.data.summary);
    };
    load();
  }, []);

  if (!records) return <FullPageLoader />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">My Attendance</h1>
        <p className="text-sm text-ink-400">Your attendance history for the current session.</p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard label="Attendance Rate" value={`${summary.percentage}%`} accent />
        <StatCard label="Days Present" value={summary.present} />
        <StatCard label="Total Recorded Days" value={summary.total} />
      </div>

      <div className="card overflow-hidden">
        <table className="table-base">
          <thead><tr><th>Date</th><th>Status</th><th>Remarks</th></tr></thead>
          <tbody>
            {records.length === 0 ? (
              <tr><td colSpan={3} className="py-8 text-center text-ink-400">No attendance records yet.</td></tr>
            ) : records.map((r) => (
              <tr key={r._id}>
                <td>{new Date(r.date).toLocaleDateString()}</td>
                <td className="capitalize">{r.status}</td>
                <td>{r.remarks || '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
