import { useEffect, useState } from 'react';
import { assignmentService, dashboardService } from '../../services/resourceServices';
import EmptyState from '../../components/ui/EmptyState';
import FullPageLoader from '../../components/ui/FullPageLoader';

export default function StudentAssignmentsPage() {
  const [assignments, setAssignments] = useState(null);

  useEffect(() => {
    const load = async () => {
      const { data: dash } = await dashboardService.student();
      const student = dash.data.student;
      if (!student) { setAssignments([]); return; }
      const { data } = await assignmentService.list({ class: student.class._id, section: student.section._id });
      setAssignments(data.data);
    };
    load();
  }, []);

  if (!assignments) return <FullPageLoader />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Assignments</h1>
        <p className="text-sm text-ink-400">Homework and deadlines from your teachers.</p>
      </div>

      {assignments.length === 0 ? (
        <EmptyState title="No assignments yet" />
      ) : (
        <div className="space-y-3">
          {assignments.map((a) => (
            <div key={a._id} className="card p-5">
              <h3 className="font-display text-base text-ink-800">{a.title}</h3>
              <p className="mt-1 text-sm text-ink-500">{a.description}</p>
              <p className="mt-2 text-xs text-ink-300">
                {a.subject?.name && `${a.subject.name} · `}Due {new Date(a.deadline).toLocaleDateString()}
              </p>
              {a.attachmentUrl && (
                <a href={a.attachmentUrl} target="_blank" rel="noreferrer" className="mt-2 inline-block text-sm text-brass-600 hover:underline">
                  Download attachment
                </a>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
