import { useEffect, useState } from 'react';
import { examService, dashboardService } from '../../services/resourceServices';
import { getAccessToken } from '../../services/api';
import EmptyState from '../../components/ui/EmptyState';
import FullPageLoader from '../../components/ui/FullPageLoader';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export default function StudentResultsPage() {
  const [exams, setExams] = useState(null);
  const [studentId, setStudentId] = useState(null);
  const [results, setResults] = useState({});

  useEffect(() => {
    const load = async () => {
      const { data: dash } = await dashboardService.student();
      const student = dash.data.student;
      if (!student) { setExams([]); return; }
      setStudentId(student._id);

      const { data: examList } = await examService.list({ class: student.class._id });
      const published = examList.data.filter((e) => e.resultPublished);
      setExams(published);

      const resultsMap = {};
      await Promise.all(published.map(async (exam) => {
        const { data: r } = await examService.getResults(exam._id);
        resultsMap[exam._id] = r.data.find((res) => res.student._id === student._id);
      }));
      setResults(resultsMap);
    };
    load();
  }, []);

  const downloadPdf = async (examId) => {
    const token = getAccessToken();
    const url = `${API_URL}${examService.reportCardUrl(examId, studentId)}`;
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    const blob = await res.blob();
    window.open(window.URL.createObjectURL(blob));
  };

  if (!exams) return <FullPageLoader />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">My Results</h1>
        <p className="text-sm text-ink-400">Published exam results and downloadable report cards.</p>
      </div>

      {exams.length === 0 ? (
        <EmptyState title="No published results yet" description="Results will appear here once your school publishes them." />
      ) : (
        <div className="space-y-3">
          {exams.map((exam) => {
            const result = results[exam._id];
            return (
              <div key={exam._id} className="card flex items-center justify-between p-5">
                <div>
                  <h3 className="font-display text-base text-ink-800">{exam.name}</h3>
                  {result ? (
                    <p className="mt-1 text-sm text-ink-500">
                      Total: {result.totalObtained}/{result.totalFullMarks} · Grade: {result.grade} · {result.isPass ? 'Pass' : 'Fail'}
                    </p>
                  ) : (
                    <p className="mt-1 text-sm text-ink-400">Result not entered yet.</p>
                  )}
                </div>
                {result && (
                  <button className="btn-outline" onClick={() => downloadPdf(exam._id)}>Download PDF</button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
