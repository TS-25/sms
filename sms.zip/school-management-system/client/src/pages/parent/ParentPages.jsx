import { useEffect, useState } from 'react';
import api, { getAccessToken } from '../../services/api';
import { attendanceService, examService, feeService } from '../../services/resourceServices';
import EmptyState from '../../components/ui/EmptyState';
import FullPageLoader from '../../components/ui/FullPageLoader';
import StatCard from '../../components/ui/StatCard';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Shared helper: parents may have more than one child, so every parent page
// loads the linked children first and defaults to the first one.
function useFirstChild() {
  const [child, setChild] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/students', { params: { limit: 50 } })
      .then(({ data }) => setChild(data.data[0] || null))
      .finally(() => setLoading(false));
  }, []);

  return { child, loading };
}

export function ParentAttendancePage() {
  const { child, loading } = useFirstChild();
  const [records, setRecords] = useState(null);
  const [summary, setSummary] = useState(null);

  useEffect(() => {
    if (!child) return;
    attendanceService.getForStudent(child._id).then(({ data }) => {
      setRecords(data.data.records);
      setSummary(data.data.summary);
    });
  }, [child]);

  if (loading) return <FullPageLoader />;
  if (!child) return <EmptyState title="No linked children found" />;
  if (!records) return <FullPageLoader />;

  return (
    <div className="space-y-6">
      <h1 className="font-display text-2xl text-ink-800">{child.firstName}'s Attendance</h1>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard label="Attendance Rate" value={`${summary.percentage}%`} accent />
        <StatCard label="Days Present" value={summary.present} />
        <StatCard label="Total Recorded Days" value={summary.total} />
      </div>
      <div className="card overflow-hidden">
        <table className="table-base">
          <thead><tr><th>Date</th><th>Status</th></tr></thead>
          <tbody>
            {records.map((r) => (
              <tr key={r._id}><td>{new Date(r.date).toLocaleDateString()}</td><td className="capitalize">{r.status}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function ParentResultsPage() {
  const { child, loading } = useFirstChild();
  const [exams, setExams] = useState(null);
  const [results, setResults] = useState({});

  useEffect(() => {
    if (!child) return;
    examService.list({ class: child.class._id }).then(async ({ data }) => {
      const published = data.data.filter((e) => e.resultPublished);
      setExams(published);
      const map = {};
      await Promise.all(published.map(async (exam) => {
        const { data: r } = await examService.getResults(exam._id);
        map[exam._id] = r.data.find((res) => res.student._id === child._id);
      }));
      setResults(map);
    });
  }, [child]);

  const downloadPdf = async (examId) => {
    const token = getAccessToken();
    const res = await fetch(`${API_URL}${examService.reportCardUrl(examId, child._id)}`, { headers: { Authorization: `Bearer ${token}` } });
    const blob = await res.blob();
    window.open(window.URL.createObjectURL(blob));
  };

  if (loading) return <FullPageLoader />;
  if (!child) return <EmptyState title="No linked children found" />;
  if (!exams) return <FullPageLoader />;

  return (
    <div className="space-y-6">
      <h1 className="font-display text-2xl text-ink-800">{child.firstName}'s Results</h1>
      {exams.length === 0 ? (
        <EmptyState title="No published results yet" />
      ) : (
        <div className="space-y-3">
          {exams.map((exam) => {
            const result = results[exam._id];
            return (
              <div key={exam._id} className="card flex items-center justify-between p-5">
                <div>
                  <h3 className="font-display text-base text-ink-800">{exam.name}</h3>
                  {result && <p className="mt-1 text-sm text-ink-500">Total: {result.totalObtained}/{result.totalFullMarks} · Grade: {result.grade}</p>}
                </div>
                {result && <button className="btn-outline" onClick={() => downloadPdf(exam._id)}>Download PDF</button>}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export function ParentFeesPage() {
  const { child, loading } = useFirstChild();
  const [fees, setFees] = useState(null);

  useEffect(() => {
    if (!child) return;
    feeService.list({ student: child._id }).then(({ data }) => setFees(data.data));
  }, [child]);

  if (loading) return <FullPageLoader />;
  if (!child) return <EmptyState title="No linked children found" />;
  if (!fees) return <FullPageLoader />;

  return (
    <div className="space-y-6">
      <h1 className="font-display text-2xl text-ink-800">{child.firstName}'s Fees</h1>
      <div className="card overflow-hidden">
        <table className="table-base">
          <thead><tr><th>Title</th><th>Amount</th><th>Paid</th><th>Due</th><th>Status</th></tr></thead>
          <tbody>
            {fees.length === 0 ? (
              <tr><td colSpan={5} className="py-8 text-center text-ink-400">No fee invoices yet.</td></tr>
            ) : fees.map((f) => (
              <tr key={f._id}><td>{f.title}</td><td>{f.amount}</td><td>{f.amountPaid}</td><td>{f.amountDue}</td><td className="capitalize">{f.status}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
