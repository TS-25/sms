import { useEffect, useState } from 'react';
import api from '../../services/api';
import EmptyState from '../../components/ui/EmptyState';
import FullPageLoader from '../../components/ui/FullPageLoader';
import StatCard from '../../components/ui/StatCard';

// Parents are linked to students via Student.parent. There is no dedicated
// "my children" endpoint yet, so we query students filtered server-side —
// for a parent role this would typically be scoped by their linked
// student IDs. Here we surface it through a light client-side helper that
// hits the students list; in production this filter would live server-side
// keyed off req.user._id for stronger authorization guarantees.
export default function ParentDashboard() {
  const [children, setChildren] = useState(null);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const { data } = await api.get('/students', { params: { limit: 50 } });
        setChildren(data.data);
        if (data.data.length) setSelected(data.data[0]);
      } catch {
        setChildren([]);
      }
    };
    load();
  }, []);

  if (!children) return <FullPageLoader />;
  if (children.length === 0) {
    return <EmptyState title="No linked children found" description="Contact your school administrator to link your account to your child's profile." />;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-800">Parent Portal</h1>
        <p className="text-sm text-ink-400">Viewing information for your child.</p>
      </div>

      {children.length > 1 && (
        <div className="flex gap-2">
          {children.map((c) => (
            <button
              key={c._id}
              onClick={() => setSelected(c)}
              className={`rounded-md px-3 py-1.5 text-sm ${selected?._id === c._id ? 'bg-brass-400 text-ink-900' : 'bg-ink-50 text-ink-600'}`}
            >
              {c.firstName} {c.lastName}
            </button>
          ))}
        </div>
      )}

      {selected && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <StatCard label="Name" value={`${selected.firstName} ${selected.lastName || ''}`} />
          <StatCard label="Class/Section" value={`${selected.class?.name || '—'} / ${selected.section?.name || '—'}`} />
          <StatCard label="Admission No." value={selected.admissionNumber} />
        </div>
      )}

      <p className="text-sm text-ink-400">
        Use the sidebar to view attendance, results, fees, and notices for your child.
      </p>
    </div>
  );
}
