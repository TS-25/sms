/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // "Ledger & Brass" palette — inspired by school registers, report
        // cards, and brass nameplates rather than generic SaaS blue.
        ink: {
          50: '#F3F4F1',
          100: '#E4E6E0',
          200: '#C4C8BE',
          300: '#9DA394',
          400: '#6B7263',
          500: '#454C3E',
          600: '#333A2D',
          700: '#252B20',
          800: '#1A1F16',
          900: '#12150F',
        },
        brass: {
          50: '#FBF3E3',
          100: '#F5E3BC',
          200: '#EACB84',
          300: '#DDAE4D',
          400: '#C99529',
          500: '#A87A1E',
          600: '#846017',
          700: '#614711',
          800: '#3F2E0B',
        },
        cream: '#F7F5EF',
      },
      fontFamily: {
        display: ['"Fraunces"', 'Georgia', 'serif'],
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        panel: '0 1px 2px rgba(18, 21, 15, 0.06), 0 1px 3px rgba(18, 21, 15, 0.08)',
      },
    },
  },
  plugins: [],
};
