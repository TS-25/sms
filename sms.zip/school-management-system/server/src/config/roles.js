// Central role definitions used across the app (auth, seed data, middleware).
// Extend this list to add new roles (e.g. librarian, receptionist) — the RBAC
// middleware and User model are driven entirely by this list, so no other
// code needs to change to introduce a new role name.

const ROLES = Object.freeze({
  SUPER_ADMIN: 'super_admin',
  ADMIN: 'admin',
  PRINCIPAL: 'principal',
  TEACHER: 'teacher',
  STUDENT: 'student',
  PARENT: 'parent',
  ACCOUNTANT: 'accountant',
  LIBRARIAN: 'librarian',
  RECEPTIONIST: 'receptionist',
  STAFF: 'staff',
});

const ALL_ROLES = Object.values(ROLES);

// Roles allowed to manage core academic/administrative data.
const ADMIN_LIKE = [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.PRINCIPAL];

// Roles allowed to manage finances.
const FINANCE_ROLES = [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTANT];

module.exports = { ROLES, ALL_ROLES, ADMIN_LIKE, FINANCE_ROLES };
