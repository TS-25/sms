const mongoose = require('mongoose');

// Retries the initial connection instead of exiting immediately. This
// matters most in container environments where "mongo" may take a few
// extra seconds to accept connections even after its own health check
// passes (slow/sandboxed CI runners, first-run volume initialization,
// etc.) — without a retry, a single early failure would kill the process
// before it ever binds to its port, which then makes any orchestrator
// health check fail forever even though the issue was purely timing.
const MAX_RETRIES = 15;
const RETRY_DELAY_MS = 3000;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const connectDB = async () => {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    console.error('MONGODB_URI is not defined in environment variables.');
    process.exit(1);
  }

  mongoose.set('strictQuery', true);

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt += 1) {
    try {
      await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
      console.log(`MongoDB connected: ${mongoose.connection.host}`);
      return;
    } catch (err) {
      console.error(
        `MongoDB connection attempt ${attempt}/${MAX_RETRIES} failed: ${err.message}`
      );
      if (attempt === MAX_RETRIES) {
        console.error('Giving up after max retries. Exiting.');
        process.exit(1);
      }
      await sleep(RETRY_DELAY_MS);
    }
  }
};

module.exports = connectDB;
