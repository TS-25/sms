const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Files are stored locally under server/uploads by default. To use Cloudinary
// instead, set STORAGE_PROVIDER=cloudinary and configure the Cloudinary env
// vars — server/src/services/storageService.js reads that flag and uploads
// the buffered file there instead. This keeps the app runnable on any host
// (Render/Railway/VPS) without a mandatory third-party dependency.
const uploadDir = path.join(__dirname, '..', '..', 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    cb(null, `${unique}${path.extname(file.originalname)}`);
  },
});

const fileFilter = (req, file, cb) => {
  const allowed = /jpeg|jpg|png|gif|pdf|doc|docx|xls|xlsx|csv/;
  const isAllowed = allowed.test(path.extname(file.originalname).toLowerCase());
  if (isAllowed) return cb(null, true);
  cb(new Error('Unsupported file type.'));
};

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
});

module.exports = upload;
