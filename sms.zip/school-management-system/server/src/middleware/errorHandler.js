const ApiError = require('../utils/ApiError');

// Converts known Mongoose/JS errors into consistent ApiError shapes so the
// notFound/errorHandler pair always produces the same response format.
const errorConverter = (err, req, res, next) => {
  let error = err;
  if (!(error instanceof ApiError)) {
    let statusCode = error.statusCode || 500;
    let message = error.message || 'Internal server error';

    if (error.name === 'ValidationError') {
      statusCode = 400;
      message = Object.values(error.errors)
        .map((e) => e.message)
        .join(', ');
    } else if (error.name === 'CastError') {
      statusCode = 400;
      message = `Invalid value for field '${error.path}'`;
    } else if (error.code === 11000) {
      statusCode = 409;
      const field = Object.keys(error.keyValue || {})[0];
      message = `${field ? field.charAt(0).toUpperCase() + field.slice(1) : 'Field'} already exists.`;
    }

    error = new ApiError(statusCode, message, error.details);
  }
  next(error);
};

// Final error handler — never leaks stack traces to the client in production.
const errorHandler = (err, req, res, next) => {
  const statusCode = err.statusCode || 500;
  const response = {
    success: false,
    message: err.message || 'Internal server error',
  };
  if (err.details) response.details = err.details;
  if (process.env.NODE_ENV !== 'production') response.stack = err.stack;

  if (statusCode >= 500) {
    console.error(err);
  }

  res.status(statusCode).json(response);
};

const notFound = (req, res, next) => {
  next(new ApiError(404, `Route not found: ${req.originalUrl}`));
};

module.exports = { errorConverter, errorHandler, notFound };
