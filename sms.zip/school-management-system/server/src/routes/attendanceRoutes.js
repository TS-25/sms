const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const { ADMIN_LIKE, ROLES } = require('../config/roles');
const ctrl = require('../controllers/attendanceController');

const router = express.Router();

router.use(protect);

router.post('/mark', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.markAttendance);
router.get('/', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.getAttendanceByDate);
router.get('/export/csv', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.exportAttendanceCsv);
router.get(
  '/student/:studentId',
  authorize(...ADMIN_LIKE, ROLES.TEACHER, ROLES.STUDENT, ROLES.PARENT),
  ctrl.getStudentAttendance
);

module.exports = router;
