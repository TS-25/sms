const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const { ROLES } = require('../config/roles');
const ctrl = require('../controllers/settingsController');

const router = express.Router();

router.use(protect);

router.get('/', ctrl.getSettings);
router.put('/', authorize(ROLES.SUPER_ADMIN, ROLES.ADMIN), ctrl.updateSettings);

module.exports = router;
