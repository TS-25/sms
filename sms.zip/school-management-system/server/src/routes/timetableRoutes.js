const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const { ADMIN_LIKE, ROLES } = require('../config/roles');
const ctrl = require('../controllers/timetableController');

const router = express.Router();

router.use(protect);

router.get('/', ctrl.getTimetable);
router.get('/teacher/:teacherId', ctrl.getTeacherTimetable);
router.post('/:class/:section/periods', authorize(...ADMIN_LIKE), ctrl.addPeriod);
router.put('/:class/:section/periods/:periodId', authorize(...ADMIN_LIKE), ctrl.updatePeriod);
router.delete('/:class/:section/periods/:periodId', authorize(...ADMIN_LIKE), ctrl.deletePeriod);

module.exports = router;
