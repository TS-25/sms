const express = require('express');
const { body } = require('express-validator');
const { protect, authorize } = require('../middleware/auth');
const validate = require('../middleware/validate');
const upload = require('../middleware/upload');
const { ROLES, ADMIN_LIKE } = require('../config/roles');
const ctrl = require('../controllers/studentController');

const router = express.Router();

router.use(protect);

router.get('/', authorize(...ADMIN_LIKE, ROLES.TEACHER, ROLES.ACCOUNTANT, ROLES.RECEPTIONIST), ctrl.getStudents);
router.get('/export/csv', authorize(...ADMIN_LIKE), ctrl.exportStudentsCsv);
router.get('/:id', authorize(...ADMIN_LIKE, ROLES.TEACHER, ROLES.ACCOUNTANT, ROLES.STUDENT, ROLES.PARENT), ctrl.getStudentProfile);

router.post(
  '/',
  authorize(...ADMIN_LIKE, ROLES.RECEPTIONIST),
  [
    body('firstName').notEmpty(),
    body('email').isEmail(),
    body('admissionNumber').notEmpty(),
    body('class').notEmpty(),
    body('section').notEmpty(),
    body('academicSession').notEmpty(),
  ],
  validate,
  ctrl.createStudent
);

router.post(
  '/import/csv',
  authorize(...ADMIN_LIKE),
  upload.single('file'),
  ctrl.importStudentsCsv
);

router.put('/:id', authorize(...ADMIN_LIKE, ROLES.RECEPTIONIST), ctrl.updateStudent);
router.delete('/:id', authorize(...ADMIN_LIKE), ctrl.deleteStudent);

module.exports = router;
