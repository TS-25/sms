const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const { ADMIN_LIKE, ROLES } = require('../config/roles');
const ctrl = require('../controllers/eventController');

const router = express.Router();

router.use(protect);

router.get('/', ctrl.getEvents);
router.post('/', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.createEvent);
router.put('/:id', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.updateEvent);
router.delete('/:id', authorize(...ADMIN_LIKE), ctrl.deleteEvent);

module.exports = router;
