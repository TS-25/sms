const express = require('express');
const { body } = require('express-validator');
const rateLimit = require('express-rate-limit');
const validate = require('../middleware/validate');
const { protect } = require('../middleware/auth');
const ctrl = require('../controllers/authController');

const router = express.Router();

// Stricter limiter on auth endpoints to slow down brute-force/credential-stuffing.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many attempts. Please try again later.' },
});

router.post(
  '/login',
  authLimiter,
  [body('email').isEmail().withMessage('Valid email is required.'), body('password').notEmpty()],
  validate,
  ctrl.login
);

router.post('/refresh', ctrl.refresh);
router.post('/logout', ctrl.logout);
router.get('/me', protect, ctrl.getMe);

router.post(
  '/change-password',
  protect,
  [body('currentPassword').notEmpty(), body('newPassword').isLength({ min: 6 })],
  validate,
  ctrl.changePassword
);

router.post(
  '/forgot-password',
  authLimiter,
  [body('email').isEmail()],
  validate,
  ctrl.forgotPassword
);

router.post(
  '/reset-password/:token',
  [body('password').isLength({ min: 6 })],
  validate,
  ctrl.resetPassword
);

module.exports = router;
