const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const { FINANCE_ROLES } = require('../config/roles');
const ctrl = require('../controllers/expenseController');

const router = express.Router();

router.use(protect, authorize(...FINANCE_ROLES));

router.get('/', ctrl.getExpenses);
router.post('/', ctrl.createExpense);
router.put('/:id', ctrl.updateExpense);
router.delete('/:id', ctrl.deleteExpense);

module.exports = router;
