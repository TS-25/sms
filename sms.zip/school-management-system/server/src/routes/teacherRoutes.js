const express = require('express');
const { body } = require('express-validator');
const { protect, authorize } = require('../middleware/auth');
const validate = require('../middleware/validate');
const { ADMIN_LIKE, ROLES } = require('../config/roles');
const ctrl = require('../controllers/teacherController');

const router = express.Router();

router.use(protect);

router.get('/', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.getTeachers);
router.get('/:id', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.getTeacherById);

router.post(
  '/',
  authorize(...ADMIN_LIKE),
  [body('firstName').notEmpty(), body('email').isEmail(), body('employeeId').notEmpty()],
  validate,
  ctrl.createTeacher
);

router.put('/:id', authorize(...ADMIN_LIKE), ctrl.updateTeacher);
router.delete('/:id', authorize(...ADMIN_LIKE), ctrl.deleteTeacher);

module.exports = router;
