const express = require('express');
const { protect } = require('../middleware/auth');
const upload = require('../middleware/upload');
const ctrl = require('../controllers/documentController');

const router = express.Router();

router.use(protect);

router.get('/', ctrl.getDocuments);
router.post('/', upload.single('file'), ctrl.uploadDocument);
router.delete('/:id', ctrl.deleteDocument);

module.exports = router;
