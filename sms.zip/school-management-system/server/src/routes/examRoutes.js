const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const { ADMIN_LIKE, ROLES } = require('../config/roles');
const ctrl = require('../controllers/examController');

const router = express.Router();

router.use(protect);

router.get('/', ctrl.getExams);
router.post('/', authorize(...ADMIN_LIKE), ctrl.createExam);
router.put('/:id', authorize(...ADMIN_LIKE), ctrl.updateExam);
router.delete('/:id', authorize(...ADMIN_LIKE), ctrl.deleteExam);

router.post('/:examId/results', authorize(...ADMIN_LIKE, ROLES.TEACHER), ctrl.upsertResult);
router.get('/:examId/results', ctrl.getExamResults);
router.patch('/:examId/publish', authorize(...ADMIN_LIKE), ctrl.publishResults);
router.patch('/:examId/lock', authorize(...ADMIN_LIKE), ctrl.lockResults);
router.get('/:examId/results/:studentId/report-card', ctrl.downloadReportCard);

module.exports = router;
