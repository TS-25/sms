const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const { ROLES } = require('../config/roles');
const ctrl = require('../controllers/auditLogController');

const router = express.Router();

router.use(protect, authorize(ROLES.SUPER_ADMIN, ROLES.ADMIN));

router.get('/', ctrl.getAuditLogs);

module.exports = router;
