const express = require('express');
const { body } = require('express-validator');
const { protect, authorize } = require('../middleware/auth');
const validate = require('../middleware/validate');
const { ADMIN_LIKE } = require('../config/roles');
const ctrl = require('../controllers/staffController');

const router = express.Router();

router.use(protect, authorize(...ADMIN_LIKE));

router.get('/', ctrl.getStaff);
router.post(
  '/',
  [body('firstName').notEmpty(), body('email').isEmail(), body('employeeId').notEmpty()],
  validate,
  ctrl.createStaff
);
router.put('/:id', ctrl.updateStaff);
router.delete('/:id', ctrl.deleteStaff);

module.exports = router;
