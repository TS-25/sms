const express = require('express');
const { protect } = require('../middleware/auth');
const upload = require('../middleware/upload');
const ctrl = require('../controllers/uploadController');

const router = express.Router();

router.post('/', protect, upload.single('file'), ctrl.uploadFile);

module.exports = router;
