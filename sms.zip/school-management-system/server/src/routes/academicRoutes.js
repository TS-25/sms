const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const { ADMIN_LIKE, ROLES } = require('../config/roles');
const ctrl = require('../controllers/academicController');

const router = express.Router();

router.use(protect);

// Sessions
router.get('/sessions', ctrl.getSessions);
router.post('/sessions', authorize(...ADMIN_LIKE), ctrl.createSession);
router.put('/sessions/:id', authorize(...ADMIN_LIKE), ctrl.updateSession);
router.delete('/sessions/:id', authorize(...ADMIN_LIKE), ctrl.deleteSession);

// Classes
router.get('/classes', ctrl.getClasses);
router.post('/classes', authorize(...ADMIN_LIKE), ctrl.createClass);
router.put('/classes/:id', authorize(...ADMIN_LIKE), ctrl.updateClass);
router.delete('/classes/:id', authorize(...ADMIN_LIKE), ctrl.deleteClass);

// Sections
router.get('/sections', ctrl.getSections);
router.post('/sections', authorize(...ADMIN_LIKE), ctrl.createSection);
router.put('/sections/:id', authorize(...ADMIN_LIKE), ctrl.updateSection);
router.delete('/sections/:id', authorize(...ADMIN_LIKE), ctrl.deleteSection);

// Subjects
router.get('/subjects', ctrl.getSubjects);
router.post('/subjects', authorize(...ADMIN_LIKE), ctrl.createSubject);
router.put('/subjects/:id', authorize(...ADMIN_LIKE), ctrl.updateSubject);
router.delete('/subjects/:id', authorize(...ADMIN_LIKE), ctrl.deleteSubject);

module.exports = router;
