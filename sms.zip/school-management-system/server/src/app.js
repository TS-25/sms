const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const mongoSanitize = require('express-mongo-sanitize');
const rateLimit = require('express-rate-limit');
const path = require('path');

const routes = require('./routes');
const { errorConverter, errorHandler, notFound } = require('./middleware/errorHandler');

const app = express();

// Behind a reverse proxy (Render/Railway/Heroku-style hosts) so req.ip and
// secure cookies work correctly.
app.set('trust proxy', 1);

app.use(helmet());

// CORS is driven entirely by CLIENT_URL so this never has to be hardcoded
// per-deployment. Add more comma-separated origins by extending this list.
const allowedOrigins = (process.env.CLIENT_URL || 'http://localhost:5173')
  .split(',')
  .map((o) => o.trim());

app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
      callback(new Error('Not allowed by CORS'));
    },
    credentials: true,
  })
);

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());
app.use(mongoSanitize());

// General API rate limiting (auth routes have their own stricter limiter).
app.use(
  '/api',
  rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 300,
    standardHeaders: true,
    legacyHeaders: false,
  })
);

// Serve locally-uploaded files (only relevant when STORAGE_PROVIDER=local).
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

app.use('/api', routes);

app.use(notFound);
app.use(errorConverter);
app.use(errorHandler);

module.exports = app;
