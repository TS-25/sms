const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Leave = require('../models/Leave');

// GET /api/leaves?applicant=&status=
const getLeaves = asyncHandler(async (req, res) => {
  const { applicant, status, page = 1, limit = 20 } = req.query;
  const filter = {};
  if (applicant) filter.applicant = applicant;
  if (status) filter.status = status;

  const skip = (Number(page) - 1) * Number(limit);
  const [leaves, total] = await Promise.all([
    Leave.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Leave.countDocuments(filter),
  ]);

  res.json({ success: true, data: leaves, pagination: { total, page: Number(page), limit: Number(limit) } });
});

// POST /api/leaves  body: { applicant, applicantModel, leaveType, startDate, endDate, reason }
const applyLeave = asyncHandler(async (req, res) => {
  const leave = await Leave.create(req.body);
  res.status(201).json({ success: true, data: leave });
});

// PATCH /api/leaves/:id/review  body: { status: 'approved'|'rejected', reviewNote }
const reviewLeave = asyncHandler(async (req, res) => {
  const { status, reviewNote } = req.body;
  if (!['approved', 'rejected'].includes(status)) throw new ApiError(400, 'status must be approved or rejected.');

  const leave = await Leave.findByIdAndUpdate(
    req.params.id,
    { status, reviewNote, reviewedBy: req.user._id },
    { new: true }
  );
  if (!leave) throw new ApiError(404, 'Leave request not found.');
  res.json({ success: true, data: leave });
});

const deleteLeave = asyncHandler(async (req, res) => {
  const leave = await Leave.findByIdAndDelete(req.params.id);
  if (!leave) throw new ApiError(404, 'Leave request not found.');
  res.json({ success: true, message: 'Leave request deleted.' });
});

module.exports = { getLeaves, applyLeave, reviewLeave, deleteLeave };
