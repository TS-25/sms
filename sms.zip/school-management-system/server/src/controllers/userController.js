const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const User = require('../models/User');
const logAction = require('../utils/logAction');

// GET /api/users?role=&search=&page=&limit=
const getUsers = asyncHandler(async (req, res) => {
  const { role, search, page = 1, limit = 20 } = req.query;
  const filter = {};
  if (role) filter.role = role;
  if (search) {
    filter.$or = [
      { name: { $regex: search, $options: 'i' } },
      { email: { $regex: search, $options: 'i' } },
    ];
  }

  const skip = (Number(page) - 1) * Number(limit);
  const [users, total] = await Promise.all([
    User.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    User.countDocuments(filter),
  ]);

  res.json({
    success: true,
    data: users.map((u) => u.toSafeObject()),
    pagination: { total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) },
  });
});

// POST /api/users
const createUser = asyncHandler(async (req, res) => {
  const { name, email, password, role, phone } = req.body;
  const existing = await User.findOne({ email: email.toLowerCase() });
  if (existing) throw new ApiError(409, 'A user with this email already exists.');

  const user = await User.create({ name, email, password, role, phone });
  await logAction({ user: req.user, action: 'created', entity: 'User', entityId: user._id, req });

  res.status(201).json({ success: true, data: user.toSafeObject() });
});

// PUT /api/users/:id
const updateUser = asyncHandler(async (req, res) => {
  const { name, phone, role, isActive } = req.body;
  const user = await User.findById(req.params.id);
  if (!user) throw new ApiError(404, 'User not found.');

  if (name !== undefined) user.name = name;
  if (phone !== undefined) user.phone = phone;
  if (role !== undefined) user.role = role;
  if (isActive !== undefined) user.isActive = isActive;
  await user.save();

  await logAction({ user: req.user, action: 'updated', entity: 'User', entityId: user._id, req });
  res.json({ success: true, data: user.toSafeObject() });
});

// DELETE /api/users/:id
const deleteUser = asyncHandler(async (req, res) => {
  const user = await User.findByIdAndDelete(req.params.id);
  if (!user) throw new ApiError(404, 'User not found.');

  await logAction({ user: req.user, action: 'deleted', entity: 'User', entityId: user._id, req });
  res.json({ success: true, message: 'User deleted successfully.' });
});

module.exports = { getUsers, createUser, updateUser, deleteUser };
