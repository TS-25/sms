const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Fee = require('../models/Fee');
const Payment = require('../models/Payment');
const Student = require('../models/Student');
const SchoolSettings = require('../models/SchoolSettings');
const Notification = require('../models/Notification');
const { generateFeeReceiptPDF } = require('../services/pdfService');

// ---------- Fees ----------
// GET /api/fees?student=&status=&category=
const getFees = asyncHandler(async (req, res) => {
  const { student, status, category, page = 1, limit = 20 } = req.query;
  const filter = {};
  if (student) filter.student = student;
  if (status) filter.status = status;
  if (category) filter.category = category;

  const skip = (Number(page) - 1) * Number(limit);
  const [fees, total] = await Promise.all([
    Fee.find(filter).populate('student', 'firstName lastName admissionNumber').sort({ dueDate: 1 }).skip(skip).limit(Number(limit)),
    Fee.countDocuments(filter),
  ]);

  res.json({ success: true, data: fees, pagination: { total, page: Number(page), limit: Number(limit) } });
});

// POST /api/fees  — create a fee invoice for a student
const createFee = asyncHandler(async (req, res) => {
  const fee = await Fee.create(req.body);

  const student = await Student.findById(fee.student);
  if (student?.user) {
    await Notification.create({
      user: student.user,
      title: 'New Fee Invoice',
      message: `A new fee invoice "${fee.title}" of amount ${fee.amount} has been added, due ${new Date(fee.dueDate).toLocaleDateString()}.`,
      type: 'fee_due',
    });
  }

  res.status(201).json({ success: true, data: fee });
});

const updateFee = asyncHandler(async (req, res) => {
  const fee = await Fee.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!fee) throw new ApiError(404, 'Fee not found.');
  res.json({ success: true, data: fee });
});

const deleteFee = asyncHandler(async (req, res) => {
  const fee = await Fee.findByIdAndDelete(req.params.id);
  if (!fee) throw new ApiError(404, 'Fee not found.');
  res.json({ success: true, message: 'Fee deleted.' });
});

// ---------- Payments ----------
// POST /api/payments  body: { fee, amount, method, notes }
const recordPayment = asyncHandler(async (req, res) => {
  const { fee: feeId, amount, method, notes } = req.body;
  const fee = await Fee.findById(feeId);
  if (!fee) throw new ApiError(404, 'Fee invoice not found.');

  const amountDue = fee.amount - fee.discount - fee.amountPaid;
  if (amount > amountDue) throw new ApiError(400, `Payment exceeds amount due (${amountDue}).`);

  const receiptNumber = `RCPT-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  const payment = await Payment.create({
    fee: fee._id,
    student: fee.student,
    amount,
    method,
    notes,
    receiptNumber,
    receivedBy: req.user._id,
  });

  fee.amountPaid += amount;
  fee.status = fee.amountPaid >= fee.amount - fee.discount ? 'paid' : 'partial';
  await fee.save();

  res.status(201).json({ success: true, data: { payment, fee } });
});

// GET /api/payments/:id/receipt  (PDF)
const downloadReceipt = asyncHandler(async (req, res) => {
  const payment = await Payment.findById(req.params.id).populate('fee');
  if (!payment) throw new ApiError(404, 'Payment not found.');

  const student = await Student.findById(payment.student).populate('class section');
  const school = await SchoolSettings.findOne({ key: 'default' });

  generateFeeReceiptPDF(res, { school, student, fee: payment.fee, payment });
});

// GET /api/payments?student=&from=&to=
const getPayments = asyncHandler(async (req, res) => {
  const { student, from, to, page = 1, limit = 20 } = req.query;
  const filter = {};
  if (student) filter.student = student;
  if (from || to) {
    filter.paidAt = {};
    if (from) filter.paidAt.$gte = new Date(from);
    if (to) filter.paidAt.$lte = new Date(to);
  }

  const skip = (Number(page) - 1) * Number(limit);
  const [payments, total] = await Promise.all([
    Payment.find(filter).populate('student', 'firstName lastName admissionNumber').populate('fee', 'title category').sort({ paidAt: -1 }).skip(skip).limit(Number(limit)),
    Payment.countDocuments(filter),
  ]);

  res.json({ success: true, data: payments, pagination: { total, page: Number(page), limit: Number(limit) } });
});

module.exports = {
  getFees, createFee, updateFee, deleteFee,
  recordPayment, downloadReceipt, getPayments,
};
