const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const { getPublicUrl } = require('../services/storageService');

// POST /api/uploads  (multipart field: "file")
const uploadFile = asyncHandler(async (req, res) => {
  if (!req.file) throw new ApiError(400, 'No file was uploaded.');
  const url = getPublicUrl(req, req.file.filename || req.file.path);
  res.status(201).json({ success: true, data: { url, originalName: req.file.originalname } });
});

module.exports = { uploadFile };
