const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Student = require('../models/Student');
const Teacher = require('../models/Teacher');
const SchoolSettings = require('../models/SchoolSettings');
const { generateIdCardPDF } = require('../services/pdfService');

// GET /api/id-cards/student/:studentId
const studentIdCard = asyncHandler(async (req, res) => {
  const student = await Student.findById(req.params.studentId).populate('class section');
  if (!student) throw new ApiError(404, 'Student not found.');
  const school = await SchoolSettings.findOne({ key: 'default' });

  generateIdCardPDF(res, {
    school,
    person: { fullName: student.fullName, phone: student.phone },
    role: 'Student',
    idLabel: student.admissionNumber,
    classSection: `${student.class?.name || ''} / ${student.section?.name || ''}`,
  });
});

// GET /api/id-cards/teacher/:teacherId
const teacherIdCard = asyncHandler(async (req, res) => {
  const teacher = await Teacher.findById(req.params.teacherId);
  if (!teacher) throw new ApiError(404, 'Teacher not found.');
  const school = await SchoolSettings.findOne({ key: 'default' });

  generateIdCardPDF(res, {
    school,
    person: { fullName: teacher.fullName, phone: teacher.phone },
    role: teacher.designation || 'Teacher',
    idLabel: teacher.employeeId,
  });
});

module.exports = { studentIdCard, teacherIdCard };
