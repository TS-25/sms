const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Certificate = require('../models/Certificate');
const Student = require('../models/Student');
const SchoolSettings = require('../models/SchoolSettings');
const { generateCertificatePDF } = require('../services/pdfService');

const getCertificates = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.student) filter.student = req.query.student;
  const certificates = await Certificate.find(filter).populate('student', 'firstName lastName admissionNumber').sort({ createdAt: -1 });
  res.json({ success: true, data: certificates });
});

// POST /api/certificates  body: { student, type, title, body }
const createCertificate = asyncHandler(async (req, res) => {
  const certificateNumber = `CERT-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  const certificate = await Certificate.create({ ...req.body, certificateNumber, issuedBy: req.user._id });
  res.status(201).json({ success: true, data: certificate });
});

const deleteCertificate = asyncHandler(async (req, res) => {
  const certificate = await Certificate.findByIdAndDelete(req.params.id);
  if (!certificate) throw new ApiError(404, 'Certificate not found.');
  res.json({ success: true, message: 'Certificate deleted.' });
});

// GET /api/certificates/:id/pdf
const downloadCertificate = asyncHandler(async (req, res) => {
  const certificate = await Certificate.findById(req.params.id);
  if (!certificate) throw new ApiError(404, 'Certificate not found.');

  const student = await Student.findById(certificate.student);
  const school = await SchoolSettings.findOne({ key: 'default' });

  generateCertificatePDF(res, { school, student, certificate });
});

module.exports = { getCertificates, createCertificate, deleteCertificate, downloadCertificate };
