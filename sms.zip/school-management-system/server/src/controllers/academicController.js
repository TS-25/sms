const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const AcademicSession = require('../models/AcademicSession');
const Class = require('../models/Class');
const Section = require('../models/Section');
const Subject = require('../models/Subject');

// ---------- Academic Sessions ----------
const getSessions = asyncHandler(async (req, res) => {
  const sessions = await AcademicSession.find().sort({ startDate: -1 });
  res.json({ success: true, data: sessions });
});

const createSession = asyncHandler(async (req, res) => {
  const { name, startDate, endDate, isCurrent } = req.body;
  if (isCurrent) await AcademicSession.updateMany({}, { isCurrent: false });
  const session = await AcademicSession.create({ name, startDate, endDate, isCurrent });
  res.status(201).json({ success: true, data: session });
});

const updateSession = asyncHandler(async (req, res) => {
  const session = await AcademicSession.findById(req.params.id);
  if (!session) throw new ApiError(404, 'Academic session not found.');
  if (req.body.isCurrent) await AcademicSession.updateMany({}, { isCurrent: false });
  Object.assign(session, req.body);
  await session.save();
  res.json({ success: true, data: session });
});

const deleteSession = asyncHandler(async (req, res) => {
  const session = await AcademicSession.findByIdAndDelete(req.params.id);
  if (!session) throw new ApiError(404, 'Academic session not found.');
  res.json({ success: true, message: 'Academic session deleted.' });
});

// ---------- Classes ----------
const getClasses = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.academicSession) filter.academicSession = req.query.academicSession;
  const classes = await Class.find(filter).populate('academicSession', 'name').populate('classTeacher', 'firstName lastName');
  res.json({ success: true, data: classes });
});

const createClass = asyncHandler(async (req, res) => {
  const cls = await Class.create(req.body);
  res.status(201).json({ success: true, data: cls });
});

const updateClass = asyncHandler(async (req, res) => {
  const cls = await Class.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!cls) throw new ApiError(404, 'Class not found.');
  res.json({ success: true, data: cls });
});

const deleteClass = asyncHandler(async (req, res) => {
  const cls = await Class.findByIdAndDelete(req.params.id);
  if (!cls) throw new ApiError(404, 'Class not found.');
  res.json({ success: true, message: 'Class deleted.' });
});

// ---------- Sections ----------
const getSections = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.class) filter.class = req.query.class;
  const sections = await Section.find(filter).populate('class', 'name').populate('classTeacher', 'firstName lastName');
  res.json({ success: true, data: sections });
});

const createSection = asyncHandler(async (req, res) => {
  const section = await Section.create(req.body);
  res.status(201).json({ success: true, data: section });
});

const updateSection = asyncHandler(async (req, res) => {
  const section = await Section.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!section) throw new ApiError(404, 'Section not found.');
  res.json({ success: true, data: section });
});

const deleteSection = asyncHandler(async (req, res) => {
  const section = await Section.findByIdAndDelete(req.params.id);
  if (!section) throw new ApiError(404, 'Section not found.');
  res.json({ success: true, message: 'Section deleted.' });
});

// ---------- Subjects ----------
const getSubjects = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.class) filter.class = req.query.class;
  const subjects = await Subject.find(filter).populate('class', 'name').populate('teacher', 'firstName lastName');
  res.json({ success: true, data: subjects });
});

const createSubject = asyncHandler(async (req, res) => {
  const subject = await Subject.create(req.body);
  res.status(201).json({ success: true, data: subject });
});

const updateSubject = asyncHandler(async (req, res) => {
  const subject = await Subject.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!subject) throw new ApiError(404, 'Subject not found.');
  res.json({ success: true, data: subject });
});

const deleteSubject = asyncHandler(async (req, res) => {
  const subject = await Subject.findByIdAndDelete(req.params.id);
  if (!subject) throw new ApiError(404, 'Subject not found.');
  res.json({ success: true, message: 'Subject deleted.' });
});

module.exports = {
  getSessions, createSession, updateSession, deleteSession,
  getClasses, createClass, updateClass, deleteClass,
  getSections, createSection, updateSection, deleteSection,
  getSubjects, createSubject, updateSubject, deleteSubject,
};
