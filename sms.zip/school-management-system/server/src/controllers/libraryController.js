const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Book = require('../models/Book');
const LibraryTransaction = require('../models/LibraryTransaction');

// ---------- Books ----------
const getBooks = asyncHandler(async (req, res) => {
  const { search, category, page = 1, limit = 20 } = req.query;
  const filter = {};
  if (category) filter.category = category;
  if (search) {
    filter.$or = [
      { title: { $regex: search, $options: 'i' } },
      { author: { $regex: search, $options: 'i' } },
      { isbn: { $regex: search, $options: 'i' } },
    ];
  }

  const skip = (Number(page) - 1) * Number(limit);
  const [books, total] = await Promise.all([
    Book.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Book.countDocuments(filter),
  ]);

  res.json({ success: true, data: books, pagination: { total, page: Number(page), limit: Number(limit) } });
});

const createBook = asyncHandler(async (req, res) => {
  const quantity = req.body.quantity || 1;
  const book = await Book.create({ ...req.body, availableQuantity: quantity });
  res.status(201).json({ success: true, data: book });
});

const updateBook = asyncHandler(async (req, res) => {
  const book = await Book.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!book) throw new ApiError(404, 'Book not found.');
  res.json({ success: true, data: book });
});

const deleteBook = asyncHandler(async (req, res) => {
  const book = await Book.findByIdAndDelete(req.params.id);
  if (!book) throw new ApiError(404, 'Book not found.');
  res.json({ success: true, message: 'Book deleted.' });
});

// ---------- Issue / Return ----------
// POST /api/library/issue  body: { book, borrower, borrowerModel, dueDate }
const issueBook = asyncHandler(async (req, res) => {
  const { book: bookId, borrower, borrowerModel, dueDate, fineRatePerDay } = req.body;
  const book = await Book.findById(bookId);
  if (!book) throw new ApiError(404, 'Book not found.');
  if (book.availableQuantity <= 0) throw new ApiError(400, 'No copies of this book are currently available.');

  const transaction = await LibraryTransaction.create({
    book: bookId,
    borrower,
    borrowerModel,
    dueDate,
    fineRatePerDay,
    issuedBy: req.user._id,
  });

  book.availableQuantity -= 1;
  await book.save();

  res.status(201).json({ success: true, data: transaction });
});

// PATCH /api/library/return/:transactionId
const returnBook = asyncHandler(async (req, res) => {
  const transaction = await LibraryTransaction.findById(req.params.transactionId).populate('book');
  if (!transaction) throw new ApiError(404, 'Transaction not found.');
  if (transaction.status === 'returned') throw new ApiError(400, 'This book has already been returned.');

  const returnDate = new Date();
  const daysLate = Math.max(
    0,
    Math.ceil((returnDate - new Date(transaction.dueDate)) / (1000 * 60 * 60 * 24))
  );
  transaction.returnDate = returnDate;
  transaction.status = 'returned';
  transaction.fineAmount = daysLate * (transaction.fineRatePerDay || 1);
  await transaction.save();

  transaction.book.availableQuantity += 1;
  await transaction.book.save();

  res.json({ success: true, data: transaction });
});

// GET /api/library/transactions?borrower=&status=
const getTransactions = asyncHandler(async (req, res) => {
  const { borrower, status, page = 1, limit = 20 } = req.query;
  const filter = {};
  if (borrower) filter.borrower = borrower;
  if (status) filter.status = status;

  const skip = (Number(page) - 1) * Number(limit);
  const [transactions, total] = await Promise.all([
    LibraryTransaction.find(filter).populate('book', 'title isbn').sort({ issueDate: -1 }).skip(skip).limit(Number(limit)),
    LibraryTransaction.countDocuments(filter),
  ]);

  res.json({ success: true, data: transactions, pagination: { total, page: Number(page), limit: Number(limit) } });
});

module.exports = {
  getBooks, createBook, updateBook, deleteBook,
  issueBook, returnBook, getTransactions,
};
