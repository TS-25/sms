const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Hostel = require('../models/Hostel');

const getHostels = asyncHandler(async (req, res) => {
  const hostels = await Hostel.find().populate('rooms.beds.student', 'firstName lastName admissionNumber');
  res.json({ success: true, data: hostels });
});

const createHostel = asyncHandler(async (req, res) => {
  const hostel = await Hostel.create(req.body);
  res.status(201).json({ success: true, data: hostel });
});

const updateHostel = asyncHandler(async (req, res) => {
  const hostel = await Hostel.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!hostel) throw new ApiError(404, 'Hostel not found.');
  res.json({ success: true, data: hostel });
});

const deleteHostel = asyncHandler(async (req, res) => {
  const hostel = await Hostel.findByIdAndDelete(req.params.id);
  if (!hostel) throw new ApiError(404, 'Hostel not found.');
  res.json({ success: true, message: 'Hostel deleted.' });
});

// POST /api/hostels/:id/rooms  body: { roomNumber, capacity, beds: [{bedNumber}] }
const addRoom = asyncHandler(async (req, res) => {
  const hostel = await Hostel.findById(req.params.id);
  if (!hostel) throw new ApiError(404, 'Hostel not found.');
  hostel.rooms.push(req.body);
  await hostel.save();
  res.status(201).json({ success: true, data: hostel });
});

// PATCH /api/hostels/:id/rooms/:roomId/beds/:bedId/allocate  body: { student }
const allocateBed = asyncHandler(async (req, res) => {
  const hostel = await Hostel.findById(req.params.id);
  if (!hostel) throw new ApiError(404, 'Hostel not found.');

  const room = hostel.rooms.id(req.params.roomId);
  if (!room) throw new ApiError(404, 'Room not found.');
  const bed = room.beds.id(req.params.bedId);
  if (!bed) throw new ApiError(404, 'Bed not found.');
  if (bed.isOccupied) throw new ApiError(400, 'This bed is already occupied.');

  bed.isOccupied = true;
  bed.student = req.body.student;
  await hostel.save();

  res.json({ success: true, data: hostel });
});

// PATCH /api/hostels/:id/rooms/:roomId/beds/:bedId/checkout
const checkoutBed = asyncHandler(async (req, res) => {
  const hostel = await Hostel.findById(req.params.id);
  if (!hostel) throw new ApiError(404, 'Hostel not found.');

  const room = hostel.rooms.id(req.params.roomId);
  const bed = room?.beds.id(req.params.bedId);
  if (!bed) throw new ApiError(404, 'Bed not found.');

  bed.isOccupied = false;
  bed.student = undefined;
  await hostel.save();

  res.json({ success: true, data: hostel });
});

module.exports = { getHostels, createHostel, updateHostel, deleteHostel, addRoom, allocateBed, checkoutBed };
