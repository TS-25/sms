const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Timetable = require('../models/Timetable');

// Checks whether a proposed period overlaps an existing period for the same
// teacher (across any class) or the same room, on the same day/time range.
async function findConflicts({ day, startTime, endTime, teacher, room, excludeTimetableId, excludePeriodId }) {
  const timetables = await Timetable.find({
    'periods.day': day,
    ...(excludeTimetableId ? { _id: { $ne: excludeTimetableId } } : {}),
  });

  const conflicts = [];
  for (const tt of timetables) {
    for (const p of tt.periods) {
      if (String(p._id) === String(excludePeriodId)) continue;
      if (p.day !== day) continue;
      const overlaps = startTime < p.endTime && endTime > p.startTime;
      if (!overlaps) continue;
      if (teacher && p.teacher && String(p.teacher) === String(teacher)) {
        conflicts.push({ type: 'teacher', timetable: tt._id, period: p._id });
      }
      if (room && p.room && p.room === room) {
        conflicts.push({ type: 'room', timetable: tt._id, period: p._id });
      }
    }
  }
  return conflicts;
}

// GET /api/timetables?class=&section=
const getTimetable = asyncHandler(async (req, res) => {
  const { class: classId, section } = req.query;
  if (!classId || !section) throw new ApiError(400, 'class and section are required.');

  const timetable = await Timetable.findOne({ class: classId, section })
    .populate('periods.subject', 'name')
    .populate('periods.teacher', 'firstName lastName');

  res.json({ success: true, data: timetable || { class: classId, section, periods: [] } });
});

// GET /api/timetables/teacher/:teacherId
const getTeacherTimetable = asyncHandler(async (req, res) => {
  const timetables = await Timetable.find({ 'periods.teacher': req.params.teacherId })
    .populate('class', 'name')
    .populate('section', 'name')
    .populate('periods.subject', 'name');

  const periods = [];
  timetables.forEach((tt) => {
    tt.periods
      .filter((p) => String(p.teacher) === req.params.teacherId)
      .forEach((p) => periods.push({ ...p.toObject(), class: tt.class, section: tt.section }));
  });

  res.json({ success: true, data: periods });
});

// POST /api/timetables/:class/:section/periods  — add a period, checking conflicts
const addPeriod = asyncHandler(async (req, res) => {
  const { class: classId, section } = req.params;
  const { day, startTime, endTime, subject, teacher, room, academicSession } = req.body;

  if (startTime >= endTime) throw new ApiError(400, 'startTime must be before endTime.');

  const conflicts = await findConflicts({ day, startTime, endTime, teacher, room });
  if (conflicts.length > 0) {
    throw new ApiError(409, 'Scheduling conflict: teacher or room already booked in this time slot.', conflicts);
  }

  let timetable = await Timetable.findOne({ class: classId, section });
  if (!timetable) {
    timetable = new Timetable({ class: classId, section, academicSession, periods: [] });
  }
  timetable.periods.push({ day, startTime, endTime, subject, teacher, room });
  await timetable.save();

  res.status(201).json({ success: true, data: timetable });
});

// PUT /api/timetables/:class/:section/periods/:periodId
const updatePeriod = asyncHandler(async (req, res) => {
  const { class: classId, section, periodId } = req.params;
  const timetable = await Timetable.findOne({ class: classId, section });
  if (!timetable) throw new ApiError(404, 'Timetable not found.');

  const period = timetable.periods.id(periodId);
  if (!period) throw new ApiError(404, 'Period not found.');

  const merged = { ...period.toObject(), ...req.body };
  const conflicts = await findConflicts({
    day: merged.day,
    startTime: merged.startTime,
    endTime: merged.endTime,
    teacher: merged.teacher,
    room: merged.room,
    excludeTimetableId: timetable._id,
    excludePeriodId: periodId,
  });
  if (conflicts.length > 0) {
    throw new ApiError(409, 'Scheduling conflict: teacher or room already booked in this time slot.', conflicts);
  }

  Object.assign(period, req.body);
  await timetable.save();
  res.json({ success: true, data: timetable });
});

// DELETE /api/timetables/:class/:section/periods/:periodId
const deletePeriod = asyncHandler(async (req, res) => {
  const { class: classId, section, periodId } = req.params;
  const timetable = await Timetable.findOne({ class: classId, section });
  if (!timetable) throw new ApiError(404, 'Timetable not found.');

  timetable.periods.id(periodId)?.deleteOne();
  await timetable.save();
  res.json({ success: true, data: timetable });
});

module.exports = { getTimetable, getTeacherTimetable, addPeriod, updatePeriod, deletePeriod };
