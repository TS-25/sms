const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Exam = require('../models/Exam');
const ExamResult = require('../models/ExamResult');
const Student = require('../models/Student');
const SchoolSettings = require('../models/SchoolSettings');
const { generateReportCardPDF } = require('../services/pdfService');

// ---------- Exams ----------
const getExams = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.class) filter.class = req.query.class;
  if (req.query.academicSession) filter.academicSession = req.query.academicSession;
  const exams = await Exam.find(filter).populate('class', 'name').populate('subjects.subject', 'name code');
  res.json({ success: true, data: exams });
});

const createExam = asyncHandler(async (req, res) => {
  const exam = await Exam.create(req.body);
  res.status(201).json({ success: true, data: exam });
});

const updateExam = asyncHandler(async (req, res) => {
  const exam = await Exam.findById(req.params.id);
  if (!exam) throw new ApiError(404, 'Exam not found.');
  if (exam.resultLocked) throw new ApiError(400, 'This exam is locked and cannot be modified.');
  Object.assign(exam, req.body);
  await exam.save();
  res.json({ success: true, data: exam });
});

const deleteExam = asyncHandler(async (req, res) => {
  const exam = await Exam.findByIdAndDelete(req.params.id);
  if (!exam) throw new ApiError(404, 'Exam not found.');
  res.json({ success: true, message: 'Exam deleted.' });
});

// ---------- Results ----------
// POST /api/exams/:examId/results  body: { student, marks: [{subject, marksObtained, fullMarks, passMarks}] }
const upsertResult = asyncHandler(async (req, res) => {
  const exam = await Exam.findById(req.params.examId);
  if (!exam) throw new ApiError(404, 'Exam not found.');
  if (exam.resultLocked) throw new ApiError(400, 'Results for this exam are locked.');

  const { student, marks, remarks } = req.body;
  let result = await ExamResult.findOne({ exam: exam._id, student });
  if (result) {
    result.marks = marks;
    result.remarks = remarks;
  } else {
    result = new ExamResult({ exam: exam._id, student, marks, remarks });
  }
  await result.save();
  res.status(201).json({ success: true, data: result });
});

// GET /api/exams/:examId/results  (ranked)
const getExamResults = asyncHandler(async (req, res) => {
  const results = await ExamResult.find({ exam: req.params.examId })
    .populate('student', 'firstName lastName admissionNumber rollNumber')
    .populate('marks.subject', 'name code')
    .sort({ totalObtained: -1 });

  // Assign rank based on descending totalObtained.
  results.forEach((r, idx) => {
    r.rank = idx + 1;
  });
  await Promise.all(results.map((r) => r.save()));

  res.json({ success: true, data: results });
});

// PATCH /api/exams/:examId/publish
const publishResults = asyncHandler(async (req, res) => {
  const exam = await Exam.findByIdAndUpdate(
    req.params.examId,
    { resultPublished: true },
    { new: true }
  );
  if (!exam) throw new ApiError(404, 'Exam not found.');
  res.json({ success: true, data: exam });
});

// PATCH /api/exams/:examId/lock
const lockResults = asyncHandler(async (req, res) => {
  const exam = await Exam.findByIdAndUpdate(
    req.params.examId,
    { resultLocked: true },
    { new: true }
  );
  if (!exam) throw new ApiError(404, 'Exam not found.');
  res.json({ success: true, data: exam });
});

// GET /api/exams/:examId/results/:studentId/report-card  (PDF)
const downloadReportCard = asyncHandler(async (req, res) => {
  const exam = await Exam.findById(req.params.examId);
  if (!exam) throw new ApiError(404, 'Exam not found.');

  const result = await ExamResult.findOne({ exam: exam._id, student: req.params.studentId }).populate(
    'marks.subject',
    'name'
  );
  if (!result) throw new ApiError(404, 'Result not found for this student.');

  const student = await Student.findById(req.params.studentId).populate('class section');
  const school = await SchoolSettings.findOne({ key: 'default' });

  generateReportCardPDF(res, { school, student, exam, result });
});

module.exports = {
  getExams, createExam, updateExam, deleteExam,
  upsertResult, getExamResults, publishResults, lockResults, downloadReportCard,
};
