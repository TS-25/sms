const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Staff = require('../models/Staff');
const User = require('../models/User');
const { ROLES } = require('../config/roles');

const getStaff = asyncHandler(async (req, res) => {
  const { search, department, page = 1, limit = 20 } = req.query;
  const filter = {};
  if (department) filter.department = department;
  if (search) {
    filter.$or = [
      { firstName: { $regex: search, $options: 'i' } },
      { lastName: { $regex: search, $options: 'i' } },
      { employeeId: { $regex: search, $options: 'i' } },
    ];
  }

  const skip = (Number(page) - 1) * Number(limit);
  const [staff, total] = await Promise.all([
    Staff.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Staff.countDocuments(filter),
  ]);

  res.json({ success: true, data: staff, pagination: { total, page: Number(page), limit: Number(limit) } });
});

const createStaff = asyncHandler(async (req, res) => {
  const { firstName, lastName, email, password, employeeId, department, designation, phone, address, joiningDate, salary, role } = req.body;

  const existingUser = await User.findOne({ email: email.toLowerCase() });
  if (existingUser) throw new ApiError(409, 'A user with this email already exists.');
  const existingEmp = await Staff.findOne({ employeeId });
  if (existingEmp) throw new ApiError(409, 'This employee ID is already in use.');

  const user = await User.create({
    name: `${firstName} ${lastName || ''}`.trim(),
    email,
    password: password || `${employeeId}@123`,
    role: role && Object.values(ROLES).includes(role) ? role : ROLES.STAFF,
    phone,
  });

  const staff = await Staff.create({
    user: user._id, employeeId, firstName, lastName, department, designation, phone, email, address, joiningDate, salary,
  });

  user.profileRef = { kind: 'Staff', id: staff._id };
  await user.save();

  res.status(201).json({ success: true, data: staff });
});

const updateStaff = asyncHandler(async (req, res) => {
  const staff = await Staff.findById(req.params.id);
  if (!staff) throw new ApiError(404, 'Staff member not found.');

  const allowedFields = ['firstName', 'lastName', 'department', 'designation', 'phone', 'email', 'address', 'salary', 'status', 'photoUrl'];
  allowedFields.forEach((f) => { if (req.body[f] !== undefined) staff[f] = req.body[f]; });
  await staff.save();

  res.json({ success: true, data: staff });
});

const deleteStaff = asyncHandler(async (req, res) => {
  const staff = await Staff.findByIdAndDelete(req.params.id);
  if (!staff) throw new ApiError(404, 'Staff member not found.');
  await User.findByIdAndDelete(staff.user);
  res.json({ success: true, message: 'Staff member deleted.' });
});

module.exports = { getStaff, createStaff, updateStaff, deleteStaff };
