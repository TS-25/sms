const asyncHandler = require('../utils/asyncHandler');
const SchoolSettings = require('../models/SchoolSettings');

// GET /api/settings
const getSettings = asyncHandler(async (req, res) => {
  let settings = await SchoolSettings.findOne({ key: 'default' });
  if (!settings) settings = await SchoolSettings.create({ key: 'default' });
  res.json({ success: true, data: settings });
});

// PUT /api/settings
const updateSettings = asyncHandler(async (req, res) => {
  const settings = await SchoolSettings.findOneAndUpdate(
    { key: 'default' },
    { $set: req.body },
    { new: true, upsert: true, runValidators: true }
  );
  res.json({ success: true, data: settings });
});

module.exports = { getSettings, updateSettings };
