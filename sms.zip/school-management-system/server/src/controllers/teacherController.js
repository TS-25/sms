const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Teacher = require('../models/Teacher');
const User = require('../models/User');
const { ROLES } = require('../config/roles');
const logAction = require('../utils/logAction');

const POPULATE = [
  { path: 'subjects', select: 'name code' },
  { path: 'assignedClasses', select: 'name' },
];

// GET /api/teachers?search=&status=&page=&limit=
const getTeachers = asyncHandler(async (req, res) => {
  const { search, status, page = 1, limit = 20 } = req.query;
  const filter = {};
  if (status) filter.status = status;
  if (search) {
    filter.$or = [
      { firstName: { $regex: search, $options: 'i' } },
      { lastName: { $regex: search, $options: 'i' } },
      { employeeId: { $regex: search, $options: 'i' } },
    ];
  }

  const skip = (Number(page) - 1) * Number(limit);
  const [teachers, total] = await Promise.all([
    Teacher.find(filter).populate(POPULATE).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Teacher.countDocuments(filter),
  ]);

  res.json({
    success: true,
    data: teachers,
    pagination: { total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) },
  });
});

// GET /api/teachers/:id
const getTeacherById = asyncHandler(async (req, res) => {
  const teacher = await Teacher.findById(req.params.id).populate(POPULATE);
  if (!teacher) throw new ApiError(404, 'Teacher not found.');
  res.json({ success: true, data: teacher });
});

// POST /api/teachers
const createTeacher = asyncHandler(async (req, res) => {
  const {
    firstName, lastName, email, password, employeeId, qualification,
    designation, subjects, assignedClasses, phone, address, joiningDate, salary,
  } = req.body;

  const existingUser = await User.findOne({ email: email.toLowerCase() });
  if (existingUser) throw new ApiError(409, 'A user with this email already exists.');

  const existingEmp = await Teacher.findOne({ employeeId });
  if (existingEmp) throw new ApiError(409, 'This employee ID is already in use.');

  const user = await User.create({
    name: `${firstName} ${lastName || ''}`.trim(),
    email,
    password: password || `${employeeId}@123`,
    role: ROLES.TEACHER,
    phone,
  });

  const teacher = await Teacher.create({
    user: user._id,
    employeeId,
    firstName,
    lastName,
    qualification,
    designation,
    subjects,
    assignedClasses,
    phone,
    email,
    address,
    joiningDate,
    salary,
  });

  user.profileRef = { kind: 'Teacher', id: teacher._id };
  await user.save();

  await logAction({ user: req.user, action: 'created', entity: 'Teacher', entityId: teacher._id, req });
  res.status(201).json({ success: true, data: teacher });
});

// PUT /api/teachers/:id
const updateTeacher = asyncHandler(async (req, res) => {
  const teacher = await Teacher.findById(req.params.id);
  if (!teacher) throw new ApiError(404, 'Teacher not found.');

  const allowedFields = [
    'firstName', 'lastName', 'qualification', 'designation', 'subjects',
    'assignedClasses', 'phone', 'email', 'address', 'salary', 'status', 'photoUrl',
  ];
  allowedFields.forEach((field) => {
    if (req.body[field] !== undefined) teacher[field] = req.body[field];
  });
  await teacher.save();

  await logAction({ user: req.user, action: 'updated', entity: 'Teacher', entityId: teacher._id, req });
  res.json({ success: true, data: teacher });
});

// DELETE /api/teachers/:id
const deleteTeacher = asyncHandler(async (req, res) => {
  const teacher = await Teacher.findByIdAndDelete(req.params.id);
  if (!teacher) throw new ApiError(404, 'Teacher not found.');
  await User.findByIdAndDelete(teacher.user);

  await logAction({ user: req.user, action: 'deleted', entity: 'Teacher', entityId: teacher._id, req });
  res.json({ success: true, message: 'Teacher deleted successfully.' });
});

module.exports = { getTeachers, getTeacherById, createTeacher, updateTeacher, deleteTeacher };
