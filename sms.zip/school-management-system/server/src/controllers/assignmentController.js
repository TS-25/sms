const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const Assignment = require('../models/Assignment');
const Student = require('../models/Student');
const Notification = require('../models/Notification');

// GET /api/assignments?class=&section=
const getAssignments = asyncHandler(async (req, res) => {
  const { class: classId, section } = req.query;
  const filter = {};
  if (classId) filter.class = classId;
  if (section) filter.section = section;

  const assignments = await Assignment.find(filter)
    .populate('teacher', 'firstName lastName')
    .populate('subject', 'name')
    .populate('class section', 'name')
    .sort({ deadline: 1 });

  res.json({ success: true, data: assignments });
});

// POST /api/assignments
const createAssignment = asyncHandler(async (req, res) => {
  const assignment = await Assignment.create(req.body);

  const students = await Student.find({ class: assignment.class }, 'user');
  const targetIds = students.map((s) => s.user).filter(Boolean);
  if (targetIds.length) {
    await Notification.insertMany(
      targetIds.map((userId) => ({
        user: userId,
        title: 'New Assignment',
        message: `A new assignment "${assignment.title}" has been posted. Deadline: ${new Date(
          assignment.deadline
        ).toLocaleDateString()}`,
        type: 'new_assignment',
      }))
    );
  }

  res.status(201).json({ success: true, data: assignment });
});

const updateAssignment = asyncHandler(async (req, res) => {
  const assignment = await Assignment.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });
  if (!assignment) throw new ApiError(404, 'Assignment not found.');
  res.json({ success: true, data: assignment });
});

const deleteAssignment = asyncHandler(async (req, res) => {
  const assignment = await Assignment.findByIdAndDelete(req.params.id);
  if (!assignment) throw new ApiError(404, 'Assignment not found.');
  res.json({ success: true, message: 'Assignment deleted.' });
});

// POST /api/assignments/:id/submit  body: { student, fileUrl }
const submitAssignment = asyncHandler(async (req, res) => {
  const assignment = await Assignment.findById(req.params.id);
  if (!assignment) throw new ApiError(404, 'Assignment not found.');

  const { student, fileUrl } = req.body;
  const existing = assignment.submissions.find((s) => String(s.student) === String(student));
  if (existing) {
    existing.fileUrl = fileUrl;
    existing.submittedAt = new Date();
  } else {
    assignment.submissions.push({ student, fileUrl });
  }
  await assignment.save();
  res.json({ success: true, data: assignment });
});

module.exports = {
  getAssignments, createAssignment, updateAssignment, deleteAssignment, submitAssignment,
};
