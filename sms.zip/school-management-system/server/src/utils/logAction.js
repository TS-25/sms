const AuditLog = require('../models/AuditLog');

// Fire-and-forget audit logger. Never throws — a logging failure must not
// break the primary request.
const logAction = async ({ user, action, entity, entityId, req, meta }) => {
  try {
    await AuditLog.create({
      user: user?._id,
      userLabel: user ? `${user.name} (${user.role})` : 'system',
      action,
      entity,
      entityId,
      ip: req?.ip,
      meta,
    });
  } catch (err) {
    console.error('Audit log failure:', err.message);
  }
};

module.exports = logAction;
