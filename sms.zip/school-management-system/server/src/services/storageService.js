// Thin abstraction so controllers never care whether a file ended up on
// local disk or in Cloudinary. Switch providers purely via env vars.
const path = require('path');

const getPublicUrl = (req, filename) => {
  if (process.env.STORAGE_PROVIDER === 'cloudinary') {
    // When using multer-storage-cloudinary in upload.js, `file.path` is
    // already the hosted URL — this function is only needed for local mode.
    return filename;
  }
  const base = `${req.protocol}://${req.get('host')}`;
  return `${base}/uploads/${path.basename(filename)}`;
};

module.exports = { getPublicUrl };
