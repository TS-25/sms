const nodemailer = require('nodemailer');

// If EMAIL_HOST is not configured, emails are logged to the console instead
// of failing — this keeps local development and demos working without any
// email provider set up.
let transporter = null;

function getTransporter() {
  if (transporter) return transporter;
  if (!process.env.EMAIL_HOST) return null;

  transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: Number(process.env.EMAIL_PORT) || 587,
    secure: Number(process.env.EMAIL_PORT) === 465,
    auth: process.env.EMAIL_USER
      ? { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASSWORD }
      : undefined,
  });
  return transporter;
}

const sendEmail = async ({ to, subject, html, text }) => {
  const t = getTransporter();
  if (!t) {
    console.log(`[email:mock] To: ${to} | Subject: ${subject}\n${text || html}`);
    return { mocked: true };
  }
  return t.sendMail({
    from: process.env.EMAIL_FROM || 'no-reply@school.com',
    to,
    subject,
    html,
    text,
  });
};

module.exports = { sendEmail };
