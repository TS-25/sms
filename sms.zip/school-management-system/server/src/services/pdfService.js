const PDFDocument = require('pdfkit');

// Streams a print-friendly fee receipt PDF directly to the HTTP response.
function generateFeeReceiptPDF(res, { school, student, fee, payment }) {
  const doc = new PDFDocument({ margin: 50, size: 'A4' });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader(
    'Content-Disposition',
    `attachment; filename=receipt-${payment.receiptNumber}.pdf`
  );
  doc.pipe(res);

  doc.fontSize(18).text(school?.schoolName || 'School', { align: 'center' });
  if (school?.address) doc.fontSize(10).text(school.address, { align: 'center' });
  doc.moveDown();
  doc.fontSize(14).text('Fee Payment Receipt', { align: 'center', underline: true });
  doc.moveDown(1.5);

  doc.fontSize(11);
  doc.text(`Receipt No: ${payment.receiptNumber}`);
  doc.text(`Date: ${new Date(payment.paidAt).toLocaleDateString()}`);
  doc.moveDown();
  doc.text(`Student Name: ${student.fullName}`);
  doc.text(`Admission No: ${student.admissionNumber}`);
  doc.text(`Class/Section: ${student.class?.name || ''} / ${student.section?.name || ''}`);
  doc.moveDown();
  doc.text(`Fee Title: ${fee.title}`);
  doc.text(`Category: ${fee.category}`);
  doc.text(`Total Amount: ${school?.currency || ''} ${fee.amount}`);
  doc.text(`Discount: ${school?.currency || ''} ${fee.discount}`);
  doc.text(`Amount Paid (this receipt): ${school?.currency || ''} ${payment.amount}`);
  doc.text(`Payment Method: ${payment.method}`);
  doc.moveDown(2);
  doc.text('_____________________', { align: 'right' });
  doc.text('Authorized Signature', { align: 'right' });

  doc.end();
}

// Streams a basic report card PDF.
function generateReportCardPDF(res, { school, student, exam, result }) {
  const doc = new PDFDocument({ margin: 50, size: 'A4' });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader(
    'Content-Disposition',
    `attachment; filename=report-card-${student.admissionNumber}.pdf`
  );
  doc.pipe(res);

  doc.fontSize(18).text(school?.schoolName || 'School', { align: 'center' });
  if (school?.address) doc.fontSize(10).text(school.address, { align: 'center' });
  doc.moveDown();
  doc.fontSize(14).text('Report Card', { align: 'center', underline: true });
  doc.moveDown();

  doc.fontSize(11);
  doc.text(`Student: ${student.fullName}`);
  doc.text(`Admission No: ${student.admissionNumber}`);
  doc.text(`Class/Section: ${student.class?.name || ''} / ${student.section?.name || ''}`);
  doc.text(`Exam: ${exam.name}`);
  doc.moveDown();

  const tableTop = doc.y;
  doc.font('Helvetica-Bold');
  doc.text('Subject', 50, tableTop);
  doc.text('Full Marks', 250, tableTop);
  doc.text('Obtained', 350, tableTop);
  doc.font('Helvetica');
  let y = tableTop + 20;
  result.marks.forEach((m) => {
    doc.text(m.subject?.name || String(m.subject), 50, y);
    doc.text(String(m.fullMarks), 250, y);
    doc.text(String(m.marksObtained), 350, y);
    y += 20;
  });

  doc.moveDown(2);
  doc.font('Helvetica-Bold');
  doc.text(`Total: ${result.totalObtained} / ${result.totalFullMarks}`);
  doc.text(`Percentage: ${result.percentage}%`);
  doc.text(`Grade: ${result.grade}  |  GPA: ${result.gpa}`);
  doc.text(`Result: ${result.isPass ? 'PASS' : 'FAIL'}`);

  doc.moveDown(3);
  doc.font('Helvetica');
  doc.text('_____________________', 50, doc.y, { continued: false });
  doc.text('Class Teacher', 50);
  doc.text('_____________________', 350, doc.y - 14);
  doc.text('Principal', 350);

  doc.end();
}

// Streams a wallet-sized student/staff ID card PDF (front side only —
// simple, print-friendly, one card per page for now).
function generateIdCardPDF(res, { school, person, role, idLabel, classSection }) {
  const doc = new PDFDocument({ size: [242, 153], margin: 10 }); // ~ CR80 card size in points
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename=id-card-${idLabel}.pdf`);
  doc.pipe(res);

  doc.rect(0, 0, 242, 153).fill('#1A1F16');
  doc.fillColor('#F7F5EF').fontSize(10).text(school?.schoolName || 'School', 10, 10, { width: 222 });
  doc.fontSize(7).fillColor('#DDAE4D').text(role.toUpperCase(), 10, 24);

  doc.fillColor('#F7F5EF').fontSize(11).text(person.fullName || person.name, 10, 45, { width: 150 });
  doc.fontSize(8).fillColor('#C4C8BE');
  doc.text(`ID: ${idLabel}`, 10, 62);
  if (classSection) doc.text(`Class: ${classSection}`, 10, 76);
  if (person.phone) doc.text(`Phone: ${person.phone}`, 10, 90);

  doc.fontSize(6).fillColor('#9DA394').text(school?.address || '', 10, 130, { width: 222 });

  doc.end();
}

// Streams a printable certificate PDF (character, transfer, participation, etc).
function generateCertificatePDF(res, { school, student, certificate }) {
  const doc = new PDFDocument({ margin: 60, size: 'A4', layout: 'landscape' });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader(
    'Content-Disposition',
    `attachment; filename=certificate-${certificate.certificateNumber}.pdf`
  );
  doc.pipe(res);

  doc.rect(20, 20, doc.page.width - 40, doc.page.height - 40).stroke('#C99529');

  doc.fontSize(20).fillColor('#1A1F16').text(school?.schoolName || 'School', { align: 'center' });
  doc.moveDown(0.5);
  doc.fontSize(24).text(certificate.title, { align: 'center', underline: true });
  doc.moveDown(2);

  doc.fontSize(13).fillColor('#333A2D').text(certificate.body.replace('{{studentName}}', student.fullName), {
    align: 'center',
    width: doc.page.width - 160,
    lineGap: 6,
  });

  doc.moveDown(3);
  doc.fontSize(10).fillColor('#454C3E');
  doc.text(`Certificate No: ${certificate.certificateNumber}`, 60, doc.page.height - 100);
  doc.text(`Date: ${new Date(certificate.issueDate).toLocaleDateString()}`, 60, doc.page.height - 85);
  doc.text('_____________________', doc.page.width - 220, doc.page.height - 100);
  doc.text('Principal Signature', doc.page.width - 220, doc.page.height - 85);

  doc.end();
}

module.exports = {
  generateFeeReceiptPDF,
  generateReportCardPDF,
  generateIdCardPDF,
  generateCertificatePDF,
};
