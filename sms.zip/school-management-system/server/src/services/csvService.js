const { parse } = require('csv-parse/sync');
const { Parser: CsvParser } = require('json2csv');

// Parses an uploaded CSV file buffer into an array of plain objects.
function parseCsvBuffer(buffer) {
  return parse(buffer, {
    columns: true,
    skip_empty_lines: true,
    trim: true,
  });
}

// Converts an array of plain objects (e.g. from a Mongoose .lean() query)
// into a CSV string for export/download.
function toCsv(records, fields) {
  const parser = new CsvParser({ fields });
  return parser.parse(records);
}

module.exports = { parseCsvBuffer, toCsv };
