const mongoose = require('mongoose');

// Simple configurable grading scale. In a full implementation this would
// live in SchoolSettings; kept here as a sane default.
const GRADE_SCALE = [
  { min: 90, grade: 'A+', gpa: 5.0 },
  { min: 80, grade: 'A', gpa: 4.0 },
  { min: 70, grade: 'A-', gpa: 3.5 },
  { min: 60, grade: 'B', gpa: 3.0 },
  { min: 50, grade: 'C', gpa: 2.0 },
  { min: 33, grade: 'D', gpa: 1.0 },
  { min: 0, grade: 'F', gpa: 0.0 },
];

function gradeFor(percentage) {
  return GRADE_SCALE.find((g) => percentage >= g.min) || GRADE_SCALE[GRADE_SCALE.length - 1];
}

const marksEntrySchema = new mongoose.Schema(
  {
    subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', required: true },
    marksObtained: { type: Number, required: true },
    fullMarks: { type: Number, required: true },
    passMarks: { type: Number, required: true },
  },
  { _id: false }
);

const examResultSchema = new mongoose.Schema(
  {
    exam: { type: mongoose.Schema.Types.ObjectId, ref: 'Exam', required: true },
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    marks: [marksEntrySchema],
    totalFullMarks: { type: Number },
    totalObtained: { type: Number },
    percentage: { type: Number },
    grade: { type: String },
    gpa: { type: Number },
    isPass: { type: Boolean },
    rank: { type: Number },
    remarks: { type: String },
  },
  { timestamps: true }
);

examResultSchema.index({ exam: 1, student: 1 }, { unique: true });

// Recalculate aggregate fields any time marks are set/modified.
examResultSchema.pre('save', function computeResult(next) {
  if (this.isModified('marks')) {
    const totalFullMarks = this.marks.reduce((sum, m) => sum + m.fullMarks, 0);
    const totalObtained = this.marks.reduce((sum, m) => sum + m.marksObtained, 0);
    const percentage = totalFullMarks > 0 ? (totalObtained / totalFullMarks) * 100 : 0;
    const isPass = this.marks.every((m) => m.marksObtained >= m.passMarks);
    const { grade, gpa } = gradeFor(percentage);

    this.totalFullMarks = totalFullMarks;
    this.totalObtained = totalObtained;
    this.percentage = Math.round(percentage * 100) / 100;
    this.isPass = isPass;
    this.grade = isPass ? grade : 'F';
    this.gpa = isPass ? gpa : 0;
  }
  next();
});

module.exports = mongoose.model('ExamResult', examResultSchema);
