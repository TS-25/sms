const mongoose = require('mongoose');

// Singleton document — always fetched/updated by a fixed key so there is
// only ever one settings record.
const schoolSettingsSchema = new mongoose.Schema(
  {
    key: { type: String, default: 'default', unique: true },
    schoolName: { type: String, default: 'My School' },
    logoUrl: { type: String },
    address: { type: String },
    phone: { type: String },
    email: { type: String },
    website: { type: String },
    currency: { type: String, default: 'USD' },
    dateFormat: { type: String, default: 'DD/MM/YYYY' },
    timezone: { type: String, default: 'UTC' },
    currentAcademicSession: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'AcademicSession',
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('SchoolSettings', schoolSettingsSchema);
