const mongoose = require('mongoose');

const documentSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    category: {
      type: String,
      enum: ['student', 'teacher', 'staff', 'school', 'certificate', 'other'],
      default: 'other',
    },
    fileUrl: { type: String, required: true },
    // Optional link to the entity this document belongs to.
    relatedTo: {
      kind: { type: String, enum: ['Student', 'Teacher', 'Staff'] },
      id: { type: mongoose.Schema.Types.ObjectId, refPath: 'relatedTo.kind' },
    },
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Document', documentSchema);
