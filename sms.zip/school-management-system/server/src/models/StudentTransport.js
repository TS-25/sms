const mongoose = require('mongoose');

const studentTransportSchema = new mongoose.Schema(
  {
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true, unique: true },
    vehicle: { type: mongoose.Schema.Types.ObjectId, ref: 'Vehicle', required: true },
    route: { type: mongoose.Schema.Types.ObjectId, ref: 'Route', required: true },
    stopId: { type: mongoose.Schema.Types.ObjectId, required: true }, // sub-doc id within Route.stops
    monthlyFee: { type: Number, default: 0 },
  },
  { timestamps: true }
);

module.exports = mongoose.model('StudentTransport', studentTransportSchema);
