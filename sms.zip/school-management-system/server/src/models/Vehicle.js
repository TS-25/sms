const mongoose = require('mongoose');

const vehicleSchema = new mongoose.Schema(
  {
    vehicleNumber: { type: String, required: true, unique: true, trim: true },
    model: { type: String, trim: true },
    capacity: { type: Number, default: 40 },
    driverName: { type: String, trim: true },
    driverPhone: { type: String, trim: true },
    driverLicenseNumber: { type: String, trim: true },
    route: { type: mongoose.Schema.Types.ObjectId, ref: 'Route' },
    status: { type: String, enum: ['active', 'maintenance', 'inactive'], default: 'active' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Vehicle', vehicleSchema);
