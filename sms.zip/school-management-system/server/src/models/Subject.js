const mongoose = require('mongoose');

const subjectSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    code: { type: String, required: true, unique: true, trim: true, uppercase: true },
    class: { type: mongoose.Schema.Types.ObjectId, ref: 'Class' },
    teacher: { type: mongoose.Schema.Types.ObjectId, ref: 'Teacher' },
    fullMarks: { type: Number, default: 100 },
    passMarks: { type: Number, default: 33 },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Subject', subjectSchema);
