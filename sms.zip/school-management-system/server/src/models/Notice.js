const mongoose = require('mongoose');

const noticeSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: { type: String, required: true },
    attachmentUrl: { type: String },
    targetAudience: {
      type: String,
      enum: ['everyone', 'teachers', 'students', 'parents', 'staff', 'class'],
      default: 'everyone',
    },
    targetClass: { type: mongoose.Schema.Types.ObjectId, ref: 'Class' },
    publishDate: { type: Date, default: Date.now },
    expiryDate: { type: Date },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Notice', noticeSchema);
