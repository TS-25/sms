const mongoose = require('mongoose');

const stopSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    name: { type: String, required: true },
    pickupTime: { type: String }, // "07:30"
    dropTime: { type: String }, // "14:30"
    fare: { type: Number, default: 0 },
  },
  { _id: true }
);

const routeSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    stops: [stopSchema],
  },
  { timestamps: true }
);

module.exports = mongoose.model('Route', routeSchema);
